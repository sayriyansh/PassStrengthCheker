"""
API Router Configuration

Main API router that includes all version 1 endpoints.
"""

from fastapi import APIRouter

from app.api.v1.endpoints import documents, chat, health, admin

# Create main API router
api_router = APIRouter()

# Include endpoint routers
api_router.include_router(
    documents.router,
    prefix="/documents",
    tags=["Documents"]
)

api_router.include_router(
    chat.router,
    prefix="/chat",
    tags=["Chat"]
)

api_router.include_router(
    health.router,
    prefix="/health",
    tags=["Health"]
)

api_router.include_router(
    admin.router,
    prefix="/admin",
    tags=["Admin"]
)