"""
Chat Endpoints

Handles chat interactions and conversation management.
"""

import asyncio
from typing import AsyncGenerator, List, Optional
from uuid import uuid4

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import StreamingResponse

from app.core.config import settings
from app.core.logging import get_logger
from app.core.security import verify_api_key
from app.models.chat import (
    ChatRequest,
    ChatResponse,
    ChatSource,
    Conversation,
    ConversationListResponse,
    ConversationRequest,
    MessageRole,
    StreamingChunk
)
from app.models.response import APIResponse, ErrorResponse
from app.services.chat_service import chat_service
from app.services.llm_service import llm_service
from app.services.retrieval_service import retrieval_service

logger = get_logger(__name__)
router = APIRouter()


@router.post(
    "/",
    response_model=APIResponse[ChatResponse],
    summary="Send chat message",
    description="Send a message and get a context-bound response"
)
async def send_message(
    request: ChatRequest,
    api_key: str = Depends(verify_api_key)
):
    """
    Send a chat message and receive a response.
    
    Args:
        request: Chat request containing query and options
        
    Returns:
        Chat response with answer and sources
    """
    try:
        # Get or create session
        session_id = request.session_id or str(uuid4())
        
        # Retrieve conversation history if available
        conversation_history = None
        if request.session_id:
            conversation = await chat_service.get_conversation(session_id)
            if conversation:
                # Get recent messages for context
                recent_messages = conversation.messages[-request.context_limit:]
                conversation_history = [
                    {"role": msg.role.value, "content": msg.content}
                    for msg in recent_messages
                ]
        
        # Retrieve relevant context
        context, sources = await retrieval_service.retrieve_context_with_sources(
            query=request.query,
            top_k=settings.TOP_K_CHUNKS
        )
        
        if not context:
            # No relevant context found
            answer = "information not available in provided data"
        else:
            # Generate response
            answer = await llm_service.generate_response(
                query=request.query,
                context=context,
                conversation_history=conversation_history
            )
        
        # Save message to conversation
        message_id = str(uuid4())
        await chat_service.add_message(
            session_id=session_id,
            role=MessageRole.USER,
            content=request.query
        )
        
        await chat_service.add_message(
            session_id=session_id,
            role=MessageRole.ASSISTANT,
            content=answer,
            sources=sources if request.include_sources else None
        )
        
        # Create response
        response = ChatResponse(
            answer=answer,
            session_id=session_id,
            message_id=message_id,
            sources=sources if request.include_sources else [],
            metadata={
                "context_used": bool(context),
                "sources_count": len(sources),
                "model": settings.LLM_MODEL
            }
        )
        
        logger.info(
            f"Chat response generated",
            extra={
                "session_id": session_id,
                "message_id": message_id,
                "query": request.query[:100] + "..." if len(request.query) > 100 else request.query,
                "answer_length": len(answer),
                "sources_count": len(sources)
            }
        )
        
        return APIResponse(data=response)
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Chat message failed: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to process chat message"
        )


@router.post(
    "/stream",
    response_class=StreamingResponse,
    summary="Send streaming chat message",
    description="Send a message and receive streaming response"
)
async def send_streaming_message(
    request: ChatRequest,
    api_key: str = Depends(verify_api_key)
):
    """
    Send a chat message and receive streaming response.
    
    Args:
        request: Chat request
        
    Returns:
        Streaming response
    """
    try:
        session_id = request.session_id or str(uuid4())
        
        async def generate_stream() -> AsyncGenerator[str, None]:
            """Generate streaming response."""
            try:
                # Retrieve context
                context, sources = await retrieval_service.retrieve_context_with_sources(
                    query=request.query,
                    top_k=settings.TOP_K_CHUNKS
                )
                
                # Start streaming response
                message_id = str(uuid4())
                
                # Send stream start
                start_chunk = StreamingChunk(
                    chunk_type="start",
                    content=f"{{\"session_id\": \"{session_id}\", \"message_id\": \"{message_id}\"}}",
                    metadata={"sources_count": len(sources)}
                )
                yield f"data: {start_chunk.model_dump_json()}\n\n"
                
                # Stream response chunks
                if context:
                    async for chunk in llm_service.generate_streaming_response(
                        query=request.query,
                        context=context
                    ):
                        content_chunk = StreamingChunk(
                            chunk_type="content",
                            content=chunk
                        )
                        yield f"data: {content_chunk.model_dump_json()}\n\n"
                else:
                    # No context available
                    content_chunk = StreamingChunk(
                        chunk_type="content",
                        content="information not available in provided data"
                    )
                    yield f"data: {content_chunk.model_dump_json()}\n\n"
                
                # Send sources and end
                end_chunk = StreamingChunk(
                    chunk_type="end",
                    sources=sources if request.include_sources else None,
                    metadata={"model": settings.LLM_MODEL}
                )
                yield f"data: {end_chunk.model_dump_json()}\n\n"
                yield "data: [DONE]\n\n"
                
            except Exception as e:
                error_chunk = StreamingChunk(
                    chunk_type="error",
                    content=f"Streaming failed: {str(e)}"
                )
                yield f"data: {error_chunk.model_dump_json()}\n\n"
                yield "data: [DONE]\n\n"
        
        return StreamingResponse(
            generate_stream(),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "Connection": "keep-alive"
            }
        )
        
    except Exception as e:
        logger.error(f"Streaming chat failed: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Streaming chat failed"
        )


@router.get(
    "/conversations",
    response_model=APIResponse[ConversationListResponse],
    summary="List conversations",
    description="List all conversation sessions"
)
async def list_conversations(
    limit: int = 50,
    offset: int = 0,
    api_key: str = Depends(verify_api_key)
):
    """
    List conversation sessions.
    
    Args:
        limit: Number of conversations to return
        offset: Number of conversations to skip
        
    Returns:
        List of conversations
    """
    try:
        conversations = await chat_service.list_conversations(
            limit=limit,
            offset=offset
        )
        
        response = ConversationListResponse(
            conversations=conversations,
            total=len(conversations)
        )
        
        return APIResponse(data=response)
        
    except Exception as e:
        logger.error(f"Failed to list conversations: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to list conversations"
        )


@router.get(
    "/conversations/{session_id}",
    response_model=APIResponse[Conversation],
    summary="Get conversation",
    description="Get a specific conversation by session ID"
)
async def get_conversation(
    session_id: str,
    api_key: str = Depends(verify_api_key)
):
    """
    Get conversation by session ID.
    
    Args:
        session_id: Session ID
        
    Returns:
        Conversation details
    """
    try:
        conversation = await chat_service.get_conversation(session_id)
        
        if not conversation:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Conversation not found"
            )
        
        return APIResponse(data=conversation)
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to get conversation: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get conversation"
        )


@router.delete(
    "/conversations/{session_id}",
    response_model=APIResponse[dict],
    summary="Delete conversation",
    description="Delete a conversation and its messages"
)
async def delete_conversation(
    session_id: str,
    api_key: str = Depends(verify_api_key)
):
    """
    Delete conversation.
    
    Args:
        session_id: Session ID to delete
        
    Returns:
        Deletion confirmation
    """
    try:
        success = await chat_service.delete_conversation(session_id)
        
        if not success:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Conversation not found"
            )
        
        return APIResponse(
            data={"deleted": True},
            message="Conversation deleted successfully"
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to delete conversation: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to delete conversation"
        )


@router.post(
    "/conversations/{session_id}/clear",
    response_model=APIResponse[dict],
    summary="Clear conversation history",
    description="Clear all messages from a conversation but keep the session"
)
async def clear_conversation(
    session_id: str,
    api_key: str = Depends(verify_api_key)
):
    """
    Clear conversation history.
    
    Args:
        session_id: Session ID
        
    Returns:
        Clear confirmation
    """
    try:
        success = await chat_service.clear_conversation(session_id)
        
        if not success:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Conversation not found"
            )
        
        return APIResponse(
            data={"cleared": True},
            message="Conversation history cleared successfully"
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to clear conversation: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to clear conversation"
        )