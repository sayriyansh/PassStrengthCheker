"""
Health Check Endpoints

System health monitoring and status endpoints.
"""

import asyncio
import time
from typing import Dict, Any

from fastapi import APIRouter, Depends, HTTPException, status

from app.core.config import settings
from app.core.logging import get_logger
from app.core.security import verify_api_key
from app.db.vector_store import vector_store
from app.models.response import HealthResponse

logger = get_logger(__name__)
router = APIRouter()


@router.get(
    "/",
    response_model=HealthResponse,
    summary="Health check",
    description="Check overall system health and dependencies"
)
async def health_check(
    detailed: bool = False,
    api_key: str = Depends(verify_api_key)
):
    """
    Check system health status.
    
    Args:
        detailed: Include detailed component checks
        
    Returns:
        Health status information
    """
    try:
        start_time = time.time()
        checks = {}
        
        # Check vector store
        vector_store_status = await _check_vector_store()
        checks["vector_store"] = vector_store_status
        
        # Check Redis (if configured)
        if settings.REDIS_URL:
            redis_status = await _check_redis()
            checks["redis"] = redis_status
        
        # Check database (if configured)
        if settings.DATABASE_URL:
            db_status = await _check_database()
            checks["database"] = db_status
        
        # Check LLM service (if health check enabled)
        if settings.DEBUG:
            llm_status = await _check_llm_service()
            checks["llm_service"] = llm_status
        
        # Determine overall health
        overall_healthy = all(
            check.get("status") == "healthy" 
            for check in checks.values()
        )
        
        response_time = time.time() - start_time
        
        response = HealthResponse(
            status="healthy" if overall_healthy else "unhealthy",
            version=settings.APP_VERSION,
            uptime=await _get_uptime(),
            checks=checks if detailed else {},
            metadata={
                "response_time": response_time,
                "checks_performed": len(checks)
            }
        )
        
        if not overall_healthy:
            logger.warning(
                "Health check failed",
                extra={"checks": checks, "response_time": response_time}
            )
        
        return response
        
    except Exception as e:
        logger.error(f"Health check failed: {e}")
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Health check failed"
        )


@router.get(
    "/ready",
    summary="Readiness check",
    description="Check if service is ready to handle requests"
)
async def readiness_check(
    api_key: str = Depends(verify_api_key)
):
    """
    Check if service is ready to handle requests.
    
    Returns:
        Readiness status
    """
    try:
        # Check essential components only
        vector_status = await _check_vector_store()
        
        if vector_status.get("status") == "healthy":
            return {"status": "ready", "timestamp": time.time()}
        else:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="Service not ready"
            )
            
    except Exception as e:
        logger.error(f"Readiness check failed: {e}")
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Service not ready"
        )


@router.get(
    "/live",
    summary="Liveness check",
    description="Check if service is alive"
)
async def liveness_check(
    api_key: str = Depends(verify_api_key)
):
    """
    Simple liveness check.
    
    Returns:
        Liveness status
    """
    return {
        "status": "alive",
        "timestamp": time.time(),
        "version": settings.APP_VERSION
    }


async def _check_vector_store() -> Dict[str, Any]:
    """Check vector store health."""
    try:
        start_time = time.time()
        stats = await vector_store.get_stats()
        
        if stats.get("status") == "healthy":
            return {
                "status": "healthy",
                "response_time": time.time() - start_time,
                "total_vectors": stats.get("total_vectors", 0),
                "index_type": stats.get("index_type", "unknown")
            }
        else:
            return {
                "status": "unhealthy",
                "error": stats.get("error", "Unknown error"),
                "response_time": time.time() - start_time
            }
            
    except Exception as e:
        return {
            "status": "unhealthy",
            "error": str(e),
            "response_time": time.time() - start_time
        }


async def _check_redis() -> Dict[str, Any]:
    """Check Redis health."""
    try:
        import redis.asyncio as redis
        
        start_time = time.time()
        redis_client = redis.from_url(settings.REDIS_URL)
        
        # Test connection
        await redis_client.ping()
        
        # Get info
        info = await redis_client.info()
        
        await redis_client.close()
        
        return {
            "status": "healthy",
            "response_time": time.time() - start_time,
            "version": info.get("redis_version", "unknown"),
            "connected_clients": info.get("connected_clients", 0),
            "used_memory_mb": info.get("used_memory_rss", 0) / (1024 * 1024)
        }
        
    except Exception as e:
        return {
            "status": "unhealthy",
            "error": str(e),
            "response_time": time.time() - start_time
        }


async def _check_database() -> Dict[str, Any]:
    """Check database health."""
    try:
        import asyncpg
        
        start_time = time.time()
        
        # Parse database URL
        conn = await asyncpg.connect(settings.DATABASE_URL)
        
        # Test query
        result = await conn.fetchval("SELECT 1")
        
        # Get database info
        version = await conn.fetchval("SELECT version()")
        
        await conn.close()
        
        if result == 1:
            return {
                "status": "healthy",
                "response_time": time.time() - start_time,
                "version": version.split()[1] if version else "unknown"
            }
        else:
            return {
                "status": "unhealthy",
                "error": "Database test query failed",
                "response_time": time.time() - start_time
            }
            
    except Exception as e:
        return {
            "status": "unhealthy",
            "error": str(e),
            "response_time": time.time() - start_time
        }


async def _check_llm_service() -> Dict[str, Any]:
    """Check LLM service health."""
    try:
        from app.services.llm_service import llm_service
        
        start_time = time.time()
        stats = await llm_service.get_llm_stats()
        
        return {
            "status": "healthy" if stats.get("status") == "healthy" else "unhealthy",
            "response_time": time.time() - start_time,
            "model": stats.get("model", "unknown"),
            "api_base": stats.get("api_base", "unknown")
        }
        
    except Exception as e:
        return {
            "status": "unhealthy",
            "error": str(e),
            "response_time": time.time() - start_time
        }


async def _get_uptime() -> Optional[float]:
    """Get application uptime."""
    try:
        # In a real implementation, you'd track startup time
        # For now, return None
        return None
    except Exception:
        return None


@router.get(
    "/metrics",
    summary="Prometheus metrics",
    description="Prometheus-compatible metrics endpoint"
)
async def get_metrics(
    api_key: str = Depends(verify_api_key)
):
    """
    Get Prometheus metrics.
    
    Returns:
        Metrics in Prometheus format
    """
    if not settings.PROMETHEUS_ENABLED:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Prometheus metrics not enabled"
        )
    
    try:
        # In production, integrate with prometheus_client
        # For now, return basic metrics
        metrics = [
            "# HELP rag_chatbot_uptime_seconds Application uptime in seconds",
            "# TYPE rag_chatbot_uptime_seconds gauge",
            f'rag_chatbot_uptime_seconds{{version="{settings.APP_VERSION}"}} {await _get_uptime() or 0}',
            "",
            "# HELP rag_chatbot_info Application information",
            "# TYPE rag_chatbot_info gauge",
            f'rag_chatbot_info{{version="{settings.APP_VERSION}",name="{settings.APP_NAME}"}} 1',
            "",
            "# HELP rag_chatbot_vector_store_total_vectors Total vectors in store",
            "# TYPE rag_chatbot_vector_store_total_vectors gauge",
        ]
        
        # Add vector store metrics
        try:
            vector_stats = await vector_store.get_stats()
            metrics.append(
                f'rag_chatbot_vector_store_total_vectors {vector_stats.get("total_vectors", 0)}'
            )
        except:
            metrics.append("rag_chatbot_vector_store_total_vectors 0")
        
        return "\n".join(metrics)
        
    except Exception as e:
        logger.error(f"Failed to get metrics: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get metrics"
        )