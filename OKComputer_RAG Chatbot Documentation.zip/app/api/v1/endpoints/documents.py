"""
Document Management Endpoints

Handles document upload, processing, and management.
"""

import asyncio
from typing import List, Optional
from uuid import UUID, uuid4

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile, status
from fastapi.responses import StreamingResponse

from app.core.config import settings
from app.core.logging import get_logger
from app.core.security import verify_api_key
from app.db.vector_store import vector_store
from app.models.document import (
    Document,
    DocumentDeleteResponse,
    DocumentListResponse,
    DocumentStatus,
    DocumentStatusResponse,
    DocumentType,
    DocumentUploadResponse,
    ProcessingError
)
from app.models.response import APIResponse, ErrorResponse
from app.services.document_processor import document_processor
from app.services.embedding_service import embedding_service
from app.utils.file_handlers import file_handler_registry

logger = get_logger(__name__)
router = APIRouter()


@router.post(
    "/upload",
    response_model=APIResponse[DocumentUploadResponse],
    status_code=status.HTTP_201_CREATED,
    summary="Upload documents",
    description="Upload one or more documents for processing and indexing"
)
async def upload_documents(
    files: List[UploadFile] = File(..., description="Document files to upload"),
    api_key: str = Depends(verify_api_key)
):
    """
    Upload and process multiple documents.
    
    Args:
        files: List of files to upload
        
    Returns:
        Upload response with document IDs and processing status
    """
    try:
        upload_responses = []
        
        for file in files:
            # Validate file
            if not file.filename:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="File must have a filename"
                )
            
            # Check file size
            file_size = 0
            content = await file.read()
            file_size = len(content)
            
            if file_size > settings.max_file_size_bytes:
                raise HTTPException(
                    status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
                    detail=f"File too large. Maximum size: {settings.MAX_FILE_SIZE}"
                )
            
            # Determine file type
            doc_type = _get_document_type(file.filename)
            if doc_type not in settings.ALLOWED_EXTENSIONS:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"File type not supported. Allowed: {settings.ALLOWED_EXTENSIONS}"
                )
            
            # Save file temporarily
            temp_dir = Path("./temp_uploads")
            temp_dir.mkdir(exist_ok=True)
            temp_file = temp_dir / f"{uuid4()}_{file.filename}"
            
            with open(temp_file, "wb") as f:
                f.write(content)
            
            # Process document asynchronously
            document_id = uuid4()
            
            # Start background processing
            asyncio.create_task(
                _process_document(temp_file, document_id, file.filename)
            )
            
            upload_responses.append(
                DocumentUploadResponse(
                    success=True,
                    document_id=document_id,
                    filename=file.filename,
                    status=DocumentStatus.PENDING,
                    message="Document uploaded successfully. Processing started."
                )
            )
            
            logger.info(
                f"Document uploaded",
                extra={
                    "document_id": str(document_id),
                    "filename": file.filename,
                    "file_size": file_size,
                    "file_type": doc_type
                }
            )
        
        return APIResponse(
            data=upload_responses[0] if len(upload_responses) == 1 else upload_responses,
            message=f"Successfully uploaded {len(upload_responses)} document(s)"
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Document upload failed: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Document upload failed"
        )


@router.get(
    "/{document_id}/status",
    response_model=APIResponse[DocumentStatusResponse],
    summary="Get document processing status",
    description="Check the processing status of a specific document"
)
async def get_document_status(
    document_id: UUID,
    api_key: str = Depends(verify_api_key)
):
    """
    Get document processing status.
    
    Args:
        document_id: Document ID to check
        
    Returns:
        Document processing status
    """
    try:
        # In a real implementation, this would query a database
        # For now, we'll return a mock status
        status_response = DocumentStatusResponse(
            document_id=document_id,
            status=DocumentStatus.COMPLETED,
            progress=1.0,
            message="Document processing completed successfully",
            processing_stats={
                "total_chunks": 25,
                "processing_time": 12.5,
                "embedding_time": 8.2,
                "index_time": 2.1
            }
        )
        
        return APIResponse(data=status_response)
        
    except Exception as e:
        logger.error(f"Failed to get document status: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve document status"
        )


@router.get(
    "/",
    response_model=APIResponse[DocumentListResponse],
    summary="List documents",
    description="List all uploaded documents with pagination"
)
async def list_documents(
    limit: int = 50,
    offset: int = 0,
    doc_type: Optional[DocumentType] = None,
    status: Optional[DocumentStatus] = None,
    api_key: str = Depends(verify_api_key)
):
    """
    List documents with optional filtering.
    
    Args:
        limit: Number of documents to return
        offset: Number of documents to skip
        doc_type: Filter by document type
        status: Filter by processing status
        
    Returns:
        List of documents
    """
    try:
        # Mock document list - in production, query database
        mock_documents = [
            Document(
                document_id=uuid4(),
                filename="sample_document.pdf",
                file_size=1024000,
                document_type=DocumentType.PDF,
                status=DocumentStatus.COMPLETED,
                metadata={
                    "title": "Sample Document",
                    "author": "John Doe",
                    "page_count": 10
                }
            )
        ]
        
        # Apply filters
        filtered_docs = mock_documents
        if doc_type:
            filtered_docs = [d for d in filtered_docs if d.document_type == doc_type]
        if status:
            filtered_docs = [d for d in filtered_docs if d.status == status]
        
        # Apply pagination
        paginated_docs = filtered_docs[offset:offset + limit]
        
        response = DocumentListResponse(
            documents=paginated_docs,
            total=len(filtered_docs),
            limit=limit,
            offset=offset
        )
        
        return APIResponse(data=response)
        
    except Exception as e:
        logger.error(f"Failed to list documents: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to list documents"
        )


@router.delete(
    "/{document_id}",
    response_model=APIResponse[DocumentDeleteResponse],
    summary="Delete document",
    description="Delete a document and its associated data"
)
async def delete_document(
    document_id: UUID,
    api_key: str = Depends(verify_api_key)
):
    """
    Delete document and associated data.
    
    Args:
        document_id: Document ID to delete
        
    Returns:
        Deletion confirmation
    """
    try:
        # Remove from vector store
        removed_count = await vector_store.remove_document(str(document_id))
        
        # In production, also remove from metadata database
        
        response = DocumentDeleteResponse(
            success=True,
            document_id=document_id,
            message=f"Document deleted successfully. Removed {removed_count} chunks from index."
        )
        
        logger.info(
            f"Document deleted",
            extra={
                "document_id": str(document_id),
                "chunks_removed": removed_count
            }
        )
        
        return APIResponse(data=response)
        
    except Exception as e:
        logger.error(f"Failed to delete document: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to delete document"
        )


async def _process_document(
    file_path: Path,
    document_id: UUID,
    filename: str
) -> None:
    """
    Process document in background.
    
    Args:
        file_path: Path to temporary file
        document_id: Document ID
        filename: Original filename
    """
    try:
        logger.info(f"Starting document processing", extra={"document_id": str(document_id)})
        
        # Parse document
        doc_type = _get_document_type(filename)
        handler = file_handler_registry.get_handler_by_type(doc_type)
        
        if not handler:
            raise ValueError(f"No handler found for document type: {doc_type}")
        
        # Process document
        document, chunks = await document_processor.process_document(
            file_path, document_id, filename
        )
        
        # Generate embeddings
        chunk_texts = [chunk.content for chunk in chunks]
        embeddings = await embedding_service.generate_embeddings(chunk_texts)
        
        # Add to vector store
        await vector_store.add_embeddings(chunks, embeddings)
        
        # Save vector store
        await vector_store.save_index()
        
        # Clean up temporary file
        file_path.unlink(missing_ok=True)
        
        logger.info(
            f"Document processing completed",
            extra={
                "document_id": str(document_id),
                "chunks_created": len(chunks),
                "embeddings_generated": len(embeddings)
            }
        )
        
    except Exception as e:
        logger.error(
            f"Document processing failed",
            extra={
                "document_id": str(document_id),
                "error": str(e)
            }
        )
        
        # Clean up temporary file
        file_path.unlink(missing_ok=True)


def _get_document_type(filename: str) -> str:
    """Get document type from filename."""
    suffix = Path(filename).suffix.lower()
    
    if suffix == ".pdf":
        return DocumentType.PDF
    elif suffix == ".txt":
        return DocumentType.TXT
    elif suffix in [".docx", ".doc"]:
        return DocumentType.DOCX
    elif suffix == ".csv":
        return DocumentType.CSV
    else:
        raise ValueError(f"Unsupported file type: {suffix}")