"""
Admin Endpoints

Administrative and monitoring endpoints.
"""

from fastapi import APIRouter, Depends, HTTPException, status

from app.core.config import settings
from app.core.logging import get_logger
from app.core.security import verify_api_key
from app.models.response import APIResponse
from app.services.embedding_service import embedding_service
from app.services.llm_service import llm_service
from app.services.retrieval_service import retrieval_service

logger = get_logger(__name__)
router = APIRouter()


@router.get(
    "/stats",
    response_model=APIResponse[dict],
    summary="Get system statistics",
    description="Get comprehensive system statistics and metrics"
)
async def get_system_stats(
    api_key: str = Depends(verify_api_key)
):
    """
    Get comprehensive system statistics.
    
    Returns:
        System statistics
    """
    try:
        # Collect statistics from all services
        stats = {
            "application": {
                "name": settings.APP_NAME,
                "version": settings.APP_VERSION,
                "debug": settings.DEBUG,
                "environment": "development" if settings.DEBUG else "production"
            },
            "configuration": {
                "chunk_size": settings.CHUNK_SIZE,
                "chunk_overlap": settings.CHUNK_OVERLAP,
                "top_k_chunks": settings.TOP_K_CHUNKS,
                "similarity_threshold": settings.SIMILARITY_THRESHOLD,
                "max_file_size": settings.MAX_FILE_SIZE,
                "allowed_extensions": settings.ALLOWED_EXTENSIONS
            },
            "services": {}
        }
        
        # Vector store stats
        try:
            from app.db.vector_store import vector_store
            vector_stats = await vector_store.get_stats()
            stats["services"]["vector_store"] = vector_stats
        except Exception as e:
            stats["services"]["vector_store"] = {
                "status": "error",
                "error": str(e)
            }
        
        # Retrieval service stats
        try:
            retrieval_stats = await retrieval_service.get_retrieval_stats()
            stats["services"]["retrieval"] = retrieval_stats
        except Exception as e:
            stats["services"]["retrieval"] = {
                "status": "error",
                "error": str(e)
            }
        
        # LLM service stats
        try:
            llm_stats = await llm_service.get_llm_stats()
            stats["services"]["llm"] = llm_stats
        except Exception as e:
            stats["services"]["llm"] = {
                "status": "error",
                "error": str(e)
            }
        
        # Embedding service stats
        try:
            embedding_stats = await embedding_service.get_embedding_stats([])
            stats["services"]["embedding"] = {
                "status": "healthy",
                "stats": embedding_stats
            }
        except Exception as e:
            stats["services"]["embedding"] = {
                "status": "error",
                "error": str(e)
            }
        
        return APIResponse(data=stats)
        
    except Exception as e:
        logger.error(f"Failed to get system stats: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get system statistics"
        )


@router.post(
    "/optimize-index",
    response_model=APIResponse[dict],
    summary="Optimize vector index",
    description="Optimize the FAISS vector index for better performance"
)
async def optimize_index(
    api_key: str = Depends(verify_api_key)
):
    """
    Optimize vector index.
    
    Returns:
        Optimization result
    """
    try:
        from app.db.vector_store import vector_store
        
        # Save current index (which will trigger optimization)
        await vector_store.save_index()
        
        # Get stats after optimization
        stats = await vector_store.get_stats()
        
        return APIResponse(
            data={
                "optimized": True,
                "stats": stats
            },
            message="Vector index optimized successfully"
        )
        
    except Exception as e:
        logger.error(f"Index optimization failed: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Index optimization failed"
        )


@router.delete(
    "/cache",
    response_model=APIResponse[dict],
    summary="Clear cache",
    description="Clear all caches including Redis cache"
)
async def clear_cache(
    cache_type: str = "all",
    api_key: str = Depends(verify_api_key)
):
    """
    Clear system cache.
    
    Args:
        cache_type: Type of cache to clear (all, redis, vector)
        
    Returns:
        Clear result
    """
    try:
        cleared_caches = []
        
        # Clear Redis cache
        if cache_type in ["all", "redis"] and settings.REDIS_URL:
            try:
                import redis.asyncio as redis
                
                redis_client = redis.from_url(settings.REDIS_URL)
                await redis_client.flushall()
                await redis_client.close()
                
                cleared_caches.append("redis")
                logger.info("Redis cache cleared")
            except Exception as e:
                logger.warning(f"Failed to clear Redis cache: {e}")
        
        # Clear vector store cache (if any)
        if cache_type in ["all", "vector"]:
            # In a real implementation, you might have a vector store cache
            cleared_caches.append("vector")
            logger.info("Vector store cache cleared")
        
        return APIResponse(
            data={"cleared_caches": cleared_caches},
            message=f"Successfully cleared {len(cleared_caches)} cache(s)"
        )
        
    except Exception as e:
        logger.error(f"Cache clearing failed: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Cache clearing failed"
        )


@router.get(
    "/logs",
    response_model=APIResponse[dict],
    summary="Get recent logs",
    description="Get recent application logs (debug mode only)"
)
async def get_logs(
    lines: int = 100,
    level: str = "ERROR",
    api_key: str = Depends(verify_api_key)
):
    """
    Get recent application logs.
    
    Args:
        lines: Number of log lines to return
        level: Log level to filter by
        
    Returns:
        Recent logs
    """
    if not settings.DEBUG:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Log access only available in debug mode"
        )
    
    try:
        # In production, integrate with log aggregation service
        # For now, return mock data
        mock_logs = [
            {
                "timestamp": "2024-01-01T12:00:00Z",
                "level": "INFO",
                "message": "Application started",
                "logger": "app.main"
            },
            {
                "timestamp": "2024-01-01T12:00:01Z",
                "level": "INFO",
                "message": "Vector store initialized",
                "logger": "app.db.vector_store"
            }
        ]
        
        return APIResponse(
            data={
                "logs": mock_logs[:lines],
                "total": len(mock_logs),
                "filtered_by": level
            }
        )
        
    except Exception as e:
        logger.error(f"Failed to get logs: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve logs"
        )


@router.post(
    "/reload-config",
    response_model=APIResponse[dict],
    summary="Reload configuration",
    description="Reload application configuration (debug mode only)"
)
async def reload_configuration(
    api_key: str = Depends(verify_api_key)
):
    """
    Reload application configuration.
    
    Returns:
        Reload result
    """
    if not settings.DEBUG:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Configuration reload only available in debug mode"
        )
    
    try:
        # In production, implement configuration reload logic
        # This might involve:
        # 1. Reloading environment variables
        # 2. Reinitializing services with new config
        # 3. Updating logging levels
        
        logger.info("Configuration reload requested")
        
        return APIResponse(
            data={"reloaded": True},
            message="Configuration reloaded successfully (mock implementation)"
        )
        
    except Exception as e:
        logger.error(f"Configuration reload failed: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Configuration reload failed"
        )