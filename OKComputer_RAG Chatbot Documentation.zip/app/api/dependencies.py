"""
API Dependencies

Shared dependencies for API endpoints.
"""

from fastapi import Depends, HTTPException, Request, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from app.core.config import settings
from app.core.logging import get_logger
from app.core.security import verify_api_key
from app.utils.validators import validate_api_key, validate_session_id

logger = get_logger(__name__)

# Security scheme
security = HTTPBearer(auto_error=False)


async def get_api_key(
    credentials: HTTPAuthorizationCredentials = Depends(security)
) -> str:
    """
    Extract and validate API key from request.
    
    Args:
        credentials: HTTP authorization credentials
        
    Returns:
        Validated API key
        
    Raises:
        HTTPException: If API key is invalid
    """
    if not credentials:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="API key required",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    try:
        api_key = validate_api_key(credentials.credentials)
        return api_key
    except HTTPException as e:
        raise e
    except Exception as e:
        logger.warning(f"API key validation failed: {e}")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid API key",
        )


def get_rate_limit_identifier(request: Request) -> str:
    """
    Get unique identifier for rate limiting.
    
    Args:
        request: FastAPI request object
        
    Returns:
        Rate limit identifier (IP or API key)
    """
    # Try to get from API key first
    auth_header = request.headers.get("Authorization")
    if auth_header and auth_header.startswith("Bearer "):
        return f"api_key:{auth_header[7:]}"
    
    # Fall back to IP address
    forwarded = request.headers.get("X-Forwarded-For")
    if forwarded:
        return forwarded.split(",")[0].strip()
    
    return request.client.host


async def verify_session(
    session_id: str,
    request: Request
) -> str:
    """
    Verify session ID.
    
    Args:
        session_id: Session ID to verify
        request: FastAPI request object
        
    Returns:
        Validated session ID
        
    Raises:
        HTTPException: If session is invalid
    """
    try:
        session_id = validate_session_id(session_id)
        
        # In production, verify session exists in database or Redis
        # For now, just validate format
        
        return session_id
        
    except HTTPException as e:
        raise e
    except Exception as e:
        logger.warning(f"Session validation failed: {e}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid session ID"
        )


def get_request_id(request: Request) -> str:
    """
    Get or generate request ID.
    
    Args:
        request: FastAPI request object
        
    Returns:
        Request ID
    """
    # Try to get from header first
    request_id = request.headers.get("X-Request-ID")
    if request_id:
        return request_id
    
    # Generate new request ID
    from app.core.security import generate_request_id
    return generate_request_id()


async def get_client_info(request: Request) -> dict:
    """
    Extract client information from request.
    
    Args:
        request: FastAPI request object
        
    Returns:
        Client information dictionary
    """
    return {
        "ip": request.client.host,
        "user_agent": request.headers.get("User-Agent", ""),
        "referer": request.headers.get("Referer", ""),
        "accept_language": request.headers.get("Accept-Language", ""),
        "x_forwarded_for": request.headers.get("X-Forwarded-For", ""),
    }


# Export dependencies
__all__ = [
    "get_api_key",
    "get_rate_limit_identifier",
    "verify_session",
    "get_request_id",
    "get_client_info"
]