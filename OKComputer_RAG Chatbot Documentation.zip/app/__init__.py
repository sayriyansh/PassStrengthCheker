"""
RAG Chatbot FastAPI Application

Enterprise-grade RAG chatbot with strict context-bound responses.
"""

__version__ = "1.0.0"
__author__ = "AI/ML Engineering Team"
__description__ = "Enterprise RAG Chatbot with Zero Hallucination"