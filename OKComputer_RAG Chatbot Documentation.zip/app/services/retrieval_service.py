"""
Retrieval Service

Handles semantic search and context retrieval from vector database.
"""

import asyncio
from typing import List, Optional, Tuple

import numpy as np

from app.core.config import settings
from app.core.logging import get_logger
from app.db.vector_store import VectorStore
from app.models.chat import ChatSource
from app.models.document import DocumentChunk
from app.services.embedding_service import embedding_service

logger = get_logger(__name__)


class RetrievalService:
    """
    Retrieval service for semantic search and context assembly.
    """
    
    def __init__(self):
        """Initialize retrieval service."""
        self.vector_store = None
        self._initialize_vector_store()
    
    def _initialize_vector_store(self) -> None:
        """Initialize vector store connection."""
        try:
            self.vector_store = VectorStore()
            logger.info("Retrieval service initialized with vector store")
        except Exception as e:
            logger.error(f"Failed to initialize vector store: {e}")
            raise
    
    async def retrieve_context(
        self,
        query: str,
        top_k: Optional[int] = None,
        similarity_threshold: Optional[float] = None,
        document_ids: Optional[List[str]] = None
    ) -> List[Tuple[DocumentChunk, float]]:
        """
        Retrieve relevant context for a query.
        
        Args:
            query: User query
            top_k: Number of top chunks to retrieve
            similarity_threshold: Minimum similarity threshold
            document_ids: Filter by specific document IDs
            
        Returns:
            List of (chunk, similarity_score) tuples sorted by relevance
        """
        try:
            # Use configured defaults if not specified
            top_k = top_k or settings.TOP_K_CHUNKS
            threshold = similarity_threshold or settings.SIMILARITY_THRESHOLD
            
            # Generate query embedding
            query_embedding = await embedding_service.generate_query_embedding(query)
            
            if not query_embedding:
                raise ValueError("Failed to generate query embedding")
            
            # Search vector store
            search_results = await self.vector_store.search(
                query_embedding=query_embedding,
                top_k=top_k * 2,  # Get more candidates for re-ranking
                document_ids=document_ids
            )
            
            # Filter by similarity threshold and re-rank
            filtered_results = [
                (chunk, score) for chunk, score in search_results
                if score >= threshold
            ]
            
            # Sort by similarity score (descending)
            filtered_results.sort(key=lambda x: x[1], reverse=True)
            
            # Return top results
            final_results = filtered_results[:top_k]
            
            logger.info(
                f"Context retrieval completed",
                extra={
                    "query": query[:100] + "..." if len(query) > 100 else query,
                    "results_found": len(final_results),
                    "threshold": threshold,
                    "top_k": top_k
                }
            )
            
            return final_results
            
        except Exception as e:
            logger.error(
                f"Context retrieval failed",
                extra={
                    "query": query[:100] + "..." if len(query) > 100 else query,
                    "error": str(e)
                }
            )
            raise
    
    async def retrieve_context_with_sources(
        self,
        query: str,
        top_k: Optional[int] = None,
        similarity_threshold: Optional[float] = None
    ) -> Tuple[str, List[ChatSource]]:
        """
        Retrieve context and format with sources.
        
        Args:
            query: User query
            top_k: Number of chunks to retrieve
            similarity_threshold: Minimum similarity threshold
            
        Returns:
            Tuple of (formatted_context, list_of_sources)
        """
        # Retrieve relevant chunks
        results = await self.retrieve_context(
            query=query,
            top_k=top_k,
            similarity_threshold=similarity_threshold
        )
        
        if not results:
            return "", []
        
        # Format context
        context_parts = []
        sources = []
        
        for i, (chunk, score) in enumerate(results):
            # Add chunk to context with source reference
            context_parts.append(
                f"[Source {i+1}] {chunk.content}\n"
            )
            
            # Create source attribution
            source = ChatSource(
                document_id=chunk.document_id,
                document_name=chunk.metadata.get("filename", "Unknown"),
                page=chunk.metadata.get("page"),
                chunk_id=chunk.chunk_id,
                relevance_score=float(score),
                content_preview=chunk.content[:200] + "..." if len(chunk.content) > 200 else chunk.content
            )
            sources.append(source)
        
        # Combine context parts
        formatted_context = "\n".join(context_parts)
        
        return formatted_context, sources
    
    async def hybrid_search(
        self,
        query: str,
        keywords: Optional[List[str]] = None,
        semantic_weight: float = 0.7,
        keyword_weight: float = 0.3
    ) -> List[Tuple[DocumentChunk, float]]:
        """
        Perform hybrid search combining semantic and keyword search.
        
        Args:
            query: Search query
            keywords: Explicit keywords to search for
            semantic_weight: Weight for semantic search results
            keyword_weight: Weight for keyword search results
            
        Returns:
            Combined and ranked search results
        """
        # Semantic search
        semantic_results = await self.retrieve_context(query)
        
        # Keyword search (if keywords provided)
        keyword_results = []
        if keywords:
            keyword_results = await self._keyword_search(keywords)
        
        # Combine results using weighted scoring
        combined_scores = {}
        
        # Add semantic results
        for chunk, semantic_score in semantic_results:
            chunk_id = chunk.chunk_id
            combined_scores[chunk_id] = {
                "chunk": chunk,
                "semantic_score": semantic_score,
                "keyword_score": 0.0
            }
        
        # Add keyword results
        for chunk, keyword_score in keyword_results:
            chunk_id = chunk.chunk_id
            if chunk_id in combined_scores:
                combined_scores[chunk_id]["keyword_score"] = keyword_score
            else:
                combined_scores[chunk_id] = {
                    "chunk": chunk,
                    "semantic_score": 0.0,
                    "keyword_score": keyword_score
                }
        
        # Calculate final scores
        final_results = []
        for chunk_data in combined_scores.values():
            chunk = chunk_data["chunk"]
            semantic_score = chunk_data["semantic_score"]
            keyword_score = chunk_data["keyword_score"]
            
            # Weighted combination
            final_score = (
                semantic_weight * semantic_score +
                keyword_weight * keyword_score
            )
            
            final_results.append((chunk, final_score))
        
        # Sort by final score
        final_results.sort(key=lambda x: x[1], reverse=True)
        
        return final_results
    
    async def _keyword_search(
        self,
        keywords: List[str]
    ) -> List[Tuple[DocumentChunk, float]]:
        """
        Perform keyword-based search.
        
        Args:
            keywords: List of keywords to search for
            
        Returns:
            Keyword search results with scores
        """
        # This is a simplified implementation
        # In production, you might use Elasticsearch or similar
        
        results = []
        
        # Get all chunks (simplified - in production, use proper search)
        all_chunks = await self.vector_store.get_all_chunks()
        
        for chunk in all_chunks:
            # Calculate keyword match score
            content_lower = chunk.content.lower()
            match_count = sum(
                1 for keyword in keywords
                if keyword.lower() in content_lower
            )
            
            if match_count > 0:
                # Normalize score by document length and keyword count
                score = match_count / len(keywords) * (1000 / len(chunk.content))
                results.append((chunk, min(score, 1.0)))  # Cap at 1.0
        
        # Sort by score
        results.sort(key=lambda x: x[1], reverse=True)
        
        return results
    
    async def get_document_context(
        self,
        document_id: str,
        query: Optional[str] = None,
        max_tokens: int = 2000
    ) -> str:
        """
        Get context from a specific document.
        
        Args:
            document_id: Document ID to search within
            query: Optional query for relevance ranking
            max_tokens: Maximum tokens to return
            
        Returns:
            Formatted context string
        """
        if query:
            # Use query to get relevant chunks from specific document
            results = await self.retrieve_context(
                query=query,
                document_ids=[document_id]
            )
        else:
            # Get all chunks from document
            chunks = await self.vector_store.get_document_chunks(document_id)
            results = [(chunk, 1.0) for chunk in chunks]
        
        # Build context within token limit
        context_parts = []
        current_tokens = 0
        
        for chunk, score in results:
            chunk_tokens = len(chunk.content.split())  # Rough token estimate
            
            if current_tokens + chunk_tokens > max_tokens:
                break
            
            context_parts.append(chunk.content)
            current_tokens += chunk_tokens
        
        return "\n\n".join(context_parts)
    
    async def rerank_results(
        self,
        query: str,
        results: List[Tuple[DocumentChunk, float]]
    ) -> List[Tuple[DocumentChunk, float]]:
        """
        Re-rank search results using more sophisticated methods.
        
        Args:
            query: Original query
            results: Initial search results
            
        Returns:
            Re-ranked results
        """
        if not results:
            return results
        
        # Apply diversity penalty to avoid similar chunks
        diverse_results = []
        seen_content = set()
        
        for chunk, score in results:
            # Create content signature (first 50 chars)
            content_sig = chunk.content[:50].strip()
            
            if content_sig not in seen_content:
                seen_content.add(content_sig)
                diverse_results.append((chunk, score))
        
        # Apply length penalty (very short or very long chunks are less useful)
        final_results = []
        for chunk, score in diverse_results:
            content_length = len(chunk.content)
            
            # Penalty for very short or very long chunks
            if content_length < 50:  # Too short
                score *= 0.7
            elif content_length > 2000:  # Too long
                score *= 0.8
            
            final_results.append((chunk, score))
        
        # Re-sort by final score
        final_results.sort(key=lambda x: x[1], reverse=True)
        
        return final_results
    
    async def get_retrieval_stats(self) -> dict:
        """
        Get retrieval service statistics.
        
        Returns:
            Dictionary with retrieval statistics
        """
        if not self.vector_store:
            return {"status": "uninitialized"}
        
        try:
            index_stats = await self.vector_store.get_stats()
            
            return {
                "status": "healthy",
                "vector_store_stats": index_stats,
                "config": {
                    "top_k": settings.TOP_K_CHUNKS,
                    "similarity_threshold": settings.SIMILARITY_THRESHOLD,
                    "embedding_dimension": settings.EMBEDDING_DIMENSION
                }
            }
            
        except Exception as e:
            logger.error(f"Failed to get retrieval stats: {e}")
            return {"status": "error", "error": str(e)}


# Global retrieval service instance
retrieval_service = RetrievalService()


# Export the service
__all__ = ["RetrievalService", "retrieval_service"]