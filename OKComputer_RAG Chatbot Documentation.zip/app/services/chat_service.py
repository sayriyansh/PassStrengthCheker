"""
Chat Service

Handles conversation management and session storage.
"""

import json
import time
from typing import Dict, List, Optional
from uuid import uuid4

from app.core.config import settings
from app.core.logging import get_logger
from app.models.chat import ChatMessage, Conversation, MessageRole

logger = get_logger(__name__)


class ChatService:
    """
    Chat service for conversation management.
    
    In production, this would use Redis or a database for persistence.
    For this implementation, we'll use an in-memory store.
    """
    
    def __init__(self):
        """Initialize chat service."""
        self.conversations: Dict[str, Conversation] = {}
        self.redis_client = None
        self._initialize_redis()
    
    def _initialize_redis(self) -> None:
        """Initialize Redis connection for session storage."""
        try:
            if settings.REDIS_URL:
                import redis.asyncio as redis
                self.redis_client = redis.from_url(settings.REDIS_URL)
                logger.info("Redis client initialized for chat service")
            else:
                logger.warning("No Redis URL configured, using in-memory storage")
        except Exception as e:
            logger.warning(f"Failed to initialize Redis client: {e}")
    
    async def create_conversation(self, title: Optional[str] = None) -> str:
        """
        Create a new conversation session.
        
        Args:
            title: Optional conversation title
            
        Returns:
            Session ID
        """
        session_id = str(uuid4())
        
        conversation = Conversation(
            session_id=session_id,
            title=title or f"Conversation {session_id[:8]}",
            messages=[],
            created_at=time.time(),
            updated_at=time.time(),
            metadata={
                "message_count": 0,
                "total_tokens": 0
            }
        )
        
        # Store in memory (and Redis if available)
        self.conversations[session_id] = conversation
        
        if self.redis_client:
            await self._save_to_redis(session_id, conversation)
        
        logger.info(f"Created conversation: {session_id}")
        return session_id
    
    async def get_conversation(self, session_id: str) -> Optional[Conversation]:
        """
        Get conversation by session ID.
        
        Args:
            session_id: Session ID
            
        Returns:
            Conversation or None if not found
        """
        # Try memory first
        if session_id in self.conversations:
            return self.conversations[session_id]
        
        # Try Redis if available
        if self.redis_client:
            conversation = await self._load_from_redis(session_id)
            if conversation:
                # Cache in memory
                self.conversations[session_id] = conversation
                return conversation
        
        return None
    
    async def add_message(
        self,
        session_id: str,
        role: MessageRole,
        content: str,
        sources: Optional[List[dict]] = None,
        metadata: Optional[Dict] = None
    ) -> bool:
        """
        Add message to conversation.
        
        Args:
            session_id: Session ID
            role: Message role (user/assistant)
            content: Message content
            sources: Optional source attributions
            metadata: Optional message metadata
            
        Returns:
            True if successful, False otherwise
        """
        try:
            # Get or create conversation
            conversation = await self.get_conversation(session_id)
            if not conversation:
                session_id = await self.create_conversation()
                conversation = await self.get_conversation(session_id)
            
            # Create message
            message = ChatMessage(
                role=role,
                content=content,
                sources=sources or [],
                metadata=metadata or {}
            )
            
            # Add to conversation
            conversation.messages.append(message)
            conversation.updated_at = time.time()
            
            # Update metadata
            conversation.metadata["message_count"] = len(conversation.messages)
            if metadata and "tokens" in metadata:
                conversation.metadata["total_tokens"] += metadata.get("tokens", 0)
            
            # Save conversation
            self.conversations[session_id] = conversation
            
            if self.redis_client:
                await self._save_to_redis(session_id, conversation)
            
            logger.debug(
                f"Message added to conversation",
                extra={
                    "session_id": session_id,
                    "role": role.value,
                    "message_length": len(content),
                    "sources_count": len(sources) if sources else 0
                }
            )
            
            return True
            
        except Exception as e:
            logger.error(f"Failed to add message: {e}")
            return False
    
    async def list_conversations(
        self,
        limit: int = 50,
        offset: int = 0
    ) -> List[Conversation]:
        """
        List all conversations.
        
        Args:
            limit: Maximum number of conversations to return
            offset: Number of conversations to skip
            
        Returns:
            List of conversations
        """
        conversations = list(self.conversations.values())
        
        # Sort by updated time (most recent first)
        conversations.sort(key=lambda x: x.updated_at, reverse=True)
        
        # Apply pagination
        return conversations[offset:offset + limit]
    
    async def delete_conversation(self, session_id: str) -> bool:
        """
        Delete conversation.
        
        Args:
            session_id: Session ID to delete
            
        Returns:
            True if successful, False otherwise
        """
        try:
            # Remove from memory
            if session_id in self.conversations:
                del self.conversations[session_id]
            
            # Remove from Redis
            if self.redis_client:
                await self.redis_client.delete(f"conversation:{session_id}")
            
            logger.info(f"Conversation deleted: {session_id}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to delete conversation: {e}")
            return False
    
    async def clear_conversation(self, session_id: str) -> bool:
        """
        Clear all messages from conversation.
        
        Args:
            session_id: Session ID
            
        Returns:
            True if successful, False otherwise
        """
        try:
            conversation = await self.get_conversation(session_id)
            if not conversation:
                return False
            
            # Clear messages
            conversation.messages = []
            conversation.updated_at = time.time()
            conversation.metadata["message_count"] = 0
            conversation.metadata["total_tokens"] = 0
            
            # Save
            self.conversations[session_id] = conversation
            
            if self.redis_client:
                await self._save_to_redis(session_id, conversation)
            
            logger.info(f"Conversation cleared: {session_id}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to clear conversation: {e}")
            return False
    
    async def _save_to_redis(self, session_id: str, conversation: Conversation) -> None:
        """Save conversation to Redis."""
        try:
            key = f"conversation:{session_id}"
            value = json.dumps(conversation.model_dump())
            
            await self.redis_client.setex(
                key,
                86400,  # 24 hour expiration
                value
            )
            
        except Exception as e:
            logger.warning(f"Failed to save conversation to Redis: {e}")
    
    async def _load_from_redis(self, session_id: str) -> Optional[Conversation]:
        """Load conversation from Redis."""
        try:
            key = f"conversation:{session_id}"
            value = await self.redis_client.get(key)
            
            if value:
                data = json.loads(value)
                return Conversation(**data)
            
            return None
            
        except Exception as e:
            logger.warning(f"Failed to load conversation from Redis: {e}")
            return None
    
    async def get_conversation_stats(self) -> dict:
        """Get conversation statistics."""
        total_conversations = len(self.conversations)
        total_messages = sum(
            len(conv.messages) for conv in self.conversations.values()
        )
        
        return {
            "total_conversations": total_conversations,
            "total_messages": total_messages,
            "storage_type": "redis" if self.redis_client else "memory",
            "redis_connected": self.redis_client is not None
        }
    
    async def close(self) -> None:
        """Close chat service and save state."""
        try:
            if self.redis_client:
                await self.redis_client.close()
                logger.info("Redis client closed")
        except Exception as e:
            logger.error(f"Error closing chat service: {e}")


# Global chat service instance
chat_service = ChatService()


# Export the service
__all__ = ["ChatService", "chat_service"]