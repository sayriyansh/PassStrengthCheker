"""
Embedding Generation Service

Handles text embedding generation using OpenAI/Kimi API.
"""

import asyncio
from typing import List, Optional

import numpy as np
import openai
from langchain.embeddings import OpenAIEmbeddings

from app.core.config import settings
from app.core.logging import get_logger

logger = get_logger(__name__)


class EmbeddingService:
    """
    Embedding generation service using OpenAI-compatible API.
    """
    
    def __init__(self):
        """Initialize embedding service."""
        self.client = None
        self._initialize_client()
    
    def _initialize_client(self) -> None:
        """Initialize OpenAI client."""
        try:
            # Initialize OpenAI client with custom base URL if needed
            if settings.OPENAI_API_KEY:
                self.client = openai.AsyncOpenAI(
                    api_key=settings.OPENAI_API_KEY,
                    base_url=settings.OPENAI_API_BASE
                )
            elif settings.KIMI_API_KEY:
                self.client = openai.AsyncOpenAI(
                    api_key=settings.KIMI_API_KEY,
                    base_url=settings.KIMI_API_BASE
                )
            else:
                raise ValueError("No API key configured for embeddings")
            
            logger.info(f"Embedding client initialized with model: {settings.EMBEDDING_MODEL}")
            
        except Exception as e:
            logger.error(f"Failed to initialize embedding client: {e}")
            raise
    
    async def generate_embeddings(
        self,
        texts: List[str],
        model: Optional[str] = None
    ) -> List[List[float]]:
        """
        Generate embeddings for a list of texts.
        
        Args:
            texts: List of texts to embed
            model: Embedding model name (uses default if not specified)
            
        Returns:
            List of embedding vectors
            
        Raises:
            Exception: If embedding generation fails
        """
        if not texts:
            return []
        
        if not self.client:
            raise RuntimeError("Embedding client not initialized")
        
        try:
            # Use configured model if not specified
            model_name = model or settings.EMBEDDING_MODEL
            
            # Generate embeddings in batches for efficiency
            batch_size = 32
            all_embeddings = []
            
            for i in range(0, len(texts), batch_size):
                batch_texts = texts[i:i + batch_size]
                
                # Generate embeddings for batch
                response = await self.client.embeddings.create(
                    model=model_name,
                    input=batch_texts,
                    encoding_format="float"
                )
                
                # Extract embeddings
                batch_embeddings = [
                    item.embedding for item in response.data
                ]
                all_embeddings.extend(batch_embeddings)
                
                logger.debug(
                    f"Generated embeddings for batch",
                    extra={
                        "batch_size": len(batch_texts),
                        "total_processed": len(all_embeddings),
                        "model": model_name
                    }
                )
            
            logger.info(
                f"Embeddings generated successfully",
                extra={
                    "total_texts": len(texts),
                    "embedding_dimension": len(all_embeddings[0]) if all_embeddings else 0,
                    "model": model_name
                }
            )
            
            return all_embeddings
            
        except Exception as e:
            logger.error(
                f"Embedding generation failed",
                extra={
                    "error": str(e),
                    "texts_count": len(texts),
                    "model": model_name
                }
            )
            raise
    
    async def generate_single_embedding(
        self,
        text: str,
        model: Optional[str] = None
    ) -> List[float]:
        """
        Generate embedding for a single text.
        
        Args:
            text: Text to embed
            model: Embedding model name
            
        Returns:
            Embedding vector
        """
        embeddings = await self.generate_embeddings([text], model)
        return embeddings[0] if embeddings else []
    
    async def generate_query_embedding(
        self,
        query: str,
        model: Optional[str] = None
    ) -> List[float]:
        """
        Generate embedding for search query.
        
        Args:
            query: Search query
            model: Embedding model name
            
        Returns:
            Query embedding vector
        """
        # For queries, we might want to apply preprocessing
        # like removing stop words or query expansion
        processed_query = self._preprocess_query(query)
        
        return await self.generate_single_embedding(processed_query, model)
    
    def _preprocess_query(self, query: str) -> str:
        """
        Preprocess query text for better embedding.
        
        Args:
            query: Raw query text
            
        Returns:
            Processed query text
        """
        # Basic preprocessing - can be enhanced
        query = query.strip()
        
        # Convert to lowercase for consistency
        query = query.lower()
        
        # Remove excessive whitespace
        import re
        query = re.sub(r'\s+', ' ', query)
        
        return query
    
    async def calculate_similarity(
        self,
        embedding1: List[float],
        embedding2: List[float]
    ) -> float:
        """
        Calculate cosine similarity between two embeddings.
        
        Args:
            embedding1: First embedding vector
            embedding2: Second embedding vector
            
        Returns:
            Cosine similarity score (-1 to 1)
        """
        # Convert to numpy arrays
        vec1 = np.array(embedding1)
        vec2 = np.array(embedding2)
        
        # Calculate cosine similarity
        dot_product = np.dot(vec1, vec2)
        norm1 = np.linalg.norm(vec1)
        norm2 = np.linalg.norm(vec2)
        
        if norm1 == 0 or norm2 == 0:
            return 0.0
        
        return dot_product / (norm1 * norm2)
    
    async def batch_similarity_search(
        self,
        query_embedding: List[float],
        candidate_embeddings: List[List[float]],
        top_k: int = 10
    ) -> List[Tuple[int, float]]:
        """
        Find top-k most similar embeddings to query.
        
        Args:
            query_embedding: Query embedding vector
            candidate_embeddings: List of candidate embeddings
            top_k: Number of top results to return
            
        Returns:
            List of (index, similarity_score) tuples
        """
        similarities = []
        
        for i, candidate in enumerate(candidate_embeddings):
            similarity = await self.calculate_similarity(
                query_embedding, candidate
            )
            similarities.append((i, similarity))
        
        # Sort by similarity score (descending)
        similarities.sort(key=lambda x: x[1], reverse=True)
        
        return similarities[:top_k]
    
    async def get_embedding_stats(
        self,
        embeddings: List[List[float]]
    ) -> dict:
        """
        Get statistics about embeddings.
        
        Args:
            embeddings: List of embedding vectors
            
        Returns:
            Dictionary with embedding statistics
        """
        if not embeddings:
            return {}
        
        # Convert to numpy array
        embeddings_array = np.array(embeddings)
        
        return {
            "count": len(embeddings),
            "dimension": len(embeddings[0]),
            "mean_vector": np.mean(embeddings_array, axis=0).tolist(),
            "std_vector": np.std(embeddings_array, axis=0).tolist(),
            "average_norm": float(np.mean(np.linalg.norm(embeddings_array, axis=1))),
            "min_norm": float(np.min(np.linalg.norm(embeddings_array, axis=1))),
            "max_norm": float(np.max(np.linalg.norm(embeddings_array, axis=1)))
        }


# Global embedding service instance
embedding_service = EmbeddingService()


# Export the service
__all__ = ["EmbeddingService", "embedding_service"]