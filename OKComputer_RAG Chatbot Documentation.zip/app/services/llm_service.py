"""
LLM Service

Handles LLM integration for response generation with context-bound constraints.
"""

import asyncio
from typing import AsyncGenerator, List, Optional

import openai
from langchain.chains import ConversationalRetrievalChain
from langchain.memory import ConversationBufferMemory
from langchain.prompts import PromptTemplate
from langchain.schema import Document as LangchainDocument

from app.core.config import settings
from app.core.logging import get_logger

logger = get_logger(__name__)


class LLMService:
    """
    LLM service for context-bound response generation.
    """
    
    def __init__(self):
        """Initialize LLM service."""
        self.client = None
        self._initialize_client()
        self._setup_prompt_templates()
    
    def _initialize_client(self) -> None:
        """Initialize OpenAI client."""
        try:
            if settings.OPENAI_API_KEY:
                self.client = openai.AsyncOpenAI(
                    api_key=settings.OPENAI_API_KEY,
                    base_url=settings.OPENAI_API_BASE
                )
            elif settings.KIMI_API_KEY:
                self.client = openai.AsyncOpenAI(
                    api_key=settings.KIMI_API_KEY,
                    base_url=settings.KIMI_API_BASE
                )
            else:
                raise ValueError("No API key configured for LLM")
            
            logger.info(f"LLM client initialized with model: {settings.LLM_MODEL}")
            
        except Exception as e:
            logger.error(f"Failed to initialize LLM client: {e}")
            raise
    
    def _setup_prompt_templates(self) -> None:
        """Setup prompt templates for different use cases."""
        
        # Main RAG prompt template
        self.rag_prompt_template = PromptTemplate(
            input_variables=["context", "question"],
            template="""
You are a helpful assistant that answers questions based strictly on the provided context. 
You must not use any external knowledge or make assumptions beyond what is given in the context.

Context:
{context}

Question: {question}

Answer based only on the provided context. If the answer cannot be found in the context, 
say "information not available in provided data". Use small letters only and maintain a 
professional tone.

Answer:"""
        )
        
        # Conversation prompt template
        self.conversation_prompt_template = PromptTemplate(
            input_variables=["context", "question", "chat_history"],
            template="""
You are a helpful assistant that answers questions based strictly on the provided context. 
You must not use any external knowledge or make assumptions beyond what is given in the context.

Previous conversation:
{chat_history}

Context:
{context}

Question: {question}

Answer based only on the provided context. If the answer cannot be found in the context, 
say "information not available in provided data". Use small letters only and maintain a 
professional tone.

Answer:"""
        )
        
        # Summarization prompt template
        self.summarization_prompt_template = PromptTemplate(
            input_variables=["context"],
            template="""
Summarize the following text in a concise manner, highlighting the key points:

{context}

Summary:"""
        )
    
    async def generate_response(
        self,
        query: str,
        context: str,
        conversation_history: Optional[List[dict]] = None
    ) -> str:
        """
        Generate response using LLM with strict context bounds.
        
        Args:
            query: User query
            context: Retrieved context
            conversation_history: Optional conversation history
            
        Returns:
            Generated response
            
        Raises:
            Exception: If response generation fails
        """
        if not self.client:
            raise RuntimeError("LLM client not initialized")
        
        try:
            # Validate context
            if not context.strip():
                return "information not available in provided data"
            
            # Build conversation history if provided
            chat_history = ""
            if conversation_history:
                for msg in conversation_history[-5:]:  # Last 5 messages
                    role = msg.get("role", "user")
                    content = msg.get("content", "")
                    chat_history += f"{role}: {content}\n"
            
            # Prepare prompt
            if chat_history:
                prompt = self.conversation_prompt_template.format(
                    context=context,
                    question=query,
                    chat_history=chat_history
                )
            else:
                prompt = self.rag_prompt_template.format(
                    context=context,
                    question=query
                )
            
            # Generate response
            response = await self.client.chat.completions.create(
                model=settings.LLM_MODEL,
                messages=[
                    {"role": "user", "content": prompt}
                ],
                temperature=settings.LLM_TEMPERATURE,
                max_tokens=settings.LLM_MAX_TOKENS,
                stream=False
            )
            
            # Extract answer
            answer = response.choices[0].message.content.strip()
            
            # Post-process answer to ensure compliance
            answer = self._post_process_answer(answer, context)
            
            logger.info(
                f"Response generated successfully",
                extra={
                    "query": query[:100] + "..." if len(query) > 100 else query,
                    "answer_length": len(answer),
                    "model": settings.LLM_MODEL,
                    "tokens_used": response.usage.total_tokens if response.usage else 0
                }
            )
            
            return answer
            
        except Exception as e:
            logger.error(
                f"Response generation failed",
                extra={
                    "query": query[:100] + "..." if len(query) > 100 else query,
                    "error": str(e)
                }
            )
            raise
    
    async def generate_streaming_response(
        self,
        query: str,
        context: str,
        conversation_history: Optional[List[dict]] = None
    ) -> AsyncGenerator[str, None]:
        """
        Generate streaming response using LLM.
        
        Args:
            query: User query
            context: Retrieved context
            conversation_history: Optional conversation history
            
        Yields:
            Response chunks
        """
        if not self.client:
            raise RuntimeError("LLM client not initialized")
        
        try:
            # Build conversation history if provided
            chat_history = ""
            if conversation_history:
                for msg in conversation_history[-5:]:
                    role = msg.get("role", "user")
                    content = msg.get("content", "")
                    chat_history += f"{role}: {content}\n"
            
            # Prepare prompt
            if chat_history:
                prompt = self.conversation_prompt_template.format(
                    context=context,
                    question=query,
                    chat_history=chat_history
                )
            else:
                prompt = self.rag_prompt_template.format(
                    context=context,
                    question=query
                )
            
            # Generate streaming response
            stream = await self.client.chat.completions.create(
                model=settings.LLM_MODEL,
                messages=[
                    {"role": "user", "content": prompt}
                ],
                temperature=settings.LLM_TEMPERATURE,
                max_tokens=settings.LLM_MAX_TOKENS,
                stream=True
            )
            
            async for chunk in stream:
                if chunk.choices and chunk.choices[0].delta.content:
                    content = chunk.choices[0].delta.content
                    yield content
            
            logger.info(
                f"Streaming response completed",
                extra={
                    "query": query[:100] + "..." if len(query) > 100 else query,
                    "model": settings.LLM_MODEL
                }
            )
            
        except Exception as e:
            logger.error(
                f"Streaming response failed",
                extra={
                    "query": query[:100] + "..." if len(query) > 100 else query,
                    "error": str(e)
                }
            )
            raise
    
    def _post_process_answer(self, answer: str, context: str) -> str:
        """
        Post-process answer to ensure context compliance.
        
        Args:
            answer: Raw LLM answer
            context: Retrieved context
            
        Returns:
            Post-processed answer
        """
        # Convert to lowercase (as per requirements)
        answer = answer.lower()
        
        # Check if answer contains hallucination indicators
        hallucination_phrases = [
            "i think",
            "i believe",
            "probably",
            "maybe",
            "perhaps",
            "in my opinion",
            "it seems",
            "based on my knowledge"
        ]
        
        # If answer seems to contain hallucinations, return safe response
        for phrase in hallucination_phrases:
            if phrase in answer:
                return "information not available in provided data"
        
        # Ensure answer doesn't reference external knowledge
        context_keywords = set(context.lower().split())
        answer_keywords = set(answer.split())
        
        # If answer contains many words not in context, it might be hallucinated
        external_words = answer_keywords - context_keywords
        if len(external_words) > len(answer_keywords) * 0.5:  # More than 50% new words
            return "information not available in provided data"
        
        return answer
    
    async def summarize_context(
        self,
        context: str,
        max_length: int = 500
    ) -> str:
        """
        Summarize long context for token optimization.
        
        Args:
            context: Context to summarize
            max_length: Maximum summary length in tokens
            
        Returns:
            Summarized context
        """
        if not self.client:
            raise RuntimeError("LLM client not initialized")
        
        try:
            # Use summarization prompt
            prompt = self.summarization_prompt_template.format(
                context=context
            )
            
            response = await self.client.chat.completions.create(
                model=settings.LLM_MODEL,
                messages=[
                    {"role": "user", "content": prompt}
                ],
                temperature=0.1,
                max_tokens=max_length
            )
            
            summary = response.choices[0].message.content.strip()
            
            logger.info(
                f"Context summarized",
                extra={
                    "original_length": len(context),
                    "summary_length": len(summary),
                    "tokens_saved": response.usage.total_tokens if response.usage else 0
                }
            )
            
            return summary
            
        except Exception as e:
            logger.error(f"Context summarization failed: {e}")
            # Return original context if summarization fails
            return context
    
    async def validate_context_relevance(
        self,
        query: str,
        context: str
    ) -> float:
        """
        Validate if context is relevant to the query.
        
        Args:
            query: User query
            context: Retrieved context
            
        Returns:
            Relevance score (0-1)
        """
        try:
            # Simple keyword overlap check
            query_words = set(query.lower().split())
            context_words = set(context.lower().split())
            
            overlap = len(query_words.intersection(context_words))
            total_unique = len(query_words.union(context_words))
            
            if total_unique == 0:
                return 0.0
            
            relevance_score = overlap / len(query_words) if query_words else 0.0
            
            logger.debug(
                f"Context relevance calculated",
                extra={
                    "query": query[:50] + "..." if len(query) > 50 else query,
                    "relevance_score": relevance_score,
                    "overlap_words": overlap
                }
            )
            
            return relevance_score
            
        except Exception as e:
            logger.error(f"Context relevance validation failed: {e}")
            return 0.0
    
    async def get_llm_stats(self) -> dict:
        """
        Get LLM service statistics.
        
        Returns:
            Dictionary with LLM statistics
        """
        if not self.client:
            return {"status": "uninitialized"}
        
        return {
            "status": "healthy",
            "model": settings.LLM_MODEL,
            "config": {
                "temperature": settings.LLM_TEMPERATURE,
                "max_tokens": settings.LLM_MAX_TOKENS,
                "streaming": settings.LLM_STREAMING
            },
            "api_base": settings.llm_api_base
        }


# Global LLM service instance
llm_service = LLMService()


# Export the service
__all__ = ["LLMService", "llm_service"]