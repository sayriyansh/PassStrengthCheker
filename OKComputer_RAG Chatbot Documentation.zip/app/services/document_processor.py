"""
Document Processing Service

Handles document parsing, text extraction, cleaning, and chunking.
"""

import asyncio
from pathlib import Path
from typing import List, Optional, Tuple
from uuid import UUID

import pandas as pd
from langchain.document_loaders import (
    CSVLoader,
    Docx2txtLoader,
    PyPDFLoader,
    TextLoader
)
from langchain.schema import Document as LangchainDocument
from langchain.text_splitter import RecursiveCharacterTextSplitter

from app.core.config import settings
from app.core.logging import get_logger
from app.models.document import (
    Document,
    DocumentChunk,
    DocumentMetadata,
    DocumentType,
    ProcessingStats
)
from app.utils.file_handlers import get_file_handler
from app.utils.text_processing import clean_text, extract_text_features

logger = get_logger(__name__)


class DocumentProcessor:
    """
    Document processing service for parsing, cleaning, and chunking documents.
    """
    
    def __init__(self):
        """Initialize document processor."""
        self.text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=settings.CHUNK_SIZE,
            chunk_overlap=settings.CHUNK_OVERLAP,
            length_function=len,
            separators=["\n\n", "\n", ". ", " ", ""]
        )
    
    async def process_document(
        self,
        file_path: Path,
        document_id: UUID,
        original_filename: str
    ) -> Tuple[Document, List[DocumentChunk]]:
        """
        Process a document from file path.
        
        Args:
            file_path: Path to the document file
            document_id: Unique document identifier
            original_filename: Original filename
            
        Returns:
            Tuple of (Document metadata, List of chunks)
            
        Raises:
            ValueError: If document type is not supported
            Exception: If processing fails
        """
        try:
            # Determine document type
            doc_type = self._get_document_type(original_filename)
            
            # Parse document
            langchain_docs = await self._parse_document(file_path, doc_type)
            
            if not langchain_docs:
                raise ValueError("No content extracted from document")
            
            # Create document metadata
            document = Document(
                document_id=document_id,
                filename=original_filename,
                file_size=file_path.stat().st_size,
                document_type=doc_type,
                metadata=await self._extract_metadata(langchain_docs, original_filename),
                processing_stats=ProcessingStats(total_chunks=len(langchain_docs))
            )
            
            # Process chunks
            chunks = await self._create_chunks(langchain_docs, document_id)
            
            logger.info(
                f"Document processing completed",
                extra={
                    "document_id": str(document_id),
                    "filename": original_filename,
                    "chunks_created": len(chunks),
                    "doc_type": doc_type.value
                }
            )
            
            return document, chunks
            
        except Exception as e:
            logger.error(
                f"Document processing failed",
                extra={
                    "document_id": str(document_id),
                    "filename": original_filename,
                    "error": str(e)
                }
            )
            raise
    
    def _get_document_type(self, filename: str) -> DocumentType:
        """
        Determine document type from filename.
        
        Args:
            filename: Document filename
            
        Returns:
            Document type enum
        """
        suffix = Path(filename).suffix.lower()
        
        if suffix == ".pdf":
            return DocumentType.PDF
        elif suffix == ".txt":
            return DocumentType.TXT
        elif suffix in [".docx", ".doc"]:
            return DocumentType.DOCX
        elif suffix == ".csv":
            return DocumentType.CSV
        else:
            raise ValueError(f"Unsupported file type: {suffix}")
    
    async def _parse_document(
        self,
        file_path: Path,
        doc_type: DocumentType
    ) -> List[LangchainDocument]:
        """
        Parse document based on type.
        
        Args:
            file_path: Path to document file
            doc_type: Document type
            
        Returns:
            List of Langchain documents
        """
        # Run in thread pool to avoid blocking
        loop = asyncio.get_event_loop()
        
        if doc_type == DocumentType.PDF:
            return await loop.run_in_executor(
                None, self._parse_pdf, file_path
            )
        elif doc_type == DocumentType.TXT:
            return await loop.run_in_executor(
                None, self._parse_txt, file_path
            )
        elif doc_type == DocumentType.DOCX:
            return await loop.run_in_executor(
                None, self._parse_docx, file_path
            )
        elif doc_type == DocumentType.CSV:
            return await loop.run_in_executor(
                None, self._parse_csv, file_path
            )
        else:
            raise ValueError(f"Unsupported document type: {doc_type}")
    
    def _parse_pdf(self, file_path: Path) -> List[LangchainDocument]:
        """Parse PDF document."""
        loader = PyPDFLoader(str(file_path))
        return loader.load()
    
    def _parse_txt(self, file_path: Path) -> List[LangchainDocument]:
        """Parse text document."""
        loader = TextLoader(str(file_path), encoding="utf-8")
        return loader.load()
    
    def _parse_docx(self, file_path: Path) -> List[LangchainDocument]:
        """Parse DOCX document."""
        loader = Docx2txtLoader(str(file_path))
        return loader.load()
    
    def _parse_csv(self, file_path: Path) -> List[LangchainDocument]:
        """Parse CSV document."""
        # Custom CSV parsing with structured format
        df = pd.read_csv(file_path)
        
        documents = []
        for idx, row in df.iterrows():
            # Convert row to readable text
            row_text = "\n".join([f"{col}: {val}" for col, val in row.items()])
            
            doc = LangchainDocument(
                page_content=row_text,
                metadata={
                    "source": str(file_path),
                    "row": idx,
                    "total_rows": len(df)
                }
            )
            documents.append(doc)
        
        return documents
    
    async def _extract_metadata(
        self,
        docs: List[LangchainDocument],
        filename: str
    ) -> DocumentMetadata:
        """
        Extract metadata from parsed documents.
        
        Args:
            docs: Parsed Langchain documents
            filename: Original filename
            
        Returns:
            Document metadata
        """
        # Combine all text for analysis
        full_text = "\n".join([doc.page_content for doc in docs])
        
        # Extract text features
        features = extract_text_features(full_text)
        
        # Extract PDF metadata if available
        pdf_metadata = {}
        if docs and docs[0].metadata:
            pdf_metadata = docs[0].metadata
        
        return DocumentMetadata(
            title=pdf_metadata.get("title") or Path(filename).stem,
            author=pdf_metadata.get("author"),
            subject=pdf_metadata.get("subject"),
            keywords=pdf_metadata.get("keywords", []),
            language=features.get("language"),
            page_count=len(docs),
            word_count=features.get("word_count", 0),
            character_count=len(full_text),
            created_date=pdf_metadata.get("creation_date"),
            modified_date=pdf_metadata.get("mod_date")
        )
    
    async def _create_chunks(
        self,
        docs: List[LangchainDocument],
        document_id: UUID
    ) -> List[DocumentChunk]:
        """
        Create document chunks from parsed documents.
        
        Args:
            docs: Parsed Langchain documents
            document_id: Document ID
            
        Returns:
            List of document chunks
        """
        chunks = []
        chunk_index = 0
        
        for doc in docs:
            # Clean and prepare text
            cleaned_text = clean_text(doc.page_content)
            
            # Split into chunks
            text_chunks = self.text_splitter.split_text(cleaned_text)
            
            # Create document chunks
            for i, chunk_content in enumerate(text_chunks):
                chunk = DocumentChunk(
                    chunk_id=f"{document_id}_{chunk_index}",
                    document_id=document_id,
                    content=chunk_content,
                    chunk_index=chunk_index,
                    start_position=i * settings.CHUNK_SIZE,
                    end_position=min((i + 1) * settings.CHUNK_SIZE, len(cleaned_text)),
                    metadata={
                        "page": doc.metadata.get("page", 0),
                        "source": doc.metadata.get("source", "unknown"),
                        **doc.metadata
                    }
                )
                chunks.append(chunk)
                chunk_index += 1
        
        return chunks
    
    async def rechunk_document(
        self,
        chunks: List[DocumentChunk],
        new_chunk_size: int,
        new_overlap: int
    ) -> List[DocumentChunk]:
        """
        Rechunk existing document chunks with new parameters.
        
        Args:
            chunks: Existing chunks
            new_chunk_size: New chunk size
            new_overlap: New overlap size
            
        Returns:
            New list of chunks
        """
        # Combine all chunk content
        full_text = "\n".join([chunk.content for chunk in chunks])
        
        # Create new text splitter
        new_splitter = RecursiveCharacterTextSplitter(
            chunk_size=new_chunk_size,
            chunk_overlap=new_overlap,
            length_function=len,
            separators=["\n\n", "\n", ". ", " ", ""]
        )
        
        # Split text
        new_text_chunks = new_splitter.split_text(full_text)
        
        # Create new chunks
        new_chunks = []
        document_id = chunks[0].document_id if chunks else None
        
        for i, chunk_content in enumerate(new_text_chunks):
            chunk = DocumentChunk(
                chunk_id=f"{document_id}_rechunk_{i}",
                document_id=document_id,
                content=chunk_content,
                chunk_index=i,
                start_position=i * new_chunk_size,
                end_position=min((i + 1) * new_chunk_size, len(full_text)),
                metadata={"rechunked": True}
            )
            new_chunks.append(chunk)
        
        return new_chunks


# Global document processor instance
document_processor = DocumentProcessor()


# Export the processor
__all__ = ["DocumentProcessor", "document_processor"]