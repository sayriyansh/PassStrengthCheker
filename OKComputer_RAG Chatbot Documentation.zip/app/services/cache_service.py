"""
Cache Service

Redis-based caching layer for performance optimization.
"""

import json
import time
from typing import Any, Optional

from app.core.config import settings
from app.core.logging import get_logger

logger = get_logger(__name__)


class CacheService:
    """
    Redis-based cache service for performance optimization.
    
    Caches:
    - Query results
    - Embeddings
    - LLM responses
    - Session data
    """
    
    def __init__(self):
        """Initialize cache service."""
        self.redis_client = None
        self._initialize_redis()
    
    def _initialize_redis(self) -> None:
        """Initialize Redis connection."""
        try:
            if settings.REDIS_URL:
                import redis.asyncio as redis
                self.redis_client = redis.from_url(
                    settings.REDIS_URL,
                    decode_responses=True
                )
                logger.info("Redis cache client initialized")
            else:
                logger.warning("No Redis URL configured, caching disabled")
        except Exception as e:
            logger.warning(f"Failed to initialize Redis cache: {e}")
    
    def _generate_cache_key(self, prefix: str, *args) -> str:
        """
        Generate cache key from prefix and arguments.
        
        Args:
            prefix: Cache key prefix
            *args: Arguments to include in key
            
        Returns:
            Cache key string
        """
        key_parts = [prefix]
        for arg in args:
            if isinstance(arg, (dict, list)):
                key_parts.append(json.dumps(arg, sort_keys=True))
            else:
                key_parts.append(str(arg))
        
        return ":".join(key_parts)
    
    async def get(self, key: str) -> Optional[Any]:
        """
        Get value from cache.
        
        Args:
            key: Cache key
            
        Returns:
            Cached value or None if not found
        """
        if not self.redis_client:
            return None
        
        try:
            value = await self.redis_client.get(key)
            if value:
                # Try to deserialize JSON
                try:
                    return json.loads(value)
                except json.JSONDecodeError:
                    return value
            return None
            
        except Exception as e:
            logger.warning(f"Cache get failed for key {key}: {e}")
            return None
    
    async def set(
        self,
        key: str,
        value: Any,
        expiration: int = 3600
    ) -> bool:
        """
        Set value in cache.
        
        Args:
            key: Cache key
            value: Value to cache
            expiration: Expiration time in seconds
            
        Returns:
            True if successful, False otherwise
        """
        if not self.redis_client:
            return False
        
        try:
            # Serialize value if needed
            if isinstance(value, (dict, list)):
                serialized = json.dumps(value)
            else:
                serialized = str(value)
            
            await self.redis_client.setex(key, expiration, serialized)
            return True
            
        except Exception as e:
            logger.warning(f"Cache set failed for key {key}: {e}")
            return False
    
    async def delete(self, key: str) -> bool:
        """
        Delete value from cache.
        
        Args:
            key: Cache key
            
        Returns:
            True if successful, False otherwise
        """
        if not self.redis_client:
            return False
        
        try:
            await self.redis_client.delete(key)
            return True
            
        except Exception as e:
            logger.warning(f"Cache delete failed for key {key}: {e}")
            return False
    
    async def exists(self, key: str) -> bool:
        """
        Check if key exists in cache.
        
        Args:
            key: Cache key
            
        Returns:
            True if key exists, False otherwise
        """
        if not self.redis_client:
            return False
        
        try:
            return bool(await self.redis_client.exists(key))
            
        except Exception as e:
            logger.warning(f"Cache exists check failed for key {key}: {e}")
            return False
    
    async def clear_pattern(self, pattern: str) -> int:
        """
        Clear all keys matching pattern.
        
        Args:
            pattern: Key pattern (supports wildcards)
            
        Returns:
            Number of keys deleted
        """
        if not self.redis_client:
            return 0
        
        try:
            keys = await self.redis_client.keys(pattern)
            if keys:
                await self.redis_client.delete(*keys)
            return len(keys)
            
        except Exception as e:
            logger.warning(f"Cache clear pattern failed for {pattern}: {e}")
            return 0
    
    # Specific cache methods
    async def get_query_result(self, query: str) -> Optional[dict]:
        """Get cached query result."""
        key = self._generate_cache_key("query", query)
        return await self.get(key)
    
    async def set_query_result(self, query: str, result: dict, expiration: int = 1800) -> bool:
        """Cache query result (30 minutes default)."""
        key = self._generate_cache_key("query", query)
        return await self.set(key, result, expiration)
    
    async def get_embedding(self, text: str) -> Optional[list]:
        """Get cached embedding."""
        key = self._generate_cache_key("embedding", text)
        return await self.get(key)
    
    async def set_embedding(self, text: str, embedding: list, expiration: int = 86400) -> bool:
        """Cache embedding (24 hours default)."""
        key = self._generate_cache_key("embedding", text)
        return await self.set(key, embedding, expiration)
    
    async def get_llm_response(self, prompt: str) -> Optional[str]:
        """Get cached LLM response."""
        key = self._generate_cache_key("llm_response", prompt)
        return await self.get(key)
    
    async def set_llm_response(self, prompt: str, response: str, expiration: int = 3600) -> bool:
        """Cache LLM response (1 hour default)."""
        key = self._generate_cache_key("llm_response", prompt)
        return await self.set(key, response, expiration)
    
    async def get_document_chunks(self, document_id: str) -> Optional[list]:
        """Get cached document chunks."""
        key = self._generate_cache_key("doc_chunks", document_id)
        return await self.get(key)
    
    async def set_document_chunks(self, document_id: str, chunks: list, expiration: int = 7200) -> bool:
        """Cache document chunks (2 hours default)."""
        key = self._generate_cache_key("doc_chunks", document_id)
        return await self.set(key, chunks, expiration)
    
    async def invalidate_document(self, document_id: str) -> bool:
        """Invalidate all caches related to a document."""
        try:
            # Clear document chunks
            await self.delete(f"doc_chunks:{document_id}")
            
            # Clear query results that might reference this document
            # In production, you might want to track which queries reference which documents
            await self.clear_pattern("query:*")
            
            logger.info(f"Cache invalidated for document: {document_id}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to invalidate document cache: {e}")
            return False
    
    async def get_stats(self) -> dict:
        """Get cache statistics."""
        if not self.redis_client:
            return {"status": "disabled"}
        
        try:
            info = await self.redis_client.info()
            
            return {
                "status": "healthy",
                "connected": True,
                "keys": await self.redis_client.dbsize(),
                "used_memory_mb": info.get("used_memory_rss", 0) / (1024 * 1024),
                "connected_clients": info.get("connected_clients", 0),
                "total_commands_processed": info.get("total_commands_processed", 0),
                "keyspace_hits": info.get("keyspace_hits", 0),
                "keyspace_misses": info.get("keyspace_misses", 0)
            }
            
        except Exception as e:
            return {
                "status": "error",
                "error": str(e)
            }
    
    async def clear_all(self) -> bool:
        """Clear all cached data."""
        if not self.redis_client:
            return False
        
        try:
            await self.redis_client.flushdb()
            logger.info("All cache cleared")
            return True
            
        except Exception as e:
            logger.error(f"Failed to clear all cache: {e}")
            return False
    
    async def close(self) -> None:
        """Close cache service."""
        try:
            if self.redis_client:
                await self.redis_client.close()
                logger.info("Cache service closed")
        except Exception as e:
            logger.error(f"Error closing cache service: {e}")


# Global cache service instance
cache_service = CacheService()


# Export the service
__all__ = ["CacheService", "cache_service"]