"""
FastAPI Application Entry Point

Main application initialization and lifecycle management.
"""

import asyncio
from contextlib import asynccontextmanager
from typing import AsyncGenerator

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware

from app.api.v1.api import api_router
from app.core.config import settings
from app.core.logging import setup_logging
from app.db.vector_store import VectorStore
from app.db.session_store import SessionStore


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """
    Application lifespan event handler.
    
    Handles startup and shutdown events.
    """
    # Startup
    app.state.logger = setup_logging()
    app.state.logger.info("Starting RAG Chatbot application...")
    
    # Initialize database connections
    try:
        app.state.vector_store = VectorStore()
        app.state.session_store = SessionStore()
        await app.state.vector_store.initialize()
        await app.state.session_store.initialize()
        app.state.logger.info("Database connections established")
    except Exception as e:
        app.state.logger.error(f"Failed to initialize databases: {e}")
        raise
    
    yield
    
    # Shutdown
    app.state.logger.info("Shutting down RAG Chatbot application...")
    
    # Close database connections
    try:
        if hasattr(app.state, 'vector_store'):
            await app.state.vector_store.close()
        if hasattr(app.state, 'session_store'):
            await app.state.session_store.close()
        app.state.logger.info("Database connections closed")
    except Exception as e:
        app.state.logger.error(f"Error during shutdown: {e}")


def create_application() -> FastAPI:
    """
    Create and configure the FastAPI application.
    
    Returns:
        Configured FastAPI application instance
    """
    app = FastAPI(
        title=settings.APP_NAME,
        version=settings.APP_VERSION,
        description="""
        Enterprise RAG Chatbot API
        
        ## Features
        
        - **Multi-format document processing**: PDF, TXT, DOCX, CSV
        - **Zero hallucination**: Strict context-bound responses
        - **Real-time semantic search**: FAISS-powered retrieval
        - **Conversation memory**: Context-aware interactions
        - **Source attribution**: Every answer includes references
        
        ## Usage
        
        1. Upload documents using the `/documents/upload` endpoint
        2. Start conversations using the `/chat` endpoint
        3. View conversation history and sources
        """,
        lifespan=lifespan,
        docs_url="/docs" if settings.DEBUG else None,
        redoc_url="/redoc" if settings.DEBUG else None,
    )
    
    # Add middleware
    setup_middleware(app)
    
    # Include API router
    app.include_router(api_router, prefix="/api/v1")
    
    # Add exception handlers
    setup_exception_handlers(app)
    
    return app


def setup_middleware(app: FastAPI) -> None:
    """
    Configure application middleware.
    
    Args:
        app: FastAPI application instance
    """
    # CORS middleware
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.CORS_ORIGINS,
        allow_credentials=True,
        allow_methods=["GET", "POST", "PUT", "DELETE"],
        allow_headers=["*"],
    )
    
    # GZip compression
    app.add_middleware(GZipMiddleware, minimum_size=1000)
    
    # Trusted host middleware
    app.add_middleware(
        TrustedHostMiddleware,
        allowed_hosts=settings.ALLOWED_HOSTS,
    )


def setup_exception_handlers(app: FastAPI) -> None:
    """
    Configure custom exception handlers.
    
    Args:
        app: FastAPI application instance
    """
    
    @app.exception_handler(ValueError)
    async def value_error_handler(request, exc: ValueError):
        return {
            "error": "Invalid value",
            "message": str(exc),
            "status_code": 400
        }
    
    @app.exception_handler(Exception)
    async def general_exception_handler(request, exc: Exception):
        app.state.logger.error(f"Unhandled exception: {exc}")
        return {
            "error": "Internal server error",
            "message": "An unexpected error occurred",
            "status_code": 500
        }


# Create application instance
app = create_application()


@app.get("/", tags=["Root"])
async def root():
    """
    Root endpoint.
    
    Returns:
        Application information
    """
    return {
        "name": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "description": "Enterprise RAG Chatbot with Zero Hallucination",
        "docs": "/docs" if settings.DEBUG else None
    }


@app.get("/health", tags=["Health"])
async def health_check():
    """
    Health check endpoint.
    
    Returns:
        Health status
    """
    return {
        "status": "healthy",
        "version": settings.APP_VERSION
    }


if __name__ == "__main__":
    import uvicorn
    
    uvicorn.run(
        "app.main:app",
        host=settings.APP_HOST,
        port=settings.APP_PORT,
        reload=settings.APP_RELOAD,
        log_level=settings.LOG_LEVEL.lower()
    )