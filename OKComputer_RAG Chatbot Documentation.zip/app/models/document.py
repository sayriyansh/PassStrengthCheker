"""
Document Data Models

Pydantic models for document processing and management.
"""

from datetime import datetime
from enum import Enum
from typing import Dict, List, Optional
from uuid import UUID, uuid4

from pydantic import BaseModel, Field, HttpUrl


class DocumentStatus(str, Enum):
    """Document processing status."""
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"


class DocumentType(str, Enum):
    """Supported document types."""
    PDF = "pdf"
    TXT = "txt"
    DOCX = "docx"
    CSV = "csv"


class ProcessingStats(BaseModel):
    """Document processing statistics."""
    total_chunks: int = Field(default=0, description="Total number of chunks")
    processing_time: float = Field(default=0.0, description="Processing time in seconds")
    embedding_time: float = Field(default=0.0, description="Embedding generation time")
    index_time: float = Field(default=0.0, description="Index update time")


class DocumentMetadata(BaseModel):
    """Document metadata."""
    title: Optional[str] = Field(default=None, description="Document title")
    author: Optional[str] = Field(default=None, description="Document author")
    subject: Optional[str] = Field(default=None, description="Document subject")
    keywords: List[str] = Field(default=[], description="Document keywords")
    language: Optional[str] = Field(default=None, description="Document language")
    page_count: Optional[int] = Field(default=None, description="Number of pages")
    word_count: Optional[int] = Field(default=None, description="Number of words")
    character_count: Optional[int] = Field(default=None, description="Number of characters")
    created_date: Optional[datetime] = Field(default=None, description="Creation date")
    modified_date: Optional[datetime] = Field(default=None, description="Last modified date")


class DocumentChunk(BaseModel):
    """Document chunk model."""
    chunk_id: str = Field(description="Unique chunk identifier")
    document_id: UUID = Field(description="Parent document ID")
    content: str = Field(description="Chunk content")
    chunk_index: int = Field(description="Chunk index in document")
    start_position: int = Field(description="Start position in original text")
    end_position: int = Field(description="End position in original text")
    metadata: Dict[str, any] = Field(default={}, description="Chunk metadata")
    embedding: Optional[List[float]] = Field(default=None, description="Vector embedding")
    
    class Config:
        """Pydantic configuration."""
        json_encoders = {
            UUID: str
        }


class Document(BaseModel):
    """Document model."""
    document_id: UUID = Field(default_factory=uuid4, description="Document ID")
    filename: str = Field(description="Original filename")
    file_size: int = Field(description="File size in bytes")
    document_type: DocumentType = Field(description="Document type")
    status: DocumentStatus = Field(default=DocumentStatus.PENDING)
    upload_date: datetime = Field(default_factory=datetime.utcnow)
    processing_date: Optional[datetime] = Field(default=None)
    metadata: DocumentMetadata = Field(default_factory=DocumentMetadata)
    processing_stats: ProcessingStats = Field(default_factory=ProcessingStats)
    error_message: Optional[str] = Field(default=None)
    
    class Config:
        """Pydantic configuration."""
        json_encoders = {
            UUID: str,
            datetime: lambda v: v.isoformat()
        }


# Request Models
class DocumentUploadRequest(BaseModel):
    """Document upload request."""
    metadata: Optional[DocumentMetadata] = Field(default=None)
    tags: List[str] = Field(default=[], description="Document tags")


class DocumentQueryRequest(BaseModel):
    """Document query request."""
    query: str = Field(description="Search query")
    limit: int = Field(default=10, ge=1, le=100, description="Result limit")
    offset: int = Field(default=0, ge=0, description="Result offset")
    document_types: List[DocumentType] = Field(default=[], description="Filter by document types")
    tags: List[str] = Field(default=[], description="Filter by tags")


# Response Models
class DocumentUploadResponse(BaseModel):
    """Document upload response."""
    success: bool = Field(default=True)
    document_id: UUID = Field(description="Uploaded document ID")
    filename: str = Field(description="Uploaded filename")
    status: DocumentStatus = Field(description="Processing status")
    message: str = Field(description="Response message")


class DocumentListResponse(BaseModel):
    """Document list response."""
    documents: List[Document] = Field(description="List of documents")
    total: int = Field(description="Total number of documents")
    limit: int = Field(description="Response limit")
    offset: int = Field(description="Response offset")


class DocumentStatusResponse(BaseModel):
    """Document status response."""
    document_id: UUID = Field(description="Document ID")
    status: DocumentStatus = Field(description="Processing status")
    progress: float = Field(default=0.0, description="Processing progress (0-1)")
    message: Optional[str] = Field(default=None, description="Status message")
    processing_stats: Optional[ProcessingStats] = Field(default=None)


class DocumentDeleteResponse(BaseModel):
    """Document deletion response."""
    success: bool = Field(default=True)
    document_id: UUID = Field(description="Deleted document ID")
    message: str = Field(description="Response message")


class ProcessingError(BaseModel):
    """Processing error details."""
    error_type: str = Field(description="Error type")
    message: str = Field(description="Error message")
    details: Optional[Dict[str, any]] = Field(default=None, description="Additional error details")
    suggested_action: Optional[str] = Field(default=None, description="Suggested user action")


# WebSocket Models
class DocumentProcessingUpdate(BaseModel):
    """Document processing update for WebSocket."""
    document_id: UUID = Field(description="Document ID")
    status: DocumentStatus = Field(description="Processing status")
    progress: float = Field(default=0.0, description="Processing progress")
    message: Optional[str] = Field(default=None, description="Status message")
    error: Optional[ProcessingError] = Field(default=None, description="Error details")


# Export models
__all__ = [
    "DocumentStatus",
    "DocumentType",
    "ProcessingStats",
    "DocumentMetadata",
    "DocumentChunk",
    "Document",
    "DocumentUploadRequest",
    "DocumentQueryRequest",
    "DocumentUploadResponse",
    "DocumentListResponse",
    "DocumentStatusResponse",
    "DocumentDeleteResponse",
    "ProcessingError",
    "DocumentProcessingUpdate"
]