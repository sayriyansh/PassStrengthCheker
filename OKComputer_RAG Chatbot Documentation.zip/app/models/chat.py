"""
Chat and Conversation Models

Pydantic models for chat functionality and conversation management.
"""

from datetime import datetime
from enum import Enum
from typing import Dict, List, Optional
from uuid import UUID, uuid4

from pydantic import BaseModel, Field


class MessageRole(str, Enum):
    """Message roles in conversation."""
    USER = "user"
    ASSISTANT = "assistant"
    SYSTEM = "system"


class ChatSource(BaseModel):
    """Source attribution for chat responses."""
    document_id: UUID = Field(description="Source document ID")
    document_name: str = Field(description="Source document name")
    page: Optional[int] = Field(default=None, description="Page number")
    chunk_id: str = Field(description="Chunk identifier")
    relevance_score: float = Field(description="Relevance score (0-1)")
    content_preview: str = Field(description="Preview of source content")


class ChatMessage(BaseModel):
    """Individual chat message."""
    message_id: str = Field(default_factory=lambda: str(uuid4()), description="Message ID")
    role: MessageRole = Field(description="Message role")
    content: str = Field(description="Message content")
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    sources: List[ChatSource] = Field(default=[], description="Source attributions")
    metadata: Dict[str, any] = Field(default={}, description="Message metadata")
    
    class Config:
        """Pydantic configuration."""
        json_encoders = {
            UUID: str,
            datetime: lambda v: v.isoformat()
        }


class Conversation(BaseModel):
    """Conversation session model."""
    session_id: str = Field(description="Session identifier")
    title: Optional[str] = Field(default=None, description="Conversation title")
    messages: List[ChatMessage] = Field(default=[], description="Conversation messages")
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    metadata: Dict[str, any] = Field(default={}, description="Session metadata")
    
    class Config:
        """Pydantic configuration."""
        json_encoders = {
            UUID: str,
            datetime: lambda v: v.isoformat()
        }


# Request Models
class ChatRequest(BaseModel):
    """Chat request model."""
    query: str = Field(
        description="User query",
        min_length=1,
        max_length=10000
    )
    session_id: Optional[str] = Field(
        default=None,
        description="Conversation session ID"
    )
    include_sources: bool = Field(
        default=True,
        description="Include source attributions in response"
    )
    stream_response: bool = Field(
        default=False,
        description="Stream response chunks"
    )
    context_limit: int = Field(
        default=5,
        ge=1,
        le=20,
        description="Number of previous messages to include as context"
    )
    
    class Config:
        """Pydantic configuration."""
        json_schema_extra = {
            "example": {
                "query": "What are the system requirements?",
                "include_sources": True,
                "stream_response": False,
                "context_limit": 5
            }
        }


class ConversationRequest(BaseModel):
    """Conversation management request."""
    session_id: str = Field(description="Session ID")
    action: str = Field(
        description="Action to perform",
        pattern="^(list|delete|rename)$"
    )
    title: Optional[str] = Field(
        default=None,
        description="New title for rename action"
    )


# Response Models
class ChatResponse(BaseModel):
    """Chat response model."""
    answer: str = Field(description="Generated answer")
    session_id: str = Field(description="Conversation session ID")
    message_id: str = Field(description="Response message ID")
    sources: List[ChatSource] = Field(
        default=[], description="Source attributions"
    )
    metadata: Dict[str, any] = Field(
        default={}, description="Response metadata"
    )
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    
    class Config:
        """Pydantic configuration."""
        json_encoders = {
            UUID: str,
            datetime: lambda v: v.isoformat()
        }


class StreamingChunk(BaseModel):
    """Streaming response chunk."""
    chunk_type: str = Field(
        description="Chunk type (start, content, sources, end)"
    )
    content: Optional[str] = Field(
        default=None, description="Chunk content"
    )
    sources: Optional[List[ChatSource]] = Field(
        default=None, description="Source attributions"
    )
    metadata: Optional[Dict[str, any]] = Field(
        default=None, description="Chunk metadata"
    )


class ConversationListResponse(BaseModel):
    """Conversation list response."""
    conversations: List[Conversation] = Field(
        description="List of conversations"
    )
    total: int = Field(description="Total number of conversations")


class ConversationResponse(BaseModel):
    """Single conversation response."""
    conversation: Conversation = Field(description="Conversation details")
    message: str = Field(description="Response message")


class ChatError(BaseModel):
    """Chat error response."""
    error: str = Field(description="Error type")
    message: str = Field(description="Error message")
    suggested_action: Optional[str] = Field(
        default=None, description="Suggested user action"
    )
    context: Optional[Dict[str, any]] = Field(
        default=None, description="Error context"
    )


# WebSocket Models
class ChatStreamStart(BaseModel):
    """WebSocket stream start message."""
    session_id: str = Field(description="Session ID")
    message_id: str = Field(description="Message ID")


class ChatStreamChunk(BaseModel):
    """WebSocket stream chunk message."""
    content: str = Field(description="Chunk content")
    chunk_number: int = Field(description="Chunk sequence number")


class ChatStreamEnd(BaseModel):
    """WebSocket stream end message."""
    sources: List[ChatSource] = Field(description="Source attributions")
    metadata: Dict[str, any] = Field(description="Response metadata")


# Export models
__all__ = [
    "MessageRole",
    "ChatSource",
    "ChatMessage",
    "Conversation",
    "ChatRequest",
    "ConversationRequest",
    "ChatResponse",
    "StreamingChunk",
    "ConversationListResponse",
    "ConversationResponse",
    "ChatError",
    "ChatStreamStart",
    "ChatStreamChunk",
    "ChatStreamEnd"
]