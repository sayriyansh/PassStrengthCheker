"""
Standard Response Models

Common response wrappers for API consistency.
"""

from typing import Dict, List, Optional, TypeVar, Generic

from pydantic import BaseModel, Field

T = TypeVar('T')


class APIResponse(BaseModel, Generic[T]):
    """
    Standard API response wrapper.
    
    Provides consistent response structure across all endpoints.
    """
    success: bool = Field(default=True, description="Request success status")
    data: Optional[T] = Field(default=None, description="Response data")
    message: str = Field(default="Success", description="Response message")
    metadata: Optional[Dict[str, any]] = Field(
        default=None, description="Response metadata"
    )
    errors: Optional[List[str]] = Field(
        default=None, description="Error messages if any"
    )
    
    class Config:
        """Pydantic configuration."""
        json_schema_extra = {
            "example": {
                "success": True,
                "data": {"key": "value"},
                "message": "Operation completed successfully",
                "metadata": {"timestamp": "2024-01-01T00:00:00Z"},
                "errors": None
            }
        }


class ErrorResponse(BaseModel):
    """
    Standard error response.
    
    Provides consistent error reporting structure.
    """
    success: bool = Field(default=False, description="Request success status")
    error: str = Field(description="Error type/code")
    message: str = Field(description="Error message")
    details: Optional[Dict[str, any]] = Field(
        default=None, description="Additional error details"
    )
    suggested_action: Optional[str] = Field(
        default=None, description="Suggested user action"
    )
    
    class Config:
        """Pydantic configuration."""
        json_schema_extra = {
            "example": {
                "success": False,
                "error": "VALIDATION_ERROR",
                "message": "Invalid input provided",
                "details": {"field": "email", "issue": "Invalid format"},
                "suggested_action": "Please provide a valid email address"
            }
        }


class PaginatedResponse(BaseModel, Generic[T]):
    """
    Paginated response wrapper.
    
    Standard pagination structure for list endpoints.
    """
    success: bool = Field(default=True, description="Request success status")
    data: List[T] = Field(description="List of items")
    pagination: Dict[str, int] = Field(
        description="Pagination information",
        example={
            "page": 1,
            "limit": 10,
            "total": 100,
            "pages": 10,
            "has_next": True,
            "has_previous": False
        }
    )
    
    class Config:
        """Pydantic configuration."""
        json_schema_extra = {
            "example": {
                "success": True,
                "data": [{"id": 1, "name": "Item 1"}],
                "pagination": {
                    "page": 1,
                    "limit": 10,
                    "total": 100,
                    "pages": 10,
                    "has_next": True,
                    "has_previous": False
                }
            }
        }


class HealthResponse(BaseModel):
    """
    Health check response.
    
    Standard health check structure.
    """
    status: str = Field(description="Overall health status")
    version: str = Field(description="Application version")
    uptime: Optional[float] = Field(default=None, description="Uptime in seconds")
    checks: Dict[str, Dict[str, any]] = Field(
        default={}, description="Individual health checks"
    )
    
    class Config:
        """Pydantic configuration."""
        json_schema_extra = {
            "example": {
                "status": "healthy",
                "version": "1.0.0",
                "uptime": 3600.5,
                "checks": {
                    "database": {"status": "healthy", "response_time": 0.01},
                    "redis": {"status": "healthy", "response_time": 0.005},
                    "vector_store": {"status": "healthy", "index_size": 1000}
                }
            }
        }


class ProgressResponse(BaseModel):
    """
    Progress tracking response.
    
    For long-running operations.
    """
    operation_id: str = Field(description="Operation identifier")
    status: str = Field(description="Operation status")
    progress: float = Field(
        ge=0.0,
        le=1.0,
        description="Progress percentage (0.0 to 1.0)"
    )
    message: str = Field(description="Status message")
    estimated_remaining_time: Optional[float] = Field(
        default=None, description="Estimated remaining time in seconds"
    )
    result_preview: Optional[Dict[str, any]] = Field(
        default=None, description="Preview of operation result"
    )
    
    class Config:
        """Pydantic configuration."""
        json_schema_extra = {
            "example": {
                "operation_id": "doc_process_123",
                "status": "processing",
                "progress": 0.75,
                "message": "Generating embeddings...",
                "estimated_remaining_time": 30.5,
                "result_preview": {"chunks_processed": 75, "total_chunks": 100}
            }
        }


# Export response models
__all__ = [
    "APIResponse",
    "ErrorResponse",
    "PaginatedResponse",
    "HealthResponse",
    "ProgressResponse"
]