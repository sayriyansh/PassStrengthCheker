"""
Custom Exception Classes

Application-specific exception definitions.
"""

from typing import Any, Dict, Optional


class RAGChatbotException(Exception):
    """Base exception for RAG Chatbot application."""
    
    def __init__(
        self,
        message: str,
        error_code: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
        suggested_action: Optional[str] = None
    ):
        """
        Initialize exception.
        
        Args:
            message: Error message
            error_code: Optional error code
            details: Additional error details
            suggested_action: Suggested user action
        """
        super().__init__(message)
        self.message = message
        self.error_code = error_code
        self.details = details or {}
        self.suggested_action = suggested_action
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert exception to dictionary."""
        return {
            "error": self.error_code or "INTERNAL_ERROR",
            "message": self.message,
            "details": self.details,
            "suggested_action": self.suggested_action
        }


class DocumentProcessingError(RAGChatbotException):
    """Raised when document processing fails."""
    
    def __init__(
        self,
        message: str,
        document_id: Optional[str] = None,
        filename: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None
    ):
        """
        Initialize document processing error.
        
        Args:
            message: Error message
            document_id: Document ID
            filename: Filename
            details: Additional error details
        """
        super().__init__(
            message,
            error_code="DOCUMENT_PROCESSING_ERROR",
            details={
                "document_id": document_id,
                "filename": filename,
                **(details or {})
            },
            suggested_action="Please check the document format and try again."
        )
        self.document_id = document_id
        self.filename = filename


class EmbeddingGenerationError(RAGChatbotException):
    """Raised when embedding generation fails."""
    
    def __init__(
        self,
        message: str,
        model: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None
    ):
        """
        Initialize embedding generation error.
        
        Args:
            message: Error message
            model: Embedding model
            details: Additional error details
        """
        super().__init__(
            message,
            error_code="EMBEDDING_GENERATION_ERROR",
            details={
                "model": model,
                **(details or {})
            },
            suggested_action="Please check your API key and try again."
        )
        self.model = model


class RetrievalError(RAGChatbotException):
    """Raised when context retrieval fails."""
    
    def __init__(
        self,
        message: str,
        query: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None
    ):
        """
        Initialize retrieval error.
        
        Args:
            message: Error message
            query: Search query
            details: Additional error details
        """
        super().__init__(
            message,
            error_code="RETRIEVAL_ERROR",
            details={
                "query": query,
                **(details or {})
            },
            suggested_action="Please try rephrasing your query or check if documents are indexed."
        )
        self.query = query


class LLMError(RAGChatbotException):
    """Raised when LLM response generation fails."""
    
    def __init__(
        self,
        message: str,
        model: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None
    ):
        """
        Initialize LLM error.
        
        Args:
            message: Error message
            model: LLM model
            details: Additional error details
        """
        super().__init__(
            message,
            error_code="LLM_ERROR",
            details={
                "model": model,
                **(details or {})
            },
            suggested_action="Please try again later or contact support if the issue persists."
        )
        self.model = model


class VectorStoreError(RAGChatbotException):
    """Raised when vector store operations fail."""
    
    def __init__(
        self,
        message: str,
        operation: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None
    ):
        """
        Initialize vector store error.
        
        Args:
            message: Error message
            operation: Operation that failed
            details: Additional error details
        """
        super().__init__(
            message,
            error_code="VECTOR_STORE_ERROR",
            details={
                "operation": operation,
                **(details or {})
            },
            suggested_action="Please check the vector store status and try again."
        )
        self.operation = operation


class CacheError(RAGChatbotException):
    """Raised when cache operations fail."""
    
    def __init__(
        self,
        message: str,
        cache_type: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None
    ):
        """
        Initialize cache error.
        
        Args:
            message: Error message
            cache_type: Type of cache
            details: Additional error details
        """
        super().__init__(
            message,
            error_code="CACHE_ERROR",
            details={
                "cache_type": cache_type,
                **(details or {})
            },
            suggested_action="Please check the cache service status."
        )
        self.cache_type = cache_type


class AuthenticationError(RAGChatbotException):
    """Raised when authentication fails."""
    
    def __init__(
        self,
        message: str = "Authentication failed",
        details: Optional[Dict[str, Any]] = None
    ):
        """
        Initialize authentication error.
        
        Args:
            message: Error message
            details: Additional error details
        """
        super().__init__(
            message,
            error_code="AUTHENTICATION_ERROR",
            details=details or {},
            suggested_action="Please check your API key and try again."
        )


class AuthorizationError(RAGChatbotException):
    """Raised when authorization fails."""
    
    def __init__(
        self,
        message: str = "Authorization failed",
        resource: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None
    ):
        """
        Initialize authorization error.
        
        Args:
            message: Error message
            resource: Resource being accessed
            details: Additional error details
        """
        super().__init__(
            message,
            error_code="AUTHORIZATION_ERROR",
            details={
                "resource": resource,
                **(details or {})
            },
            suggested_action="You don't have permission to access this resource."
        )
        self.resource = resource


class RateLimitError(RAGChatbotException):
    """Raised when rate limit is exceeded."""
    
    def __init__(
        self,
        message: str = "Rate limit exceeded",
        limit: Optional[int] = None,
        window: Optional[int] = None,
        retry_after: Optional[int] = None,
        details: Optional[Dict[str, Any]] = None
    ):
        """
        Initialize rate limit error.
        
        Args:
            message: Error message
            limit: Rate limit
            window: Time window
            retry_after: Seconds until retry
            details: Additional error details
        """
        super().__init__(
            message,
            error_code="RATE_LIMIT_ERROR",
            details={
                "limit": limit,
                "window": window,
                "retry_after": retry_after,
                **(details or {})
            },
            suggested_action=f"Please try again in {retry_after} seconds."
        )
        self.limit = limit
        self.window = window
        self.retry_after = retry_after


class ValidationError(RAGChatbotException):
    """Raised when input validation fails."""
    
    def __init__(
        self,
        message: str,
        field: Optional[str] = None,
        value: Optional[Any] = None,
        details: Optional[Dict[str, Any]] = None
    ):
        """
        Initialize validation error.
        
        Args:
            message: Error message
            field: Field that failed validation
            value: Invalid value
            details: Additional error details
        """
        super().__init__(
            message,
            error_code="VALIDATION_ERROR",
            details={
                "field": field,
                "value": value,
                **(details or {})
            },
            suggested_action="Please check your input and try again."
        )
        self.field = field
        self.value = value


class ConfigurationError(RAGChatbotException):
    """Raised when configuration is invalid."""
    
    def __init__(
        self,
        message: str,
        config_key: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None
    ):
        """
        Initialize configuration error.
        
        Args:
            message: Error message
            config_key: Configuration key
            details: Additional error details
        """
        super().__init__(
            message,
            error_code="CONFIGURATION_ERROR",
            details={
                "config_key": config_key,
                **(details or {})
            },
            suggested_action="Please check your configuration and environment variables."
        )
        self.config_key = config_key


# Export exceptions
__all__ = [
    "RAGChatbotException",
    "DocumentProcessingError",
    "EmbeddingGenerationError",
    "RetrievalError",
    "LLMError",
    "VectorStoreError",
    "CacheError",
    "AuthenticationError",
    "AuthorizationError",
    "RateLimitError",
    "ValidationError",
    "ConfigurationError"
]