"""
Input Validation Utilities

Validation functions for various input types.
"""

import re
from pathlib import Path
from typing import List, Optional, Union

from fastapi import HTTPException, status

from app.core.config import settings
from app.core.logging import get_logger

logger = get_logger(__name__)


class InputValidator:
    """Input validation utilities."""
    
    @staticmethod
    def validate_file_upload(
        filename: str,
        file_size: int,
        allowed_extensions: Optional[List[str]] = None,
        max_size_bytes: Optional[int] = None
    ) -> None:
        """
        Validate file upload.
        
        Args:
            filename: Original filename
            file_size: File size in bytes
            allowed_extensions: List of allowed extensions
            max_size_bytes: Maximum file size in bytes
            
        Raises:
            HTTPException: If validation fails
        """
        # Use defaults if not provided
        allowed_extensions = allowed_extensions or settings.ALLOWED_EXTENSIONS
        max_size_bytes = max_size_bytes or settings.max_file_size_bytes
        
        # Check if file has extension
        if not filename or "." not in filename:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="File must have an extension"
            )
        
        # Extract and validate extension
        extension = Path(filename).suffix.lower().lstrip(".")
        
        if extension not in allowed_extensions:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"File type '{extension}' not supported. Allowed: {allowed_extensions}"
            )
        
        # Check file size
        if file_size > max_size_bytes:
            max_size_mb = max_size_bytes / (1024 * 1024)
            raise HTTPException(
                status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
                detail=f"File too large. Maximum size: {max_size_mb:.1f}MB"
            )
    
    @staticmethod
    def validate_query(query: str, min_length: int = 3, max_length: int = 10000) -> str:
        """
        Validate search query.
        
        Args:
            query: Search query
            min_length: Minimum query length
            max_length: Maximum query length
            
        Returns:
            Cleaned query
            
        Raises:
            HTTPException: If validation fails
        """
        if not query or not query.strip():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Query cannot be empty"
            )
        
        query = query.strip()
        
        if len(query) < min_length:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Query too short. Minimum length: {min_length} characters"
            )
        
        if len(query) > max_length:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Query too long. Maximum length: {max_length} characters"
            )
        
        # Check for potential SQL injection patterns (basic)
        dangerous_patterns = [
            r"(\s|^)(union|select|insert|update|delete|drop|create|alter|exec|execute)(\s|$)",
            r"(\s|^)(script|javascript|vbscript|onload|onerror)(\s|$)",
            r"[<>\"']",
        ]
        
        query_lower = query.lower()
        for pattern in dangerous_patterns:
            if re.search(pattern, query_lower, re.IGNORECASE):
                logger.warning(f"Potentially dangerous query detected: {query}")
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Query contains invalid characters or patterns"
                )
        
        return query
    
    @staticmethod
    def validate_document_id(document_id: str) -> str:
        """
        Validate document ID format.
        
        Args:
            document_id: Document ID
            
        Returns:
            Validated document ID
            
        Raises:
            HTTPException: If validation fails
        """
        import uuid
        
        try:
            # Try to parse as UUID
            uuid_obj = uuid.UUID(document_id)
            return str(uuid_obj)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid document ID format. Expected UUID."
            )
    
    @staticmethod
    def validate_session_id(session_id: str) -> str:
        """
        Validate session ID format.
        
        Args:
            session_id: Session ID
            
        Returns:
            Validated session ID
            
        Raises:
            HTTPException: If validation fails
        """
        if not session_id or len(session_id) < 10:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid session ID"
            )
        
        # Check for valid characters (alphanumeric and hyphens)
        if not re.match(r"^[a-zA-Z0-9\-]+$", session_id):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Session ID contains invalid characters"
            )
        
        return session_id
    
    @staticmethod
    def validate_api_key(api_key: str) -> str:
        """
        Validate API key format.
        
        Args:
            api_key: API key
            
        Returns:
            Validated API key
            
        Raises:
            HTTPException: If validation fails
        """
        if not api_key or len(api_key) < 10:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid API key"
            )
        
        # Check for valid characters
        if not re.match(r"^[a-zA-Z0-9\-_]+$", api_key):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="API key contains invalid characters"
            )
        
        return api_key
    
    @staticmethod
    def validate_pagination(limit: int, offset: int) -> None:
        """
        Validate pagination parameters.
        
        Args:
            limit: Number of items to return
            offset: Number of items to skip
            
        Raises:
            HTTPException: If validation fails
        """
        if limit < 1 or limit > 1000:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Limit must be between 1 and 1000"
            )
        
        if offset < 0:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Offset cannot be negative"
            )
    
    @staticmethod
    def validate_embedding(embedding: List[float]) -> List[float]:
        """
        Validate embedding vector.
        
        Args:
            embedding: Embedding vector
            
        Returns:
            Validated embedding
            
        Raises:
            HTTPException: If validation fails
        """
        if not embedding:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Embedding cannot be empty"
            )
        
        if len(embedding) != settings.EMBEDDING_DIMENSION:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Invalid embedding dimension. Expected: {settings.EMBEDDING_DIMENSION}"
            )
        
        # Check for NaN or infinite values
        for value in embedding:
            if not isinstance(value, (int, float)):
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Embedding contains non-numeric values"
                )
            
            if value != value or value == float('inf') or value == float('-inf'):
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Embedding contains NaN or infinite values"
                )
        
        return embedding
    
    @staticmethod
    def sanitize_text(text: str, max_length: int = 10000) -> str:
        """
        Sanitize text input.
        
        Args:
            text: Text to sanitize
            max_length: Maximum allowed length
            
        Returns:
            Sanitized text
            
        Raises:
            HTTPException: If validation fails
        """
        if not text:
            return ""
        
        if len(text) > max_length:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Text too long. Maximum length: {max_length} characters"
            )
        
        # Remove control characters (except newlines, tabs)
        sanitized = "".join(
            char for char in text 
            if ord(char) >= 32 or char in "\n\r\t"
        )
        
        # Remove null bytes
        sanitized = sanitized.replace('\x00', '')
        
        # Normalize whitespace
        import re
        sanitized = re.sub(r'\s+', ' ', sanitized)
        
        return sanitized.strip()
    
    @staticmethod
    def validate_email(email: str) -> str:
        """
        Validate email address.
        
        Args:
            email: Email address
            
        Returns:
            Validated email
            
        Raises:
            HTTPException: If validation fails
        """
        if not email:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Email is required"
            )
        
        # Basic email pattern
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        
        if not re.match(pattern, email):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid email format"
            )
        
        return email.lower().strip()
    
    @staticmethod
    def validate_rate_limit_identifier(identifier: str) -> str:
        """
        Validate rate limit identifier.
        
        Args:
            identifier: Rate limit identifier (IP or API key)
            
        Returns:
            Validated identifier
            
        Raises:
            HTTPException: If validation fails
        """
        if not identifier or len(identifier) < 3:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid rate limit identifier"
            )
        
        # Check for valid characters
        if not re.match(r"^[a-zA-Z0-9\.\-_:@]+$", identifier):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Rate limit identifier contains invalid characters"
            )
        
        return identifier


# Global validator instance
input_validator = InputValidator()


# Export commonly used functions
validate_file_upload = input_validator.validate_file_upload
validate_query = input_validator.validate_query
validate_document_id = input_validator.validate_document_id
validate_session_id = input_validator.validate_session_id
validate_api_key = input_validator.validate_api_key
validate_pagination = input_validator.validate_pagination
validate_embedding = input_validator.validate_embedding
sanitize_text = input_validator.sanitize_text
validate_email = input_validator.validate_email


# Export
__all__ = [
    "InputValidator",
    "input_validator",
    "validate_file_upload",
    "validate_query",
    "validate_document_id",
    "validate_session_id",
    "validate_api_key",
    "validate_pagination",
    "validate_embedding",
    "sanitize_text",
    "validate_email"
]