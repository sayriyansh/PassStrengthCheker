"""
File Handling Utilities

Multi-format file parsers and handlers.
"""

import csv
import json
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd
from langchain.document_loaders import (
    CSVLoader,
    Docx2txtLoader,
    PyPDFLoader,
    TextLoader,
    UnstructuredFileLoader
)
from langchain.schema import Document as LangchainDocument

from app.core.logging import get_logger
from app.models.document import DocumentType

logger = get_logger(__name__)


class FileHandler(ABC):
    """Abstract base class for file handlers."""
    
    @abstractmethod
    def can_handle(self, file_path: Path) -> bool:
        """Check if handler can process the file."""
        pass
    
    @abstractmethod
    async def parse(self, file_path: Path) -> List[LangchainDocument]:
        """Parse file and return documents."""
        pass
    
    @abstractmethod
    def get_metadata(self, file_path: Path) -> Dict[str, Any]:
        """Extract file metadata."""
        pass


class PDFHandler(FileHandler):
    """PDF file handler."""
    
    def can_handle(self, file_path: Path) -> bool:
        return file_path.suffix.lower() == ".pdf"
    
    async def parse(self, file_path: Path) -> List[LangchainDocument]:
        """Parse PDF file."""
        try:
            loader = PyPDFLoader(str(file_path))
            documents = await self._run_in_thread(loader.load)
            
            # Add file-specific metadata
            for doc in documents:
                doc.metadata["file_type"] = "pdf"
                doc.metadata["file_path"] = str(file_path)
            
            return documents
            
        except Exception as e:
            logger.error(f"Failed to parse PDF {file_path}: {e}")
            raise
    
    def get_metadata(self, file_path: Path) -> Dict[str, Any]:
        """Extract PDF metadata."""
        try:
            import pypdf
            
            with open(file_path, 'rb') as file:
                pdf_reader = pypdf.PdfReader(file)
                metadata = pdf_reader.metadata
                
                return {
                    "title": metadata.get("/Title", "") if metadata else "",
                    "author": metadata.get("/Author", "") if metadata else "",
                    "subject": metadata.get("/Subject", "") if metadata else "",
                    "keywords": metadata.get("/Keywords", "") if metadata else "",
                    "page_count": len(pdf_reader.pages),
                    "file_size": file_path.stat().st_size
                }
                
        except Exception as e:
            logger.warning(f"Could not extract PDF metadata: {e}")
            return {"page_count": 0, "file_size": file_path.stat().st_size}
    
    async def _run_in_thread(self, func):
        """Run function in thread pool."""
        import asyncio
        return await asyncio.get_event_loop().run_in_executor(None, func)


class TextHandler(FileHandler):
    """Text file handler."""
    
    def can_handle(self, file_path: Path) -> bool:
        return file_path.suffix.lower() in [".txt", ".md", ".rst"]
    
    async def parse(self, file_path: Path) -> List[LangchainDocument]:
        """Parse text file."""
        try:
            # Detect encoding
            encoding = self._detect_encoding(file_path)
            
            loader = TextLoader(str(file_path), encoding=encoding)
            documents = await self._run_in_thread(loader.load)
            
            # Add file-specific metadata
            for doc in documents:
                doc.metadata["file_type"] = "text"
                doc.metadata["file_path"] = str(file_path)
                doc.metadata["encoding"] = encoding
            
            return documents
            
        except Exception as e:
            logger.error(f"Failed to parse text file {file_path}: {e}")
            raise
    
    def get_metadata(self, file_path: Path) -> Dict[str, Any]:
        """Extract text file metadata."""
        stat = file_path.stat()
        encoding = self._detect_encoding(file_path)
        
        # Count lines, words, characters
        with open(file_path, 'r', encoding=encoding) as f:
            content = f.read()
            lines = content.split('\n')
            words = content.split()
        
        return {
            "encoding": encoding,
            "line_count": len(lines),
            "word_count": len(words),
            "char_count": len(content),
            "file_size": stat.st_size
        }
    
    def _detect_encoding(self, file_path: Path) -> str:
        """Detect file encoding."""
        try:
            import chardet
            
            with open(file_path, 'rb') as f:
                raw_data = f.read(10000)  # Read first 10KB
                result = chardet.detect(raw_data)
                return result.get('encoding', 'utf-8') or 'utf-8'
                
        except Exception:
            return 'utf-8'  # Default to UTF-8
    
    async def _run_in_thread(self, func):
        """Run function in thread pool."""
        import asyncio
        return await asyncio.get_event_loop().run_in_executor(None, func)


class DocxHandler(FileHandler):
    """DOCX file handler."""
    
    def can_handle(self, file_path: Path) -> bool:
        return file_path.suffix.lower() in [".docx", ".doc"]
    
    async def parse(self, file_path: Path) -> List[LangchainDocument]:
        """Parse DOCX file."""
        try:
            loader = Docx2txtLoader(str(file_path))
            documents = await self._run_in_thread(loader.load)
            
            # Add file-specific metadata
            for doc in documents:
                doc.metadata["file_type"] = "docx"
                doc.metadata["file_path"] = str(file_path)
            
            return documents
            
        except Exception as e:
            logger.error(f"Failed to parse DOCX {file_path}: {e}")
            raise
    
    def get_metadata(self, file_path: Path) -> Dict[str, Any]:
        """Extract DOCX metadata."""
        try:
            from docx import Document as DocxDocument
            
            doc = DocxDocument(file_path)
            props = doc.core_properties
            
            # Count paragraphs
            para_count = len(doc.paragraphs)
            
            return {
                "title": props.title or "",
                "author": props.author or "",
                "subject": props.subject or "",
                "keywords": props.keywords or "",
                "created": props.created.isoformat() if props.created else None,
                "modified": props.modified.isoformat() if props.modified else None,
                "paragraph_count": para_count,
                "file_size": file_path.stat().st_size
            }
            
        except Exception as e:
            logger.warning(f"Could not extract DOCX metadata: {e}")
            return {"paragraph_count": 0, "file_size": file_path.stat().st_size}
    
    async def _run_in_thread(self, func):
        """Run function in thread pool."""
        import asyncio
        return await asyncio.get_event_loop().run_in_executor(None, func)


class CSVHandler(FileHandler):
    """CSV file handler."""
    
    def can_handle(self, file_path: Path) -> bool:
        return file_path.suffix.lower() == ".csv"
    
    async def parse(self, file_path: Path) -> List[LangchainDocument]:
        """Parse CSV file."""
        try:
            # Detect delimiter and encoding
            delimiter = self._detect_delimiter(file_path)
            encoding = self._detect_encoding(file_path)
            
            # Load CSV
            df = await self._run_in_thread(
                lambda: pd.read_csv(file_path, delimiter=delimiter, encoding=encoding)
            )
            
            # Convert to documents
            documents = []
            for idx, row in df.iterrows():
                # Create readable text representation
                row_text = self._row_to_text(row, idx)
                
                doc = LangchainDocument(
                    page_content=row_text,
                    metadata={
                        "file_type": "csv",
                        "file_path": str(file_path),
                        "row_index": idx,
                        "total_rows": len(df),
                        "columns": list(df.columns),
                        "delimiter": delimiter,
                        "encoding": encoding
                    }
                )
                documents.append(doc)
            
            return documents
            
        except Exception as e:
            logger.error(f"Failed to parse CSV {file_path}: {e}")
            raise
    
    def get_metadata(self, file_path: Path) -> Dict[str, Any]:
        """Extract CSV metadata."""
        try:
            delimiter = self._detect_delimiter(file_path)
            encoding = self._detect_encoding(file_path)
            
            # Quick analysis
            with open(file_path, 'r', encoding=encoding) as f:
                reader = csv.reader(f, delimiter=delimiter)
                headers = next(reader, None)
                row_count = sum(1 for _ in reader)
            
            return {
                "delimiter": delimiter,
                "encoding": encoding,
                "column_count": len(headers) if headers else 0,
                "row_count": row_count,
                "headers": headers or [],
                "file_size": file_path.stat().st_size
            }
            
        except Exception as e:
            logger.warning(f"Could not extract CSV metadata: {e}")
            return {"file_size": file_path.stat().st_size}
    
    def _detect_delimiter(self, file_path: Path) -> str:
        """Detect CSV delimiter."""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                first_line = f.readline()
                
            # Try common delimiters
            delimiters = [',', ';', '\t', '|']
            for delimiter in delimiters:
                if delimiter in first_line:
                    return delimiter
            
            return ','  # Default to comma
            
        except Exception:
            return ','
    
    def _detect_encoding(self, file_path: Path) -> str:
        """Detect file encoding."""
        try:
            import chardet
            
            with open(file_path, 'rb') as f:
                raw_data = f.read(10000)
                result = chardet.detect(raw_data)
                return result.get('encoding', 'utf-8') or 'utf-8'
                
        except Exception:
            return 'utf-8'
    
    def _row_to_text(self, row: pd.Series, index: int) -> str:
        """Convert DataFrame row to text."""
        parts = [f"Row {index + 1}:"]
        for col, val in row.items():
            if pd.notna(val):  # Skip NaN values
                parts.append(f"{col}: {val}")
        return "\n".join(parts)
    
    async def _run_in_thread(self, func):
        """Run function in thread pool."""
        import asyncio
        return await asyncio.get_event_loop().run_in_executor(None, func)


class FileHandlerRegistry:
    """Registry for file handlers."""
    
    def __init__(self):
        """Initialize handler registry."""
        self.handlers = [
            PDFHandler(),
            TextHandler(),
            DocxHandler(),
            CSVHandler()
        ]
    
    def get_handler(self, file_path: Path) -> Optional[FileHandler]:
        """
        Get appropriate handler for file.
        
        Args:
            file_path: Path to file
            
        Returns:
            File handler or None if not supported
        """
        for handler in self.handlers:
            if handler.can_handle(file_path):
                return handler
        return None
    
    def get_handler_by_type(self, doc_type: DocumentType) -> Optional[FileHandler]:
        """
        Get handler by document type.
        
        Args:
            doc_type: Document type
            
        Returns:
            File handler or None
        """
        type_mapping = {
            DocumentType.PDF: PDFHandler,
            DocumentType.TXT: TextHandler,
            DocumentType.DOCX: DocxHandler,
            DocumentType.CSV: CSVHandler
        }
        
        handler_class = type_mapping.get(doc_type)
        if handler_class:
            for handler in self.handlers:
                if isinstance(handler, handler_class):
                    return handler
        
        return None
    
    def get_supported_extensions(self) -> List[str]:
        """Get list of supported file extensions."""
        extensions = []
        for handler in self.handlers:
            # This is a simplified approach - in production, you might
            # want to add a get_extensions method to each handler
            if isinstance(handler, PDFHandler):
                extensions.append(".pdf")
            elif isinstance(handler, TextHandler):
                extensions.extend([".txt", ".md", ".rst"])
            elif isinstance(handler, DocxHandler):
                extensions.extend([".docx", ".doc"])
            elif isinstance(handler, CSVHandler):
                extensions.append(".csv")
        
        return extensions


# Global file handler registry
file_handler_registry = FileHandlerRegistry()


# Convenience function
def get_file_handler(file_path: Path) -> Optional[FileHandler]:
    """Get appropriate file handler."""
    return file_handler_registry.get_handler(file_path)


# Export
__all__ = [
    "FileHandler",
    "PDFHandler",
    "TextHandler",
    "DocxHandler",
    "CSVHandler",
    "FileHandlerRegistry",
    "file_handler_registry",
    "get_file_handler"
]