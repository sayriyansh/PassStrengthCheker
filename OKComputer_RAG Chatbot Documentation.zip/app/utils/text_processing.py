"""
Text Processing Utilities

Text cleaning, chunking, and feature extraction utilities.
"""

import re
from typing import Dict, List, Optional

import nltk
from langdetect import detect
from nltk.corpus import stopwords
from nltk.tokenize import sent_tokenize, word_tokenize

from app.core.logging import get_logger

logger = get_logger(__name__)


class TextProcessor:
    """
    Text processing utilities for document processing.
    """
    
    def __init__(self):
        """Initialize text processor."""
        self._download_nltk_data()
    
    def _download_nltk_data(self) -> None:
        """Download required NLTK data."""
        required_data = ["punkt", "stopwords"]
        for data in required_data:
            try:
                nltk.data.find(f"tokenizers/{data}")
            except LookupError:
                logger.info(f"Downloading NLTK {data} data")
                nltk.download(data, quiet=True)
    
    def clean_text(self, text: str) -> str:
        """
        Clean and normalize text content.
        
        Args:
            text: Raw text to clean
            
        Returns:
            Cleaned text
        """
        if not text:
            return ""
        
        # Remove excessive whitespace
        text = re.sub(r'\s+', ' ', text)
        
        # Remove control characters (except newlines, tabs)
        text = "".join(char for char in text if ord(char) >= 32 or char in "\n\r\t")
        
        # Remove special characters but keep basic punctuation
        text = re.sub(r'[^\w\s\.\,\!\?\:\;\-\(\)\[\]\{\}]', ' ', text)
        
        # Fix common encoding issues
        text = text.replace('\ufeff', '')  # Remove BOM
        text = text.replace('\x00', '')    # Remove null bytes
        
        # Normalize quotes
        text = text.replace('"', '"').replace('"', '"')
        text = text.replace(''', "'").replace(''', "'")
        
        # Strip leading/trailing whitespace
        text = text.strip()
        
        return text
    
    def extract_text_features(self, text: str) -> Dict[str, any]:
        """
        Extract features from text.
        
        Args:
            text: Text to analyze
            
        Returns:
            Dictionary of text features
        """
        if not text:
            return {}
        
        try:
            # Basic statistics
            char_count = len(text)
            word_count = len(text.split())
            sentence_count = len(sent_tokenize(text))
            
            # Language detection
            try:
                language = detect(text)
            except:
                language = "unknown"
            
            # Average sentence length
            avg_sentence_length = word_count / sentence_count if sentence_count > 0 else 0
            
            # Paragraph count (double newlines)
            paragraph_count = len([p for p in text.split('\n\n') if p.strip()])
            
            # Readability metrics (Flesch Reading Ease approximation)
            avg_words_per_sentence = word_count / sentence_count if sentence_count > 0 else 0
            avg_syllables_per_word = self._estimate_syllables_per_word(text)
            
            # Flesch Reading Ease (simplified)
            flesch_score = 206.835 - (1.015 * avg_words_per_sentence) - (84.6 * avg_syllables_per_word)
            
            return {
                "char_count": char_count,
                "word_count": word_count,
                "sentence_count": sentence_count,
                "paragraph_count": paragraph_count,
                "language": language,
                "avg_sentence_length": avg_sentence_length,
                "avg_words_per_sentence": avg_words_per_sentence,
                "avg_syllables_per_word": avg_syllables_per_word,
                "flesch_reading_ease": max(0, min(100, flesch_score))  # Clamp to 0-100
            }
            
        except Exception as e:
            logger.error(f"Error extracting text features: {e}")
            return {}
    
    def _estimate_syllables_per_word(self, text: str) -> float:
        """
        Estimate average syllables per word.
        
        Args:
            text: Text to analyze
            
        Returns:
            Estimated syllables per word
        """
        words = text.split()
        if not words:
            return 0.0
        
        total_syllables = 0
        for word in words:
            # Simple syllable counting: count vowel groups
            vowels = "aeiouy"
            word_lower = word.lower()
            syllable_count = 0
            prev_was_vowel = False
            
            for char in word_lower:
                if char in vowels:
                    if not prev_was_vowel:
                        syllable_count += 1
                    prev_was_vowel = True
                else:
                    prev_was_vowel = False
            
            # Handle silent 'e'
            if word_lower.endswith('e') and syllable_count > 1:
                syllable_count -= 1
            
            total_syllables += max(1, syllable_count)
        
        return total_syllables / len(words)
    
    def extract_keywords(
        self,
        text: str,
        max_keywords: int = 10,
        min_length: int = 3
    ) -> List[str]:
        """
        Extract keywords from text.
        
        Args:
            text: Text to analyze
            max_keywords: Maximum number of keywords to return
            min_length: Minimum keyword length
            
        Returns:
            List of extracted keywords
        """
        try:
            # Clean text
            clean_text = re.sub(r'[^\w\s]', ' ', text.lower())
            
            # Tokenize
            words = word_tokenize(clean_text)
            
            # Remove stopwords
            stop_words = set(stopwords.words('english'))
            filtered_words = [
                word for word in words
                if word not in stop_words
                and len(word) >= min_length
                and word.isalpha()
            ]
            
            # Count word frequencies
            word_freq = {}
            for word in filtered_words:
                word_freq[word] = word_freq.get(word, 0) + 1
            
            # Get top keywords
            sorted_words = sorted(
                word_freq.items(),
                key=lambda x: x[1],
                reverse=True
            )
            
            return [word for word, freq in sorted_words[:max_keywords]]
            
        except Exception as e:
            logger.error(f"Error extracting keywords: {e}")
            return []
    
    def split_into_sentences(self, text: str) -> List[str]:
        """
        Split text into sentences.
        
        Args:
            text: Text to split
            
        Returns:
            List of sentences
        """
        try:
            sentences = sent_tokenize(text)
            return [s.strip() for s in sentences if s.strip()]
        except Exception as e:
            logger.error(f"Error splitting sentences: {e}")
            return text.split('.')  # Fallback to simple split
    
    def extract_text_chunks(
        self,
        text: str,
        chunk_size: int = 1000,
        chunk_overlap: int = 100
    ) -> List[str]:
        """
        Extract overlapping text chunks.
        
        Args:
            text: Text to chunk
            chunk_size: Size of each chunk (in characters)
            chunk_overlap: Overlap between chunks (in characters)
            
        Returns:
            List of text chunks
        """
        if not text:
            return []
        
        chunks = []
        start = 0
        text_length = len(text)
        
        while start < text_length:
            # Calculate end position
            end = min(start + chunk_size, text_length)
            
            # Extract chunk
            chunk = text[start:end].strip()
            
            # Only add non-empty chunks
            if chunk:
                chunks.append(chunk)
            
            # Move to next chunk
            start = end - chunk_overlap
            
            # Prevent infinite loop
            if start >= text_length:
                break
        
        return chunks
    
    def find_text_boundaries(
        self,
        text: str,
        position: int,
        window_size: int = 100
    ) -> Tuple[int, int]:
        """
        Find sentence boundaries around a position.
        
        Args:
            text: Full text
            position: Position to center around
            window_size: Size of window around position
            
        Returns:
            Tuple of (start_position, end_position)
        """
        text_length = len(text)
        
        # Calculate rough window
        start = max(0, position - window_size // 2)
        end = min(text_length, position + window_size // 2)
        
        # Find sentence boundaries
        # Look for sentence endings before start
        sentence_endings = ['.', '!', '?']
        
        # Find start of sentence
        while start > 0 and text[start - 1] not in sentence_endings:
            start -= 1
        
        # Find end of sentence
        while end < text_length and text[end - 1] not in sentence_endings:
            end += 1
        
        return start, end
    
    def remove_duplicates(
        self,
        chunks: List[str],
        similarity_threshold: float = 0.9
    ) -> List[str]:
        """
        Remove duplicate or very similar chunks.
        
        Args:
            chunks: List of text chunks
            similarity_threshold: Similarity threshold for deduplication
            
        Returns:
            Deduplicated list of chunks
        """
        if not chunks:
            return []
        
        unique_chunks = []
        seen_signatures = set()
        
        for chunk in chunks:
            # Create signature (first 50 chars, normalized)
            signature = chunk[:50].strip().lower()
            signature = re.sub(r'\s+', ' ', signature)
            
            if signature not in seen_signatures:
                seen_signatures.add(signature)
                unique_chunks.append(chunk)
        
        return unique_chunks
    
    def highlight_query_terms(
        self,
        text: str,
        query_terms: List[str],
        highlight_tag: str = "**"
    ) -> str:
        """
        Highlight query terms in text.
        
        Args:
            text: Text to highlight
            query_terms: Terms to highlight
            highlight_tag: Tag to use for highlighting
            
        Returns:
            Text with highlighted terms
        """
        highlighted_text = text
        
        for term in query_terms:
            # Case-insensitive replacement with highlighting
            pattern = re.compile(re.escape(term), re.IGNORECASE)
            highlighted_text = pattern.sub(
                f"{highlight_tag}{term}{highlight_tag}",
                highlighted_text
            )
        
        return highlighted_text


# Global text processor instance
text_processor = TextProcessor()


# Export commonly used functions
def clean_text(text: str) -> str:
    """Clean and normalize text."""
    return text_processor.clean_text(text)


def extract_text_features(text: str) -> Dict[str, any]:
    """Extract features from text."""
    return text_processor.extract_text_features(text)


def extract_keywords(text: str, max_keywords: int = 10) -> List[str]:
    """Extract keywords from text."""
    return text_processor.extract_keywords(text, max_keywords)


# Export the processor
__all__ = [
    "TextProcessor",
    "text_processor",
    "clean_text",
    "extract_text_features",
    "extract_keywords"
]