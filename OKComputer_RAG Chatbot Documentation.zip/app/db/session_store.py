"""
Session Store Implementation

Redis-based session management for conversation persistence.
"""

import json
import time
from typing import Any, Dict, Optional

from app.core.config import settings
from app.core.logging import get_logger

logger = get_logger(__name__)


class SessionStore:
    """
    Redis-based session store for conversation and user session management.
    """
    
    def __init__(self):
        """Initialize session store."""
        self.redis_client = None
        self._initialize_redis()
    
    def _initialize_redis(self) -> None:
        """Initialize Redis connection."""
        try:
            if settings.REDIS_URL:
                import redis.asyncio as redis
                self.redis_client = redis.from_url(settings.REDIS_URL)
                logger.info("Redis session store initialized")
            else:
                logger.warning("No Redis URL configured, session persistence disabled")
        except Exception as e:
            logger.error(f"Failed to initialize session store: {e}")
            raise
    
    async def initialize(self) -> None:
        """Initialize session store."""
        if self.redis_client:
            # Test connection
            await self.redis_client.ping()
            logger.info("Session store connection verified")
    
    async def create_session(
        self,
        session_id: str,
        user_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> bool:
        """
        Create a new session.
        
        Args:
            session_id: Unique session identifier
            user_id: Optional user ID
            metadata: Optional session metadata
            
        Returns:
            True if successful, False otherwise
        """
        if not self.redis_client:
            return False
        
        try:
            session_data = {
                "session_id": session_id,
                "user_id": user_id,
                "created_at": time.time(),
                "last_activity": time.time(),
                "metadata": metadata or {}
            }
            
            key = f"session:{session_id}"
            value = json.dumps(session_data)
            
            # Set with 24-hour expiration
            await self.redis_client.setex(key, 86400, value)
            
            logger.debug(f"Session created: {session_id}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to create session: {e}")
            return False
    
    async def get_session(self, session_id: str) -> Optional[Dict[str, Any]]:
        """
        Get session data.
        
        Args:
            session_id: Session ID
            
        Returns:
            Session data or None if not found
        """
        if not self.redis_client:
            return None
        
        try:
            key = f"session:{session_id}"
            value = await self.redis_client.get(key)
            
            if value:
                session_data = json.loads(value)
                return session_data
            
            return None
            
        except Exception as e:
            logger.error(f"Failed to get session: {e}")
            return None
    
    async def update_session(
        self,
        session_id: str,
        updates: Dict[str, Any]
    ) -> bool:
        """
        Update session data.
        
        Args:
            session_id: Session ID
            updates: Updates to apply
            
        Returns:
            True if successful, False otherwise
        """
        if not self.redis_client:
            return False
        
        try:
            session_data = await self.get_session(session_id)
            if not session_data:
                return False
            
            # Update session data
            session_data.update(updates)
            session_data["last_activity"] = time.time()
            
            key = f"session:{session_id}"
            value = json.dumps(session_data)
            
            # Update with new expiration
            await self.redis_client.setex(key, 86400, value)
            
            logger.debug(f"Session updated: {session_id}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to update session: {e}")
            return False
    
    async def delete_session(self, session_id: str) -> bool:
        """
        Delete session.
        
        Args:
            session_id: Session ID
            
        Returns:
            True if successful, False otherwise
        """
        if not self.redis_client:
            return False
        
        try:
            key = f"session:{session_id}"
            await self.redis_client.delete(key)
            
            logger.debug(f"Session deleted: {session_id}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to delete session: {e}")
            return False
    
    async def get_active_sessions(self) -> int:
        """
        Get number of active sessions.
        
        Returns:
            Number of active sessions
        """
        if not self.redis_client:
            return 0
        
        try:
            keys = await self.redis_client.keys("session:*")
            return len(keys)
            
        except Exception as e:
            logger.error(f"Failed to get active sessions: {e}")
            return 0
    
    async def cleanup_expired_sessions(self) -> int:
        """
        Clean up expired sessions.
        
        Returns:
            Number of sessions cleaned up
        """
        if not self.redis_client:
            return 0
        
        try:
            # Get all session keys
            keys = await self.redis_client.keys("session:*")
            
            expired_count = 0
            current_time = time.time()
            
            for key in keys:
                try:
                    value = await self.redis_client.get(key)
                    if value:
                        session_data = json.loads(value)
                        
                        # Check if session is older than 48 hours
                        if current_time - session_data.get("last_activity", 0) > 172800:
                            await self.redis_client.delete(key)
                            expired_count += 1
                            
                except Exception as e:
                    logger.warning(f"Error checking session {key}: {e}")
            
            logger.info(f"Cleaned up {expired_count} expired sessions")
            return expired_count
            
        except Exception as e:
            logger.error(f"Failed to cleanup expired sessions: {e}")
            return 0
    
    async def get_session_stats(self) -> dict:
        """Get session statistics."""
        stats = {
            "active_sessions": await self.get_active_sessions(),
            "redis_connected": self.redis_client is not None,
            "storage_type": "redis" if self.redis_client else "none"
        }
        
        if self.redis_client:
            try:
                info = await self.redis_client.info()
                stats["redis_info"] = {
                    "connected_clients": info.get("connected_clients", 0),
                    "used_memory_mb": info.get("used_memory_rss", 0) / (1024 * 1024),
                    "total_commands_processed": info.get("total_commands_processed", 0)
                }
            except Exception as e:
                stats["redis_error"] = str(e)
        
        return stats
    
    async def close(self) -> None:
        """Close session store."""
        try:
            if self.redis_client:
                await self.redis_client.close()
                logger.info("Session store closed")
        except Exception as e:
            logger.error(f"Error closing session store: {e}")


# Global session store instance
session_store = SessionStore()


# Export the store
__all__ = ["SessionStore", "session_store"]