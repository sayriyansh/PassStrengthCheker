"""
Metadata Store Implementation

PostgreSQL-based metadata storage for documents and user data.
"""

import json
import time
from typing import Any, Dict, List, Optional

from app.core.config import settings
from app.core.logging import get_logger

logger = get_logger(__name__)


class MetadataStore:
    """
    PostgreSQL-based metadata store for document and user management.
    
    Stores:
    - Document metadata
    - User information
    - Audit logs
    - Analytics data
    """
    
    def __init__(self):
        """Initialize metadata store."""
        self.database_url = settings.DATABASE_URL
        self.pool = None
    
    async def initialize(self) -> None:
        """Initialize database connection pool."""
        if not self.database_url:
            logger.warning("No database URL configured, metadata store disabled")
            return
        
        try:
            import asyncpg
            
            self.pool = await asyncpg.create_pool(
                self.database_url,
                min_size=5,
                max_size=20,
                command_timeout=60
            )
            
            # Initialize database schema
            await self._initialize_schema()
            
            logger.info("Metadata store initialized")
            
        except Exception as e:
            logger.error(f"Failed to initialize metadata store: {e}")
            raise
    
    async def _initialize_schema(self) -> None:
        """Initialize database schema."""
        if not self.pool:
            return
        
        async with self.pool.acquire() as conn:
            # Create documents table
            await conn.execute("""
                CREATE TABLE IF NOT EXISTS documents (
                    document_id UUID PRIMARY KEY,
                    filename VARCHAR(255) NOT NULL,
                    file_size BIGINT NOT NULL,
                    document_type VARCHAR(20) NOT NULL,
                    status VARCHAR(20) NOT NULL,
                    upload_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    processing_date TIMESTAMP,
                    metadata JSONB,
                    processing_stats JSONB,
                    error_message TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Create document_chunks table
            await conn.execute("""
                CREATE TABLE IF NOT EXISTS document_chunks (
                    chunk_id VARCHAR(255) PRIMARY KEY,
                    document_id UUID REFERENCES documents(document_id) ON DELETE CASCADE,
                    content TEXT NOT NULL,
                    chunk_index INTEGER NOT NULL,
                    start_position INTEGER NOT NULL,
                    end_position INTEGER NOT NULL,
                    metadata JSONB,
                    embedding VECTOR(1536),  -- Assuming 1536-dimensional embeddings
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Create conversations table
            await conn.execute("""
                CREATE TABLE IF NOT EXISTS conversations (
                    session_id VARCHAR(255) PRIMARY KEY,
                    title VARCHAR(500),
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    metadata JSONB
                )
            """)
            
            # Create messages table
            await conn.execute("""
                CREATE TABLE IF NOT EXISTS messages (
                    message_id VARCHAR(255) PRIMARY KEY,
                    session_id VARCHAR(255) REFERENCES conversations(session_id) ON DELETE CASCADE,
                    role VARCHAR(20) NOT NULL,
                    content TEXT NOT NULL,
                    sources JSONB,
                    metadata JSONB,
                    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Create audit_logs table
            await conn.execute("""
                CREATE TABLE IF NOT EXISTS audit_logs (
                    id SERIAL PRIMARY KEY,
                    user_id VARCHAR(255),
                    action VARCHAR(100) NOT NULL,
                    resource_type VARCHAR(50) NOT NULL,
                    resource_id VARCHAR(255),
                    details JSONB,
                    ip_address INET,
                    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Create indexes
            await conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_documents_status ON documents(status)
            """)
            
            await conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_documents_type ON documents(document_type)
            """)
            
            await conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_chunks_document_id ON document_chunks(document_id)
            """)
            
            await conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_messages_session_id ON messages(session_id)
            """)
            
            await conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_audit_timestamp ON audit_logs(timestamp)
            """)
            
            logger.info("Database schema initialized")
            
        except Exception as e:
            logger.error(f"Failed to initialize schema: {e}")
            raise
    
    async def save_document(self, document_data: Dict[str, Any]) -> bool:
        """
        Save document metadata.
        
        Args:
            document_data: Document metadata
            
        Returns:
            True if successful, False otherwise
        """
        if not self.pool:
            return False
        
        try:
            async with self.pool.acquire() as conn:
                await conn.execute("""
                    INSERT INTO documents (
                        document_id, filename, file_size, document_type, status,
                        metadata, processing_stats, error_message
                    ) VALUES (
                        $1, $2, $3, $4, $5, $6, $7, $8
                    )
                    ON CONFLICT (document_id) DO UPDATE SET
                        status = EXCLUDED.status,
                        processing_date = CURRENT_TIMESTAMP,
                        metadata = EXCLUDED.metadata,
                        processing_stats = EXCLUDED.processing_stats,
                        error_message = EXCLUDED.error_message,
                        updated_at = CURRENT_TIMESTAMP
                """,
                    document_data.get("document_id"),
                    document_data.get("filename"),
                    document_data.get("file_size"),
                    document_data.get("document_type"),
                    document_data.get("status"),
                    json.dumps(document_data.get("metadata", {})),
                    json.dumps(document_data.get("processing_stats", {})),
                    document_data.get("error_message")
                )
                
                return True
                
        except Exception as e:
            logger.error(f"Failed to save document: {e}")
            return False
    
    async def get_document(self, document_id: str) -> Optional[Dict[str, Any]]:
        """
        Get document by ID.
        
        Args:
            document_id: Document ID
            
        Returns:
            Document data or None
        """
        if not self.pool:
            return None
        
        try:
            async with self.pool.acquire() as conn:
                row = await conn.fetchrow(
                    "SELECT * FROM documents WHERE document_id = $1",
                    document_id
                )
                
                if row:
                    return dict(row)
                
                return None
                
        except Exception as e:
            logger.error(f"Failed to get document: {e}")
            return None
    
    async def list_documents(
        self,
        limit: int = 50,
        offset: int = 0,
        filters: Optional[Dict[str, Any]] = None
    ) -> List[Dict[str, Any]]:
        """
        List documents with optional filters.
        
        Args:
            limit: Number of documents to return
            offset: Number of documents to skip
            filters: Optional filters
            
        Returns:
            List of documents
        """
        if not self.pool:
            return []
        
        try:
            async with self.pool.acquire() as conn:
                # Build query
                query = "SELECT * FROM documents"
                params = []
                conditions = []
                
                if filters:
                    for key, value in filters.items():
                        if key in ["document_type", "status"]:
                            conditions.append(f"{key} = ${len(params) + 1}")
                            params.append(value)
                
                if conditions:
                    query += " WHERE " + " AND ".join(conditions)
                
                query += f" ORDER BY created_at DESC LIMIT ${len(params) + 1} OFFSET ${len(params) + 2}"
                params.extend([limit, offset])
                
                rows = await conn.fetch(query, *params)
                
                return [dict(row) for row in rows]
                
        except Exception as e:
            logger.error(f"Failed to list documents: {e}")
            return []
    
    async def delete_document(self, document_id: str) -> bool:
        """
        Delete document and associated data.
        
        Args:
            document_id: Document ID
            
        Returns:
            True if successful, False otherwise
        """
        if not self.pool:
            return False
        
        try:
            async with self.pool.acquire() as conn:
                # This will cascade delete chunks due to foreign key constraint
                result = await conn.execute(
                    "DELETE FROM documents WHERE document_id = $1",
                    document_id
                )
                
                return result != "DELETE 0"
                
        except Exception as e:
            logger.error(f"Failed to delete document: {e}")
            return False
    
    async def save_conversation(self, conversation_data: Dict[str, Any]) -> bool:
        """
        Save conversation.
        
        Args:
            conversation_data: Conversation data
            
        Returns:
            True if successful, False otherwise
        """
        if not self.pool:
            return False
        
        try:
            async with self.pool.acquire() as conn:
                await conn.execute("""
                    INSERT INTO conversations (
                        session_id, title, metadata
                    ) VALUES ($1, $2, $3)
                    ON CONFLICT (session_id) DO UPDATE SET
                        title = EXCLUDED.title,
                        metadata = EXCLUDED.metadata,
                        updated_at = CURRENT_TIMESTAMP
                """,
                    conversation_data.get("session_id"),
                    conversation_data.get("title"),
                    json.dumps(conversation_data.get("metadata", {}))
                )
                
                return True
                
        except Exception as e:
            logger.error(f"Failed to save conversation: {e}")
            return False
    
    async def get_conversation(self, session_id: str) -> Optional[Dict[str, Any]]:
        """
        Get conversation by session ID.
        
        Args:
            session_id: Session ID
            
        Returns:
            Conversation data or None
        """
        if not self.pool:
            return None
        
        try:
            async with self.pool.acquire() as conn:
                # Get conversation
                conversation = await conn.fetchrow(
                    "SELECT * FROM conversations WHERE session_id = $1",
                    session_id
                )
                
                if not conversation:
                    return None
                
                # Get messages
                messages = await conn.fetch(
                    "SELECT * FROM messages WHERE session_id = $1 ORDER BY timestamp",
                    session_id
                )
                
                conversation_dict = dict(conversation)
                conversation_dict["messages"] = [dict(msg) for msg in messages]
                
                return conversation_dict
                
        except Exception as e:
            logger.error(f"Failed to get conversation: {e}")
            return None
    
    async def add_message(
        self,
        session_id: str,
        message_data: Dict[str, Any]
    ) -> bool:
        """
        Add message to conversation.
        
        Args:
            session_id: Session ID
            message_data: Message data
            
        Returns:
            True if successful, False otherwise
        """
        if not self.pool:
            return False
        
        try:
            async with self.pool.acquire() as conn:
                await conn.execute("""
                    INSERT INTO messages (
                        message_id, session_id, role, content, sources, metadata
                    ) VALUES ($1, $2, $3, $4, $5, $6)
                """,
                    message_data.get("message_id"),
                    session_id,
                    message_data.get("role"),
                    message_data.get("content"),
                    json.dumps(message_data.get("sources", [])),
                    json.dumps(message_data.get("metadata", {}))
                )
                
                # Update conversation timestamp
                await conn.execute(
                    "UPDATE conversations SET updated_at = CURRENT_TIMESTAMP WHERE session_id = $1",
                    session_id
                )
                
                return True
                
        except Exception as e:
            logger.error(f"Failed to add message: {e}")
            return False
    
    async def delete_conversation(self, session_id: str) -> bool:
        """
        Delete conversation and messages.
        
        Args:
            session_id: Session ID
            
        Returns:
            True if successful, False otherwise
        """
        if not self.pool:
            return False
        
        try:
            async with self.pool.acquire() as conn:
                # This will cascade delete messages due to foreign key constraint
                result = await conn.execute(
                    "DELETE FROM conversations WHERE session_id = $1",
                    session_id
                )
                
                return result != "DELETE 0"
                
        except Exception as e:
            logger.error(f"Failed to delete conversation: {e}")
            return False
    
    async def add_audit_log(
        self,
        action: str,
        resource_type: str,
        resource_id: Optional[str] = None,
        user_id: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
        ip_address: Optional[str] = None
    ) -> bool:
        """
        Add audit log entry.
        
        Args:
            action: Action performed
            resource_type: Type of resource
            resource_id: Resource ID
            user_id: User ID
            details: Additional details
            ip_address: IP address
            
        Returns:
            True if successful, False otherwise
        """
        if not self.pool:
            return False
        
        try:
            async with self.pool.acquire() as conn:
                await conn.execute("""
                    INSERT INTO audit_logs (
                        user_id, action, resource_type, resource_id, details, ip_address
                    ) VALUES ($1, $2, $3, $4, $5, $6)
                """,
                    user_id,
                    action,
                    resource_type,
                    resource_id,
                    json.dumps(details or {}),
                    ip_address
                )
                
                return True
                
        except Exception as e:
            logger.error(f"Failed to add audit log: {e}")
            return False
    
    async def get_stats(self) -> Dict[str, Any]:
        """Get metadata store statistics."""
        if not self.pool:
            return {"status": "disabled"}
        
        try:
            async with self.pool.acquire() as conn:
                # Count various entities
                document_count = await conn.fetchval("SELECT COUNT(*) FROM documents")
                chunk_count = await conn.fetchval("SELECT COUNT(*) FROM document_chunks")
                conversation_count = await conn.fetchval("SELECT COUNT(*) FROM conversations")
                message_count = await conn.fetchval("SELECT COUNT(*) FROM messages")
                
                return {
                    "status": "healthy",
                    "connected": True,
                    "document_count": document_count,
                    "chunk_count": chunk_count,
                    "conversation_count": conversation_count,
                    "message_count": message_count
                }
                
        except Exception as e:
            return {
                "status": "error",
                "error": str(e)
            }
    
    async def close(self) -> None:
        """Close metadata store."""
        try:
            if self.pool:
                await self.pool.close()
                logger.info("Metadata store closed")
        except Exception as e:
            logger.error(f"Error closing metadata store: {e}")


# Global metadata store instance
metadata_store = MetadataStore()


# Export the store
__all__ = ["MetadataStore", "metadata_store"]