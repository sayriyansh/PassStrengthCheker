"""
Vector Store Implementation

FAISS-based vector database for semantic search.
"""

import json
import pickle
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any

import faiss
import numpy as np

from app.core.config import settings
from app.core.logging import get_logger
from app.models.document import DocumentChunk

logger = get_logger(__name__)


class VectorStore:
    """
    FAISS-based vector store for efficient similarity search.
    """
    
    def __init__(self):
        """Initialize vector store."""
        self.index = None
        self.metadata = {}
        self.index_path = Path(settings.FAISS_INDEX_PATH)
        self.index_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Index file paths
        self.index_file = self.index_path / "faiss.index"
        self.metadata_file = self.index_path / "metadata.pkl"
        self.mapping_file = self.index_path / "id_mapping.json"
        
        # ID mapping for chunk retrieval
        self.id_mapping = {}
        self.reverse_mapping = {}
        self.next_id = 0
    
    async def initialize(self) -> None:
        """Initialize vector store - load existing or create new."""
        try:
            if self.index_file.exists():
                await self.load_index()
                logger.info(f"Loaded existing FAISS index with {len(self.metadata)} vectors")
            else:
                await self.create_new_index()
                logger.info("Created new FAISS index")
                
        except Exception as e:
            logger.error(f"Failed to initialize vector store: {e}")
            raise
    
    async def create_new_index(self) -> None:
        """Create a new FAISS index."""
        try:
            # Create index based on configured type
            if settings.FAISS_INDEX_TYPE == "IndexFlatIP":
                # Inner Product index (for normalized vectors)
                self.index = faiss.IndexFlatIP(settings.EMBEDDING_DIMENSION)
            elif settings.FAISS_INDEX_TYPE == "IndexFlatL2":
                # L2 distance index
                self.index = faiss.IndexFlatL2(settings.EMBEDDING_DIMENSION)
            elif settings.FAISS_INDEX_TYPE == "IndexIVFFlat":
                # IVF (Inverted File) index for large datasets
                nlist = 100  # Number of clusters
                quantizer = faiss.IndexFlatIP(settings.EMBEDDING_DIMENSION)
                self.index = faiss.IndexIVFFlat(
                    quantizer,
                    settings.EMBEDDING_DIMENSION,
                    nlist
                )
            else:
                # Default to IndexFlatIP
                self.index = faiss.IndexFlatIP(settings.EMBEDDING_DIMENSION)
            
            # Initialize empty metadata
            self.metadata = {}
            self.id_mapping = {}
            self.reverse_mapping = {}
            self.next_id = 0
            
            logger.info(f"Created new FAISS index: {settings.FAISS_INDEX_TYPE}")
            
        except Exception as e:
            logger.error(f"Failed to create FAISS index: {e}")
            raise
    
    async def add_embeddings(
        self,
        chunks: List[DocumentChunk],
        embeddings: List[List[float]]
    ) -> None:
        """
        Add embeddings to the index.
        
        Args:
            chunks: List of document chunks
            embeddings: List of embedding vectors
        """
        if not self.index:
            raise RuntimeError("Vector store not initialized")
        
        if len(chunks) != len(embeddings):
            raise ValueError("Number of chunks must match number of embeddings")
        
        try:
            # Convert embeddings to numpy array
            embeddings_array = np.array(embeddings).astype(np.float32)
            
            # For cosine similarity, normalize vectors
            if settings.FAISS_INDEX_TYPE in ["IndexFlatIP", "IndexIVFFlat"]:
                faiss.normalize_L2(embeddings_array)
            
            # Add to index
            self.index.add(embeddings_array)
            
            # Update metadata and mappings
            for i, (chunk, embedding) in enumerate(zip(chunks, embeddings)):
                internal_id = self.next_id + i
                
                # Store chunk metadata
                self.metadata[internal_id] = {
                    "chunk_id": chunk.chunk_id,
                    "document_id": str(chunk.document_id),
                    "content": chunk.content,
                    "metadata": chunk.metadata,
                    "embedding": embedding
                }
                
                # Update ID mappings
                self.id_mapping[chunk.chunk_id] = internal_id
                self.reverse_mapping[internal_id] = chunk.chunk_id
            
            self.next_id += len(chunks)
            
            logger.info(
                f"Added {len(chunks)} embeddings to index",
                extra={
                    "total_vectors": self.index.ntotal,
                    "chunks_added": len(chunks)
                }
            )
            
        except Exception as e:
            logger.error(f"Failed to add embeddings: {e}")
            raise
    
    async def search(
        self,
        query_embedding: List[float],
        top_k: int = 10,
        document_ids: Optional[List[str]] = None
    ) -> List[Tuple[DocumentChunk, float]]:
        """
        Search for similar vectors.
        
        Args:
            query_embedding: Query embedding vector
            top_k: Number of top results to return
            document_ids: Filter by specific document IDs
            
        Returns:
            List of (chunk, similarity_score) tuples
        """
        if not self.index or self.index.ntotal == 0:
            return []
        
        try:
            # Convert query embedding to numpy array
            query_array = np.array([query_embedding]).astype(np.float32)
            
            # Normalize query vector for cosine similarity
            if settings.FAISS_INDEX_TYPE in ["IndexFlatIP", "IndexIVFFlat"]:
                faiss.normalize_L2(query_array)
            
            # Search index
            scores, indices = self.index.search(query_array, top_k * 2)
            
            # Convert results to chunk objects
            results = []
            for score, idx in zip(scores[0], indices[0]):
                if idx == -1:  # No more results
                    break
                
                # Get chunk metadata
                chunk_data = self.metadata.get(int(idx))
                if not chunk_data:
                    continue
                
                # Create chunk object
                chunk = DocumentChunk(
                    chunk_id=chunk_data["chunk_id"],
                    document_id=chunk_data["document_id"],
                    content=chunk_data["content"],
                    metadata=chunk_data["metadata"]
                )
                
                # Filter by document IDs if specified
                if document_ids and chunk.document_id not in document_ids:
                    continue
                
                # Convert score based on index type
                if settings.FAISS_INDEX_TYPE == "IndexFlatL2":
                    # Convert L2 distance to similarity (inverse relationship)
                    similarity = 1 / (1 + score)
                else:
                    # Inner product is already a similarity score
                    similarity = float(score)
                
                results.append((chunk, similarity))
            
            # Sort by similarity and return top results
            results.sort(key=lambda x: x[1], reverse=True)
            return results[:top_k]
            
        except Exception as e:
            logger.error(f"Vector search failed: {e}")
            raise
    
    async def remove_document(self, document_id: str) -> int:
        """
        Remove all chunks for a specific document.
        
        Args:
            document_id: Document ID to remove
            
        Returns:
            Number of chunks removed
        """
        if not self.index:
            return 0
        
        try:
            # Find all chunks for this document
            chunks_to_remove = []
            for internal_id, metadata in self.metadata.items():
                if metadata["document_id"] == document_id:
                    chunks_to_remove.append(internal_id)
            
            if not chunks_to_remove:
                return 0
            
            # For FAISS, we need to rebuild the index without these vectors
            # This is a limitation of FAISS - it doesn't support direct deletion
            
            # Create new index
            old_index = self.index
            old_metadata = self.metadata.copy()
            
            await self.create_new_index()
            
            # Add back all chunks except the ones to remove
            for internal_id, metadata in old_metadata.items():
                if internal_id not in chunks_to_remove:
                    # Recreate chunk object
                    chunk = DocumentChunk(
                        chunk_id=metadata["chunk_id"],
                        document_id=metadata["document_id"],
                        content=metadata["content"],
                        metadata=metadata["metadata"]
                    )
                    embedding = metadata["embedding"]
                    
                    await self.add_embeddings([chunk], [embedding])
            
            logger.info(
                f"Removed document from index",
                extra={
                    "document_id": document_id,
                    "chunks_removed": len(chunks_to_remove),
                    "remaining_vectors": self.index.ntotal
                }
            )
            
            return len(chunks_to_remove)
            
        except Exception as e:
            logger.error(f"Failed to remove document: {e}")
            raise
    
    async def get_document_chunks(self, document_id: str) -> List[DocumentChunk]:
        """
        Get all chunks for a specific document.
        
        Args:
            document_id: Document ID
            
        Returns:
            List of document chunks
        """
        chunks = []
        
        for metadata in self.metadata.values():
            if metadata["document_id"] == document_id:
                chunk = DocumentChunk(
                    chunk_id=metadata["chunk_id"],
                    document_id=metadata["document_id"],
                    content=metadata["content"],
                    metadata=metadata["metadata"]
                )
                chunks.append(chunk)
        
        return chunks
    
    async def get_all_chunks(self) -> List[DocumentChunk]:
        """
        Get all chunks in the index.
        
        Returns:
            List of all document chunks
        """
        chunks = []
        
        for metadata in self.metadata.values():
            chunk = DocumentChunk(
                chunk_id=metadata["chunk_id"],
                document_id=metadata["document_id"],
                content=metadata["content"],
                metadata=metadata["metadata"]
            )
            chunks.append(chunk)
        
        return chunks
    
    async def save_index(self) -> None:
        """Save FAISS index and metadata to disk."""
        try:
            # Save FAISS index
            faiss.write_index(self.index, str(self.index_file))
            
            # Save metadata
            with open(self.metadata_file, "wb") as f:
                pickle.dump(self.metadata, f)
            
            # Save ID mappings
            mappings = {
                "id_mapping": self.id_mapping,
                "reverse_mapping": self.reverse_mapping,
                "next_id": self.next_id
            }
            with open(self.mapping_file, "w") as f:
                json.dump(mappings, f, indent=2)
            
            logger.info(
                f"Saved FAISS index",
                extra={
                    "index_file": str(self.index_file),
                    "total_vectors": self.index.ntotal,
                    "metadata_size": len(self.metadata)
                }
            )
            
        except Exception as e:
            logger.error(f"Failed to save FAISS index: {e}")
            raise
    
    async def load_index(self) -> None:
        """Load FAISS index and metadata from disk."""
        try:
            # Load FAISS index
            self.index = faiss.read_index(str(self.index_file))
            
            # Load metadata
            with open(self.metadata_file, "rb") as f:
                self.metadata = pickle.load(f)
            
            # Load ID mappings
            with open(self.mapping_file, "r") as f:
                mappings = json.load(f)
                self.id_mapping = mappings["id_mapping"]
                self.reverse_mapping = mappings["reverse_mapping"]
                self.next_id = mappings["next_id"]
            
            logger.info(
                f"Loaded FAISS index",
                extra={
                    "index_file": str(self.index_file),
                    "total_vectors": self.index.ntotal,
                    "metadata_size": len(self.metadata)
                }
            )
            
        except Exception as e:
            logger.error(f"Failed to load FAISS index: {e}")
            raise
    
    async def get_stats(self) -> Dict[str, any]:
        """Get vector store statistics."""
        if not self.index:
            return {"status": "uninitialized"}
        
        return {
            "status": "healthy",
            "total_vectors": self.index.ntotal,
            "dimension": self.index.d,
            "index_type": settings.FAISS_INDEX_TYPE,
            "metadata_entries": len(self.metadata),
            "index_file": str(self.index_file),
            "index_size_mb": self.index_file.stat().st_size / (1024 * 1024) if self.index_file.exists() else 0
        }
    
    async def close(self) -> None:
        """Close vector store and save state."""
        try:
            if self.index and self.index.ntotal > 0:
                await self.save_index()
            logger.info("Vector store closed successfully")
        except Exception as e:
            logger.error(f"Error closing vector store: {e}")


# Global vector store instance
vector_store = VectorStore()


# Export the vector store
__all__ = ["VectorStore", "vector_store"]