"""
Logging Configuration

Structured logging with JSON format support and configurable levels.
"""

import json
import logging
import sys
from pathlib import Path
from typing import Any, Dict, Optional

from pythonjsonlogger import jsonlogger

from app.core.config import settings


class CustomJsonFormatter(jsonlogger.JsonFormatter):
    """
    Custom JSON formatter for structured logging.
    """
    
    def add_fields(
        self,
        log_record: Dict[str, Any],
        record: logging.LogRecord,
        message_dict: Dict[str, Any]
    ) -> None:
        """
        Add custom fields to log record.
        
        Args:
            log_record: Log record dictionary
            record: Log record
            message_dict: Message dictionary
        """
        super().add_fields(log_record, record, message_dict)
        
        # Add timestamp
        log_record["timestamp"] = record.created
        
        # Add log level
        log_record["level"] = record.levelname
        
        # Add logger name
        log_record["logger"] = record.name
        
        # Add application info
        log_record["app"] = {
            "name": settings.APP_NAME,
            "version": settings.APP_VERSION,
            "environment": "development" if settings.DEBUG else "production"
        }
        
        # Add request context if available
        if hasattr(record, "request_id"):
            log_record["request_id"] = record.request_id
        
        if hasattr(record, "user_id"):
            log_record["user_id"] = record.user_id
        
        # Add exception info if present
        if record.exc_info:
            log_record["exception"] = {
                "type": record.exc_info[0].__name__ if record.exc_info[0] else None,
                "message": str(record.exc_info[1]) if record.exc_info[1] else None,
                "traceback": self.formatException(record.exc_info)
            }


def setup_logging() -> logging.Logger:
    """
    Configure application logging.
    
    Returns:
        Configured logger instance
    """
    # Root logger configuration
    root_logger = logging.getLogger()
    root_logger.setLevel(getattr(logging, settings.LOG_LEVEL.upper()))
    
    # Remove existing handlers
    root_logger.handlers.clear()
    
    # Console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(getattr(logging, settings.LOG_LEVEL.upper()))
    
    # Formatter based on configuration
    if settings.LOG_FORMAT == "json":
        formatter = CustomJsonFormatter(
            "%(timestamp)s %(level)s %(name)s %(message)s"
        )
    else:
        formatter = logging.Formatter(
            "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S"
        )
    
    console_handler.setFormatter(formatter)
    root_logger.addHandler(console_handler)
    
    # File handler if configured
    if settings.LOG_FILE:
        setup_file_handler(root_logger, formatter)
    
    # Configure third-party loggers
    configure_third_party_loggers()
    
    return logging.getLogger(__name__)


def setup_file_handler(
    logger: logging.Logger,
    formatter: logging.Formatter
) -> None:
    """
    Setup file handler with rotation.
    
    Args:
        logger: Logger instance
        formatter: Log formatter
    """
    try:
        # Create log directory if needed
        log_file = Path(settings.LOG_FILE)
        log_file.parent.mkdir(parents=True, exist_ok=True)
        
        # Rotating file handler
        from logging.handlers import RotatingFileHandler
        
        file_handler = RotatingFileHandler(
            filename=str(log_file),
            maxBytes=settings.log_max_size_bytes,
            backupCount=settings.LOG_BACKUP_COUNT,
            encoding="utf-8"
        )
        file_handler.setLevel(getattr(logging, settings.LOG_LEVEL.upper()))
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
        
    except Exception as e:
        # Log error but don't prevent app startup
        print(f"Failed to setup file handler: {e}")


def configure_third_party_loggers() -> None:
    """
    Configure log levels for third-party libraries.
    """
    # Reduce verbosity of third-party libraries
    third_party_loggers = [
        "urllib3",
        "requests",
        "httpx",
        "openai",
        "langchain",
        "faiss",
        "redis",
        "sqlalchemy"
    ]
    
    for logger_name in third_party_loggers:
        logging.getLogger(logger_name).setLevel(logging.WARNING)


def get_logger(name: str) -> logging.Logger:
    """
    Get a logger instance with the specified name.
    
    Args:
        name: Logger name
        
    Returns:
        Logger instance
    """
    return logging.getLogger(name)


def log_request(
    logger: logging.Logger,
    request_id: str,
    method: str,
    path: str,
    status_code: int,
    duration: float,
    user_id: Optional[str] = None,
    **kwargs
) -> None:
    """
    Log HTTP request information.
    
    Args:
        logger: Logger instance
        request_id: Unique request ID
        method: HTTP method
        path: Request path
        status_code: Response status code
        duration: Request duration in seconds
        user_id: Optional user ID
        **kwargs: Additional context
    """
    logger.info(
        "Request completed",
        extra={
            "request_id": request_id,
            "user_id": user_id,
            "request": {
                "method": method,
                "path": path
            },
            "response": {
                "status_code": status_code,
                "duration": duration
            },
            **kwargs
        }
    )


def log_error(
    logger: logging.Logger,
    error: Exception,
    request_id: Optional[str] = None,
    user_id: Optional[str] = None,
    **kwargs
) -> None:
    """
    Log error with context.
    
    Args:
        logger: Logger instance
        error: Exception instance
        request_id: Optional request ID
        user_id: Optional user ID
        **kwargs: Additional context
    """
    logger.error(
        str(error),
        exc_info=True,
        extra={
            "request_id": request_id,
            "user_id": user_id,
            "error_type": type(error).__name__,
            **kwargs
        }
    )


# Export commonly used functions
__all__ = [
    "setup_logging",
    "get_logger",
    "log_request",
    "log_error"
]