"""
Security and Authentication Module

Handles API security, rate limiting, and input validation.
"""

import secrets
import time
from typing import Optional

from fastapi import HTTPException, Request, Security
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from passlib.context import CryptContext

from app.core.config import settings
from app.core.logging import get_logger

# Security logger
security_logger = get_logger("security")

# Password hashing context
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# API Key security scheme
api_key_header = HTTPBearer(auto_error=False)


class RateLimiter:
    """
    Simple in-memory rate limiter.
    
    For production, consider using Redis-based rate limiting.
    """
    
    def __init__(self):
        self.requests = {}
        self.window_size = 60  # 1 minute
        self.max_requests = settings.RATE_LIMIT_REQUESTS_PER_MINUTE
        self.burst_limit = settings.RATE_LIMIT_BURST
    
    def is_allowed(self, identifier: str) -> bool:
        """
        Check if request is within rate limits.
        
        Args:
            identifier: Client identifier (IP or API key)
            
        Returns:
            True if allowed, False if rate limited
        """
        current_time = time.time()
        
        # Clean old entries
        self._clean_old_entries(current_time)
        
        # Get or create request history
        if identifier not in self.requests:
            self.requests[identifier] = []
        
        request_times = self.requests[identifier]
        
        # Remove requests outside window
        cutoff_time = current_time - self.window_size
        request_times[:] = [t for t in request_times if t > cutoff_time]
        
        # Check burst limit
        recent_requests = [t for t in request_times if t > current_time - 10]
        if len(recent_requests) >= self.burst_limit:
            return False
        
        # Check overall limit
        if len(request_times) >= self.max_requests:
            return False
        
        # Record this request
        request_times.append(current_time)
        return True
    
    def _clean_old_entries(self, current_time: float) -> None:
        """Clean entries older than 2 windows."""
        cutoff_time = current_time - (2 * self.window_size)
        to_remove = [
            identifier for identifier, times in self.requests.items()
            if not any(t > cutoff_time for t in times)
        ]
        for identifier in to_remove:
            del self.requests[identifier]


# Global rate limiter instance
rate_limiter = RateLimiter()


def verify_api_key(
    credentials: HTTPAuthorizationCredentials = Security(api_key_header)
) -> str:
    """
    Verify API key from request.
    
    Args:
        credentials: HTTP authorization credentials
        
    Returns:
        Validated API key
        
    Raises:
        HTTPException: If API key is invalid
    """
    if not credentials:
        raise HTTPException(
            status_code=401,
            detail="API key required"
        )
    
    # In production, validate against database or key management service
    # For now, we'll use a simple comparison with environment variable
    valid_keys = [
        settings.SECRET_KEY,  # Use secret key as API key for simplicity
        "dev_api_key_123",    # Development key
    ]
    
    if credentials.credentials not in valid_keys:
        security_logger.warning(
            "Invalid API key attempted",
            extra={"api_key": credentials.credentials[:10] + "..."}
        )
        raise HTTPException(
            status_code=401,
            detail="Invalid API key"
        )
    
    return credentials.credentials


def get_client_identifier(request: Request) -> str:
    """
    Get unique identifier for rate limiting.
    
    Args:
        request: FastAPI request object
        
    Returns:
        Client identifier string
    """
    # Try to get from API key first
    auth_header = request.headers.get("Authorization")
    if auth_header and auth_header.startswith("Bearer "):
        return f"api_key:{auth_header[7:]}"
    
    # Fall back to IP address
    forwarded = request.headers.get("X-Forwarded-For")
    if forwarded:
        return forwarded.split(",")[0].strip()
    
    return request.client.host


def check_rate_limit(request: Request) -> bool:
    """
    Check if request is within rate limits.
    
    Args:
        request: FastAPI request object
        
    Returns:
        True if allowed, False if rate limited
    """
    identifier = get_client_identifier(request)
    return rate_limiter.is_allowed(identifier)


def generate_request_id() -> str:
    """
    Generate unique request ID.
    
    Returns:
        Unique request ID string
    """
    return secrets.token_urlsafe(16)


def sanitize_input(text: str, max_length: int = 10000) -> str:
    """
    Sanitize user input.
    
    Args:
        text: Input text to sanitize
        max_length: Maximum allowed length
        
    Returns:
        Sanitized text
        
    Raises:
        ValueException: If input is invalid
    """
    if not text:
        return ""
    
    # Check length
    if len(text) > max_length:
        raise ValueError(f"Input too long. Maximum {max_length} characters allowed.")
    
    # Basic sanitization - remove control characters
    sanitized = "".join(char for char in text if ord(char) >= 32 or char in "\n\r\t")
    
    # Strip whitespace
    sanitized = sanitized.strip()
    
    return sanitized


def hash_password(password: str) -> str:
    """
    Hash a password.
    
    Args:
        password: Plain text password
        
    Returns:
        Hashed password
    """
    return pwd_context.hash(password)


def verify_password(password: str, hashed_password: str) -> bool:
    """
    Verify a password against its hash.
    
    Args:
        password: Plain text password
        hashed_password: Hashed password
        
    Returns:
        True if password matches, False otherwise
    """
    return pwd_context.verify(password, hashed_password)


async def security_middleware(request: Request, call_next):
    """
    Security middleware for request processing.
    
    Args:
        request: FastAPI request
        call_next: Next middleware in chain
        
    Returns:
        Response
    """
    # Generate request ID
    request_id = generate_request_id()
    request.state.request_id = request_id
    
    # Check rate limiting
    if not check_rate_limit(request):
        security_logger.warning(
            "Rate limit exceeded",
            extra={
                "request_id": request_id,
                "client": get_client_identifier(request),
                "path": request.url.path
            }
        )
        raise HTTPException(
            status_code=429,
            detail="Rate limit exceeded. Try again later."
        )
    
    # Log request
    security_logger.info(
        "Request started",
        extra={
            "request_id": request_id,
            "method": request.method,
            "path": request.url.path,
            "client": get_client_identifier(request)
        }
    )
    
    # Process request
    response = await call_next(request)
    
    # Log response
    security_logger.info(
        "Request completed",
        extra={
            "request_id": request_id,
            "status_code": response.status_code,
            "path": request.url.path
        }
    )
    
    return response


# Export security utilities
__all__ = [
    "verify_api_key",
    "check_rate_limit",
    "get_client_identifier",
    "generate_request_id",
    "sanitize_input",
    "hash_password",
    "verify_password",
    "security_middleware"
]