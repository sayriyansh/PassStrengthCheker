"""
Application Configuration Management

Uses Pydantic Settings for environment-based configuration management.
"""

import json
from pathlib import Path
from typing import List, Optional, Union

from pydantic import Field, validator
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """
    Application settings with environment variable support.
    """
    
    # Application Information
    APP_NAME: str = Field(default="RAG Chatbot", description="Application name")
    APP_VERSION: str = Field(default="1.0.0", description="Application version")
    APP_DESCRIPTION: str = Field(
        default="Enterprise RAG Chatbot with Zero Hallucination",
        description="Application description"
    )
    
    # Server Configuration
    APP_HOST: str = Field(default="0.0.0.0", description="Application host")
    APP_PORT: int = Field(default=8000, description="Application port")
    APP_RELOAD: bool = Field(default=False, description="Enable auto-reload")
    DEBUG: bool = Field(default=False, description="Debug mode")
    
    # Security
    SECRET_KEY: str = Field(description="Secret key for encryption")
    JWT_ALGORITHM: str = Field(default="HS256", description="JWT algorithm")
    JWT_EXPIRATION_MINUTES: int = Field(
        default=10080, description="JWT expiration in minutes"
    )
    
    # CORS and Hosts
    ALLOWED_HOSTS: List[str] = Field(
        default=["*"],
        description="Allowed host patterns"
    )
    CORS_ORIGINS: List[str] = Field(
        default=["http://localhost:3000", "http://localhost:8501"],
        description="CORS allowed origins"
    )
    
    # API Configuration
    RATE_LIMIT_REQUESTS_PER_MINUTE: int = Field(
        default=60, description="Rate limit per minute"
    )
    RATE_LIMIT_BURST: int = Field(
        default=10, description="Rate limit burst"
    )
    
    # LLM Configuration
    LLM_MODEL: str = Field(
        default="gpt-4", description="LLM model name"
    )
    LLM_TEMPERATURE: float = Field(
        default=0.1, description="LLM temperature"
    )
    LLM_MAX_TOKENS: int = Field(
        default=1000, description="LLM max tokens"
    )
    LLM_STREAMING: bool = Field(
        default=True, description="Enable streaming responses"
    )
    
    # Embedding Configuration
    EMBEDDING_MODEL: str = Field(
        default="text-embedding-ada-002",
        description="Embedding model name"
    )
    EMBEDDING_DIMENSION: int = Field(
        default=1536, description="Embedding dimension"
    )
    
    # OpenAI API Configuration
    OPENAI_API_KEY: Optional[str] = Field(
        default=None, description="OpenAI API key"
    )
    OPENAI_API_BASE: str = Field(
        default="https://api.openai.com/v1",
        description="OpenAI API base URL"
    )
    
    # Kimi API Configuration (Alternative)
    KIMI_API_KEY: Optional[str] = Field(
        default=None, description="Kimi API key"
    )
    KIMI_API_BASE: str = Field(
        default="https://api.kimi.com/v1",
        description="Kimi API base URL"
    )
    
    # Database Configuration
    REDIS_URL: str = Field(
        default="redis://localhost:6379/0",
        description="Redis connection URL"
    )
    DATABASE_URL: Optional[str] = Field(
        default=None, description="PostgreSQL connection URL"
    )
    
    # Document Processing
    MAX_FILE_SIZE: str = Field(
        default="50MB", description="Maximum file upload size"
    )
    ALLOWED_EXTENSIONS: List[str] = Field(
        default=["pdf", "txt", "docx", "csv"],
        description="Allowed file extensions"
    )
    
    # RAG Configuration
    CHUNK_SIZE: int = Field(
        default=1000, description="Document chunk size"
    )
    CHUNK_OVERLAP: int = Field(
        default=100, description="Chunk overlap size"
    )
    SIMILARITY_THRESHOLD: float = Field(
        default=0.7, description="Similarity threshold"
    )
    TOP_K_CHUNKS: int = Field(
        default=7, description="Number of chunks to retrieve"
    )
    MAX_CONTEXT_TOKENS: int = Field(
        default=4000, description="Maximum context tokens"
    )
    
    # Vector Database
    FAISS_INDEX_PATH: Path = Field(
        default=Path("./data/faiss_index"),
        description="FAISS index path"
    )
    FAISS_INDEX_TYPE: str = Field(
        default="IndexFlatIP", description="FAISS index type"
    )
    
    # Logging Configuration
    LOG_LEVEL: str = Field(
        default="INFO", description="Log level"
    )
    LOG_FORMAT: str = Field(
        default="json", description="Log format"
    )
    LOG_FILE: Optional[Path] = Field(
        default=None, description="Log file path"
    )
    LOG_MAX_SIZE: str = Field(
        default="100MB", description="Maximum log file size"
    )
    LOG_BACKUP_COUNT: int = Field(
        default=5, description="Number of log backups"
    )
    
    # Performance Monitoring
    PROMETHEUS_ENABLED: bool = Field(
        default=False, description="Enable Prometheus metrics"
    )
    PROMETHEUS_PORT: int = Field(
        default=8001, description="Prometheus metrics port"
    )
    
    # Development Settings
    DEV_MODE: bool = Field(
        default=False, description="Development mode"
    )
    TESTING: bool = Field(
        default=False, description="Testing mode"
    )
    
    @validator("CORS_ORIGINS", pre=True)
    def parse_cors_origins(cls, v):
        """Parse CORS origins from string or list."""
        if isinstance(v, str):
            return [origin.strip() for origin in v.split(",")]
        return v
    
    @validator("ALLOWED_EXTENSIONS", pre=True)
    def parse_allowed_extensions(cls, v):
        """Parse allowed extensions from string or list."""
        if isinstance(v, str):
            return [ext.strip() for ext in v.split(",")]
        return v
    
    @validator("SECRET_KEY", pre=True)
    def validate_secret_key(cls, v):
        """Validate that secret key is set in production."""
        if not v or v == "your_super_secret_key_here_change_in_production":
            if not cls.DEBUG:
                raise ValueError(
                    "SECRET_KEY must be set to a secure value in production"
                )
        return v
    
    @property
    def max_file_size_bytes(self) -> int:
        """Convert MAX_FILE_SIZE to bytes."""
        size_str = self.MAX_FILE_SIZE.upper()
        if size_str.endswith("KB"):
            return int(size_str[:-2]) * 1024
        elif size_str.endswith("MB"):
            return int(size_str[:-2]) * 1024 * 1024
        elif size_str.endswith("GB"):
            return int(size_str[:-2]) * 1024 * 1024 * 1024
        else:
            return int(size_str)
    
    @property
    def log_max_size_bytes(self) -> int:
        """Convert LOG_MAX_SIZE to bytes."""
        size_str = self.LOG_MAX_SIZE.upper()
        if size_str.endswith("KB"):
            return int(size_str[:-2]) * 1024
        elif size_str.endswith("MB"):
            return int(size_str[:-2]) * 1024 * 1024
        elif size_str.endswith("GB"):
            return int(size_str[:-2]) * 1024 * 1024 * 1024
        else:
            return int(size_str)
    
    @property
    def llm_api_key(self) -> str:
        """Get the primary LLM API key."""
        return self.OPENAI_API_KEY or self.KIMI_API_KEY or ""
    
    @property
    def llm_api_base(self) -> str:
        """Get the primary LLM API base URL."""
        if self.OPENAI_API_KEY:
            return self.OPENAI_API_BASE
        elif self.KIMI_API_KEY:
            return self.KIMI_API_BASE
        else:
            return self.OPENAI_API_BASE
    
    class Config:
        """Pydantic settings configuration."""
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = True


# Global settings instance
settings = Settings()