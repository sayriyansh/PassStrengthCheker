# Project Structure and Module Responsibilities

## Project Overview

The RAG Chatbot project follows a modular, production-ready architecture with clear separation of concerns. Each module has specific responsibilities and interfaces with other components through well-defined APIs.

## Folder Structure

```
rag-chatbot/
├── app/
│   ├── __init__.py
│   ├── main.py                    # FastAPI application entry point
│   ├── api/
│   │   ├── __init__.py
│   │   ├── v1/
│   │   │   ├── __init__.py
│   │   │   ├── endpoints/
│   │   │   │   ├── __init__.py
│   │   │   │   ├── documents.py  # Document upload endpoints
│   │   │   │   ├── chat.py       # Chat and query endpoints
│   │   │   │   ├── health.py     # Health check endpoints
│   │   │   │   └── admin.py      # Admin endpoints
│   │   │   └── api.py            # API router configuration
│   │   └── dependencies.py       # Shared dependencies
│   ├── core/
│   │   ├── __init__.py
│   │   ├── config.py             # Configuration management
│   │   ├── security.py           # Security and authentication
│   │   └── logging.py            # Logging configuration
│   ├── models/
│   │   ├── __init__.py
│   │   ├── document.py           # Document data models
│   │   ├── chat.py               # Chat and conversation models
│   │   └── response.py           # Response data models
│   ├── services/
│   │   ├── __init__.py
│   │   ├── document_processor.py # Document processing service
│   │   ├── embedding_service.py  # Embedding generation service
│   │   ├── retrieval_service.py  # Document retrieval service
│   │   ├── llm_service.py        # LLM integration service
│   │   ├── chat_service.py       # Conversation management
│   │   └── cache_service.py      # Caching layer
│   ├── db/
│   │   ├── __init__.py
│   │   ├── vector_store.py       # FAISS vector database
│   │   ├── session_store.py      # Redis session management
│   │   └── metadata_store.py     # PostgreSQL metadata storage
│   └── utils/
│       ├── __init__.py
│       ├── file_handlers.py      # File format handlers
│       ├── text_processing.py    # Text cleaning and chunking
│       ├── validators.py         # Input validation utilities
│       └── exceptions.py         # Custom exceptions
├── streamlit_app/
│   ├── __init__.py
│   ├── app.py                    # Streamlit UI application
│   ├── components/
│   │   ├── __init__.py
│   │   ├── upload.py             # File upload component
│   │   ├── chat.py               # Chat interface component
│   │   └── sidebar.py            # Sidebar configuration
│   └── utils/
│       ├── __init__.py
│       └── api_client.py         # FastAPI client
├── rag_pipeline/
│   ├── __init__.py
│   ├── document_loader.py        # Multi-format document loading
│   ├── text_splitter.py          # Intelligent text chunking
│   ├── embeddings.py             # Embedding generation
│   ├── vector_store.py           # Vector database operations
│   ├── retriever.py              # Context retrieval logic
│   ├── generator.py              # Response generation
│   └── pipeline.py               # Main RAG pipeline orchestrator
├── tests/
│   ├── __init__.py
│   ├── unit/
│   │   ├── test_document_processor.py
│   │   ├── test_embedding_service.py
│   │   └── test_retrieval_service.py
│   ├── integration/
│   │   ├── test_api_endpoints.py
│   │   └── test_rag_pipeline.py
│   └── fixtures/
│       ├── sample_documents/
│       └── test_data.py
├── scripts/
│   ├── setup_faiss_index.py      # Initialize vector database
│   ├── process_documents.py      # Batch document processing
│   └── evaluate_pipeline.py      # Pipeline evaluation tools
├── docker/
│   ├── Dockerfile.fastapi        # FastAPI service container
│   ├── Dockerfile.streamlit      # Streamlit app container
│   └── docker-compose.yml        # Multi-service deployment
├── config/
│   ├── app_config.yaml           # Application configuration
│   ├── logging_config.yaml       # Logging configuration
│   └── prompts.yaml              # LLM prompt templates
├── logs/
├── requirements.txt              # Python dependencies
├── requirements-dev.txt          # Development dependencies
├── .env.example                  # Environment variables template
├── .gitignore                    # Git ignore rules
├── README.md                     # Project documentation
└── LICENSE                       # License file
```

## Module Responsibilities

### 1. FastAPI Application (`app/`)

#### `main.py`
**Responsibility**: Application entry point and lifecycle management
- FastAPI app initialization
- Middleware configuration
- Exception handlers
- Application startup/shutdown events
- CORS configuration

#### `api/v1/endpoints/`

**`documents.py`**
- File upload endpoints (single/multiple)
- Document status checking
- Document deletion and management
- Upload progress tracking

**`chat.py`**
- Query processing endpoint
- Conversation history retrieval
- Chat session management
- Real-time response streaming

**`health.py`**
- Health check endpoint
- Service dependency checks
- System status reporting

**`admin.py`**
- System statistics
- User management (if multi-user)
- Configuration management

#### `core/`

**`config.py`**
- Environment variable management
- Configuration validation
- Settings class using Pydantic
- Environment-specific configurations

**`security.py`**
- API key authentication
- Request validation
- Rate limiting implementation
- Security headers

**`logging.py`**
- Structured logging setup
- Log format configuration
- Log level management
- External logging service integration

#### `models/`

**`document.py`**
- Document metadata models
- File upload request/response models
- Document processing status models

**`chat.py`**
- Chat request/response models
- Conversation history models
- Message models

**`response.py`**
- Standard API response wrappers
- Error response models
- Pagination models

#### `services/`

**`document_processor.py`**
- Multi-format document parsing
- Text extraction and cleaning
- Document chunking logic
- Metadata extraction

**`embedding_service.py`**
- Embedding generation using external APIs
- Batch processing optimization
- Embedding cache management
- Quality validation

**`retrieval_service.py`**
- Semantic search implementation
- Context assembly and formatting
- Relevance scoring
- Source attribution

**`llm_service.py`**
- LLM API integration
- Prompt template management
- Response generation
- Token usage tracking

**`chat_service.py`**
- Conversation session management
- Context maintenance
- Message history storage
- Conversation analytics

**`cache_service.py`**
- Redis cache operations
- Cache invalidation logic
- Performance optimization
- Cache hit/miss tracking

#### `db/`

**`vector_store.py`**
- FAISS index management
- Vector similarity search
- Index persistence and loading
- Index optimization

**`session_store.py`**
- Redis session operations
- Conversation state management
- Session expiration handling
- Multi-user session isolation

**`metadata_store.py`**
- PostgreSQL database operations
- Document metadata storage
- User analytics storage
- Audit log storage

#### `utils/`

**`file_handlers.py`**
- File format detection
- Parser selection and execution
- File validation utilities
- Streaming file processing

**`text_processing.py`**
- Text cleaning functions
- Language detection
- Sentence tokenization
- Chunking algorithms

**`validators.py`**
- Input validation functions
- File size and type validation
- Query validation
- Response validation

**`exceptions.py`**
- Custom exception classes
- Exception handling utilities
- Error code definitions

### 2. Streamlit Frontend (`streamlit_app/`)

#### `app.py`
**Responsibility**: Main Streamlit application
- Page configuration
- Session state management
- Navigation logic
- Main UI layout

#### `components/`

**`upload.py`**
- File upload interface
- Upload progress indicators
- File preview functionality
- Batch upload support

**`chat.py`**
- Chat interface
- Message display
- Real-time response streaming
- Source citation display

**`sidebar.py`**
- Configuration panel
- Document management
- Settings interface
- Help and documentation links

#### `utils/api_client.py`
- FastAPI client wrapper
- HTTP request handling
- Error handling and retries
- Response parsing

### 3. RAG Pipeline (`rag_pipeline/`)

#### `document_loader.py`
- Abstract document loader interface
- Format-specific loader implementations
- Lazy loading for large files
- Error handling and recovery

#### `text_splitter.py`
- Intelligent text chunking
- Semantic chunking using embeddings
- Overlap management
- Chunk quality scoring

#### `embeddings.py`
- Embedding model abstraction
- Batch embedding generation
- Embedding cache management
- Multiple model support

#### `vector_store.py`
- Vector database operations
- Index management
- Similarity search implementation
- Index optimization

#### `retriever.py`
- Multi-stage retrieval logic
- Re-ranking implementation
- Context assembly
- Relevance scoring

#### `generator.py`
- LLM response generation
- Prompt engineering
- Response validation
- Token management

#### `pipeline.py`
- Pipeline orchestration
- Component coordination
- Error handling and recovery
- Performance monitoring

### 4. Tests (`tests/`)

#### `unit/`
- Individual component testing
- Mock external dependencies
- Edge case testing
- Performance testing

#### `integration/`
- API endpoint testing
- Database integration tests
- External service integration
- End-to-end workflow testing

#### `fixtures/`
- Test data and documents
- Mock responses
- Sample configurations

### 5. Scripts (`scripts/`)

#### `setup_faiss_index.py`
- Initialize FAISS index
- Configure index parameters
- Load initial data
- Index optimization

#### `process_documents.py`
- Batch document processing
- Background job execution
- Progress tracking
- Error reporting

#### `evaluate_pipeline.py`
- Pipeline performance evaluation
- Quality metrics calculation
- Benchmark comparisons
- Optimization suggestions

### 6. Docker (`docker/`)

#### `Dockerfile.fastapi`
- FastAPI service containerization
- Dependency installation
- Container optimization
- Health checks

#### `Dockerfile.streamlit`
- Streamlit app containerization
- Frontend dependencies
- Container configuration

#### `docker-compose.yml`
- Multi-service orchestration
- Network configuration
- Volume mounting
- Environment setup

### 7. Configuration (`config/`)

#### `app_config.yaml`
- Application settings
- Feature flags
- Performance tuning parameters
- Environment-specific overrides

#### `logging_config.yaml`
- Logging levels and formats
- Handler configurations
- External log aggregation
- Log rotation settings

#### `prompts.yaml`
- LLM prompt templates
- System prompts
- Response format specifications
- Prompt versioning

## Inter-Module Communication

### API Communication Flow
1. **Streamlit Frontend** → **FastAPI Backend**: HTTP requests
2. **FastAPI Endpoints** → **Services**: Direct function calls
3. **Services** → **Database Layer**: Data access operations
4. **Services** → **External APIs**: LLM and embedding services
5. **RAG Pipeline** → **All Services**: Orchestrated workflow

### Data Flow
1. **File Upload** → **Document Processor** → **Text Chunks**
2. **Text Chunks** → **Embedding Service** → **Vector Embeddings**
3. **Vector Embeddings** → **Vector Store** → **FAISS Index**
4. **User Query** → **Retrieval Service** → **Relevant Chunks**
5. **Relevant Chunks** → **LLM Service** → **Generated Response**
6. **Response** → **Chat Service** → **Conversation History**

### Configuration Management
- Environment variables for sensitive data
- YAML files for application settings
- Version control for configuration changes
- Environment-specific configurations

This modular structure ensures maintainability, scalability, and clear separation of concerns while facilitating testing and deployment.