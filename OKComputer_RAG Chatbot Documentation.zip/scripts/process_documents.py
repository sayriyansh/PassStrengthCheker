#!/usr/bin/env python3
"""
Batch Document Processing Script

Script to process multiple documents in batch.
"""

import asyncio
import sys
from pathlib import Path
from typing import List

# Add project root to path
sys.path.append(str(Path(__file__).parent.parent))

from app.core.config import settings
from app.core.logging import get_logger, setup_logging
from app.services.document_processor import document_processor

logger = get_logger(__name__)


async def process_documents_batch(
    file_paths: List[Path],
    batch_size: int = 5
) -> None:
    """
    Process multiple documents in batch.
    
    Args:
        file_paths: List of file paths to process
        batch_size: Number of documents to process concurrently
    """
    logger.info(f"Starting batch processing of {len(file_paths)} documents")
    
    # Process in batches
    for i in range(0, len(file_paths), batch_size):
        batch = file_paths[i:i + batch_size]
        
        logger.info(f"Processing batch {i//batch_size + 1}: {len(batch)} documents")
        
        # Create tasks for concurrent processing
        tasks = []
        for file_path in batch:
            if file_path.exists():
                # Generate document ID
                from uuid import uuid4
                document_id = uuid4()
                
                task = document_processor.process_document(
                    file_path,
                    document_id,
                    file_path.name
                )
                tasks.append(task)
            else:
                logger.warning(f"File not found: {file_path}")
        
        # Process batch
        if tasks:
            results = await asyncio.gather(*tasks, return_exceptions=True)
            
            # Log results
            for j, result in enumerate(results):
                if isinstance(result, Exception):
                    logger.error(f"Failed to process {batch[j]}: {result}")
                else:
                    document, chunks = result
                    logger.info(
                        f"Successfully processed {batch[j]}":
                        f"{len(chunks)} chunks created"
                    )
        
        logger.info(f"Batch {i//batch_size + 1} completed")
    
    logger.info("Batch processing completed!")


def main() -> None:
    """Main function."""
    import argparse
    
    # Setup logging
    setup_logging()
    
    # Parse arguments
    parser = argparse.ArgumentParser(description="Batch document processing")
    parser.add_argument(
        "files",
        nargs="+",
        help="Document files to process"
    )
    parser.add_argument(
        "--batch-size",
        type=int,
        default=5,
        help="Number of documents to process concurrently"
    )
    
    args = parser.parse_args()
    
    # Convert to Path objects
    file_paths = [Path(f) for f in args.files]
    
    logger.info("Batch Document Processing Script")
    logger.info(f"Files to process: {len(file_paths)}")
    logger.info(f"Batch size: {args.batch_size}")
    
    # Run async processing
    asyncio.run(process_documents_batch(file_paths, args.batch_size))
    
    logger.info("Processing completed!")


if __name__ == "__main__":
    main()