#!/usr/bin/env python3
"""
Initialize FAISS Vector Database

Script to set up the FAISS index for vector storage.
"""

import asyncio
import sys
from pathlib import Path

# Add project root to path
sys.path.append(str(Path(__file__).parent.parent))

from app.core.config import settings
from app.core.logging import get_logger, setup_logging
from app.db.vector_store import VectorStore

logger = get_logger(__name__)


async def setup_faiss_index() -> None:
    """Initialize FAISS vector database."""
    try:
        logger.info("Starting FAISS index setup...")
        
        # Create vector store
        vector_store = VectorStore()
        
        # Initialize
        await vector_store.initialize()
        
        # Create new index
        await vector_store.create_new_index()
        
        # Save index
        await vector_store.save_index()
        
        logger.info("FAISS index setup completed successfully!")
        
        # Get and display stats
        stats = await vector_store.get_stats()
        logger.info(f"Vector store stats: {stats}")
        
    except Exception as e:
        logger.error(f"FAISS index setup failed: {e}")
        raise


def main() -> None:
    """Main function."""
    # Setup logging
    setup_logging()
    
    logger.info("FAISS Index Setup Script")
    logger.info(f"Configuration:")
    logger.info(f"  - Index Path: {settings.FAISS_INDEX_PATH}")
    logger.info(f"  - Index Type: {settings.FAISS_INDEX_TYPE}")
    logger.info(f"  - Embedding Dimension: {settings.EMBEDDING_DIMENSION}")
    
    # Run async setup
    asyncio.run(setup_faiss_index())
    
    logger.info("Setup completed!")


if __name__ == "__main__":
    main()