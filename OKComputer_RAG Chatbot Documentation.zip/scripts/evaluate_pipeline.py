#!/usr/bin/env python3
"""
RAG Pipeline Evaluation Script

Script to evaluate the performance and quality of the RAG pipeline.
"""

import asyncio
import json
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

# Add project root to path
sys.path.append(str(Path(__file__).parent.parent))

from app.core.config import settings
from app.core.logging import get_logger, setup_logging
from app.services.embedding_service import embedding_service
from app.services.llm_service import llm_service
from app.services.retrieval_service import retrieval_service

logger = get_logger(__name__)


class PipelineEvaluator:
    """RAG pipeline evaluation utilities."""
    
    def __init__(self):
        """Initialize evaluator."""
        self.results = {}
    
    async def evaluate_retrieval_quality(
        self,
        test_queries: List[Tuple[str, List[str]]],
        top_k: int = 10
    ) -> Dict[str, float]:
        """
        Evaluate retrieval quality using test queries.
        
        Args:
            test_queries: List of (query, expected_doc_ids) tuples
            top_k: Number of top results to retrieve
            
        Returns:
            Retrieval quality metrics
        """
        logger.info("Evaluating retrieval quality...")
        
        total_queries = len(test_queries)
        precision_scores = []
        recall_scores = []
        
        for query, expected_docs in test_queries:
            try:
                # Retrieve context
                results = await retrieval_service.retrieve_context(
                    query=query,
                    top_k=top_k
                )
                
                # Extract retrieved document IDs
                retrieved_docs = [str(chunk.document_id) for chunk, _ in results]
                
                # Calculate precision and recall
                relevant_retrieved = len(set(retrieved_docs) & set(expected_docs))
                
                precision = relevant_retrieved / len(retrieved_docs) if retrieved_docs else 0
                recall = relevant_retrieved / len(expected_docs) if expected_docs else 0
                
                precision_scores.append(precision)
                recall_scores.append(recall)
                
            except Exception as e:
                logger.error(f"Error evaluating query '{query}': {e}")
                precision_scores.append(0)
                recall_scores.append(0)
        
        avg_precision = sum(precision_scores) / len(precision_scores) if precision_scores else 0
        avg_recall = sum(recall_scores) / len(recall_scores) if recall_scores else 0
        avg_f1 = 2 * (avg_precision * avg_recall) / (avg_precision + avg_recall) if (avg_precision + avg_recall) > 0 else 0
        
        return {
            "precision": avg_precision,
            "recall": avg_recall,
            "f1_score": avg_f1,
            "queries_evaluated": total_queries
        }
    
    async def evaluate_response_quality(
        self,
        test_pairs: List[Tuple[str, str, str]]
    ) -> Dict[str, float]:
        """
        Evaluate response quality using test pairs.
        
        Args:
            test_pairs: List of (query, context, expected_answer) tuples
            
        Returns:
            Response quality metrics
        """
        logger.info("Evaluating response quality...")
        
        total_pairs = len(test_pairs)
        faithfulness_scores = []
        relevance_scores = []
        
        for query, context, expected in test_pairs:
            try:
                # Generate response
                response = await llm_service.generate_response(
                    query=query,
                    context=context
                )
                
                # Calculate faithfulness (response should only use context)
                faithfulness = self._calculate_faithfulness(response, context)
                faithfulness_scores.append(faithfulness)
                
                # Calculate relevance (response should answer the query)
                relevance = self._calculate_relevance(response, query, expected)
                relevance_scores.append(relevance)
                
            except Exception as e:
                logger.error(f"Error evaluating response for query '{query}': {e}")
                faithfulness_scores.append(0)
                relevance_scores.append(0)
        
        avg_faithfulness = sum(faithfulness_scores) / len(faithfulness_scores) if faithfulness_scores else 0
        avg_relevance = sum(relevance_scores) / len(relevance_scores) if relevance_scores else 0
        
        return {
            "faithfulness": avg_faithfulness,
            "relevance": avg_relevance,
            "pairs_evaluated": total_pairs
        }
    
    async def evaluate_performance(
        self, test_queries: List[str]) -> Dict[str, float]:
        """
        Evaluate system performance.
        
        Args:
            test_queries: List of test queries
            
        Returns:
            Performance metrics
        """
        logger.info("Evaluating system performance...")
        
        retrieval_times = []
        generation_times = []
        total_times = []
        
        for query in test_queries:
            try:
                start_time = time.time()
                
                # Measure retrieval time
                retrieval_start = time.time()
                context, sources = await retrieval_service.retrieve_context_with_sources(
                    query=query
                )
                retrieval_time = time.time() - retrieval_start
                retrieval_times.append(retrieval_time)
                
                # Measure generation time
                generation_start = time.time()
                response = await llm_service.generate_response(
                    query=query,
                    context=context
                )
                generation_time = time.time() - generation_start
                generation_times.append(generation_time)
                
                total_time = time.time() - start_time
                total_times.append(total_time)
                
            except Exception as e:
                logger.error(f"Error measuring performance for query '{query}': {e}")
                retrieval_times.append(0)
                generation_times.append(0)
                total_times.append(0)
        
        return {
            "avg_retrieval_time": sum(retrieval_times) / len(retrieval_times) if retrieval_times else 0,
            "avg_generation_time": sum(generation_times) / len(generation_times) if generation_times else 0,
            "avg_total_time": sum(total_times) / len(total_times) if total_times else 0,
            "queries_evaluated": len(test_queries)
        }
    
    def _calculate_faithfulness(self, response: str, context: str) -> float:
        """Calculate how faithful the response is to the context."""
        response_words = set(response.lower().split())
        context_words = set(context.lower().split())
        
        # Calculate overlap
        overlap = len(response_words & context_words)
        total_response_words = len(response_words)
        
        return overlap / total_response_words if total_response_words > 0 else 0
    
    def _calculate_relevance(
        self,
        response: str,
        query: str,
        expected: str
    ) -> float:
        """Calculate how relevant the response is to the query."""
        # Simple keyword matching for now
        # In production, you might use more sophisticated methods
        query_keywords = set(query.lower().split())
        response_keywords = set(response.lower().split())
        expected_keywords = set(expected.lower().split())
        
        # Query relevance
        query_overlap = len(query_keywords & response_keywords)
        query_relevance = query_overlap / len(query_keywords) if query_keywords else 0
        
        # Expected answer relevance
        expected_overlap = len(expected_keywords & response_keywords)
        expected_relevance = expected_overlap / len(expected_keywords) if expected_keywords else 0
        
        # Combine scores
        return (query_relevance + expected_relevance) / 2
    
    async def run_full_evaluation(
        self,
        test_data_path: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Run full pipeline evaluation.
        
        Args:
            test_data_path: Path to test data file
            
        Returns:
            Complete evaluation results
        """
        logger.info("Starting full pipeline evaluation...")
        
        # Load test data or use defaults
        if test_data_path:
            test_data = self._load_test_data(test_data_path)
        else:
            test_data = self._get_default_test_data()
        
        results = {
            "timestamp": time.time(),
            "config": {
                "chunk_size": settings.CHUNK_SIZE,
                "chunk_overlap": settings.CHUNK_OVERLAP,
                "top_k_chunks": settings.TOP_K_CHUNKS,
                "similarity_threshold": settings.SIMILARITY_THRESHOLD,
                "llm_model": settings.LLM_MODEL,
                "embedding_model": settings.EMBEDDING_MODEL
            }
        }
        
        # Evaluate retrieval
        if "retrieval_tests" in test_data:
            results["retrieval"] = await self.evaluate_retrieval_quality(
                test_data["retrieval_tests"]
            )
        
        # Evaluate response quality
        if "response_tests" in test_data:
            results["response"] = await self.evaluate_response_quality(
                test_data["response_tests"]
            )
        
        # Evaluate performance
        if "performance_tests" in test_data:
            results["performance"] = await self.evaluate_performance(
                test_data["performance_tests"]
            )
        
        # Overall score
        overall_scores = []
        if "retrieval" in results:
            overall_scores.append(results["retrieval"]["f1_score"])
        if "response" in results:
            overall_scores.append(results["response"]["faithfulness"])
            overall_scores.append(results["response"]["relevance"])
        
        results["overall_score"] = sum(overall_scores) / len(overall_scores) if overall_scores else 0
        
        return results
    
    def _load_test_data(self, file_path: str) -> Dict[str, Any]:
        """Load test data from file."""
        try:
            with open(file_path, 'r') as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"Failed to load test data: {e}")
            return {}
    
    def _get_default_test_data(self) -> Dict[str, Any]:
        """Get default test data."""
        return {
            "retrieval_tests": [
                ("What is Python?", ["doc1", "doc2"]),
                ("How to install packages?", ["doc3"]),
                ("API documentation", ["doc4", "doc5"])
            ],
            "response_tests": [
                (
                    "What is Python?",
                    "Python is a high-level programming language.",
                    "Python is a programming language"
                )
            ],
            "performance_tests": [
                "What is Python?",
                "How to use FastAPI?",
                "What is semantic search?"
            ]
        }


def main() -> None:
    """Main function."""
    import argparse
    
    # Setup logging
    setup_logging()
    
    # Parse arguments
    parser = argparse.ArgumentParser(description="RAG Pipeline Evaluation")
    parser.add_argument(
        "--test-data",
        type=str,
        help="Path to test data file (JSON)"
    )
    parser.add_argument(
        "--output",
        type=str,
        default="evaluation_results.json",
        help="Output file for results"
    )
    
    args = parser.parse_args()
    
    logger.info("RAG Pipeline Evaluation Script")
    
    async def run_evaluation():
        evaluator = PipelineEvaluator()
        results = await evaluator.run_full_evaluation(args.test_data)
        
        # Save results
        with open(args.output, 'w') as f:
            json.dump(results, f, indent=2)
        
        logger.info(f"Evaluation completed! Results saved to {args.output}")
        logger.info(f"Overall Score: {results.get('overall_score', 0):.3f}")
        
        # Print summary
        if "retrieval" in results:
            r = results["retrieval"]
            logger.info(f"Retrieval - Precision: {r['precision']:.3f}, Recall: {r['recall']:.3f}, F1: {r['f1_score']:.3f}")
        
        if "response" in results:
            r = results["response"]
            logger.info(f"Response - Faithfulness: {r['faithfulness']:.3f}, Relevance: {r['relevance']:.3f}")
        
        if "performance" in results:
            p = results["performance"]
            logger.info(f"Performance - Avg Total Time: {p['avg_total_time']:.3f}s")
    
    # Run evaluation
    asyncio.run(run_evaluation())


if __name__ == "__main__":
    main()