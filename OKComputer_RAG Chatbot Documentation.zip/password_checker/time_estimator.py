"""
Time Estimator Module

Functions to estimate how long it would take to crack a password.
This uses mathematical calculations to estimate cracking time.
"""

import math
from typing import Dict


def estimate_time_to_crack(password: str) -> float:
    """
    Estimate how many seconds it would take to crack the password.
    
    This calculation assumes:
    - Brute force attack (trying every possible combination)
    - Computer can try 1 billion passwords per second
    - Attacker knows the character set used
    
    Args:
        password: The password to analyze
        
    Returns:
        Time in seconds to crack the password
    """
    if not password:
        return 0
    
    # Determine character set size based on password content
    char_set_size = get_character_set_size(password)
    
    # Calculate total possible combinations
    # For a password of length N with C possible characters:
    # Total combinations = C^N
    length = len(password)
    total_combinations = char_set_size ** length
    
    # Assume attacker can try 1 billion passwords per second
    # (This is a reasonable estimate for a modern computer)
    guesses_per_second = 1_000_000_000
    
    # On average, attacker will find password halfway through all combinations
    average_tries = total_combinations / 2
    
    # Calculate time in seconds
    time_seconds = average_tries / guesses_per_second
    
    return time_seconds


def get_character_set_size(password: str) -> int:
    """
    Determine the size of the character set used in the password.
    
    Args:
        password: The password to analyze
        
    Returns:
        Number of possible characters in the character set
    """
    # Start with 0
    char_set_size = 0
    
    # Check what types of characters are used
    has_lowercase = any(c.islower() for c in password)
    has_uppercase = any(c.isupper() for c in password)
    has_numbers = any(c.isdigit() for c in password)
    has_symbols = any(c in "!@#$%^&*()_+-=[]{}|;:,.<>?" for c in password)
    
    # Add to character set size based on what's used
    if has_lowercase:
        char_set_size += 26  # a-z
    if has_uppercase:
        char_set_size += 26  # A-Z
    if has_numbers:
        char_set_size += 10  # 0-9
    if has_symbols:
        char_set_size += 32  # Common symbols
    
    # If no character types detected, assume at least lowercase
    if char_set_size == 0:
        char_set_size = 26
    
    return char_set_size


def format_time(seconds: float) -> str:
    """
    Convert seconds into a human-readable time format.
    
    Args:
        seconds: Time in seconds
        
    Returns:
        Human-readable time string
    """
    if seconds < 1:
        return "Less than 1 second"
    elif seconds < 60:
        return f"{seconds:.1f} seconds"
    elif seconds < 3600:  # Less than 1 hour
        minutes = seconds / 60
        return f"{minutes:.1f} minutes"
    elif seconds < 86400:  # Less than 1 day
        hours = seconds / 3600
        return f"{hours:.1f} hours"
    elif seconds < 31536000:  # Less than 1 year
        days = seconds / 86400
        return f"{days:.1f} days"
    elif seconds < 31536000000:  # Less than 1,000 years
        years = seconds / 31536000
        return f"{years:.1f} years"
    else:
        return "Over 1,000 years"


def get_cracking_method_info(password: str) -> Dict[str, str]:
    """
    Get information about the cracking method assumptions.
    
    Args:
        password: The password being analyzed
        
    Returns:
        Dictionary with cracking method information
    """
    char_set_size = get_character_set_size(password)
    total_combinations = char_set_size ** len(password)
    
    return {
        "method": "Brute Force (average case)",
        "speed": "1 billion guesses per second",
        "character_set": f"{char_set_size} characters",
        "total_combinations": f"{total_combinations:,.0f}",
        "assumptions": [
            "Attacker knows character set used",
            "Attacker uses optimal brute force strategy",
            "Modern computer with GPU acceleration",
            "Average case (50% of combinations tried)"
        ]
    }


def estimate_with_different_methods(password: str) -> Dict[str, float]:
    """
    Estimate cracking time with different attack methods.
    
    Args:
        password: The password to analyze
        
    Returns:
        Dictionary with different time estimates
    """
    base_time = estimate_time_to_crack(password)
    
    return {
        "brute_force_average": base_time,
        "brute_force_worst": base_time * 2,  # Worst case: try all combinations
        "dictionary_attack": base_time / 1000,  # Dictionary attacks are faster
        "rainbow_tables": base_time / 10000,  # Rainbow tables are even faster
        "gpu_cluster": base_time / 100,  # GPU clusters are much faster
    }


def explain_calculation(password: str) -> str:
    """
    Explain how the time-to-crack calculation was done.
    
    Args:
        password: The password being analyzed
        
    Returns:
        Explanation string
    """
    char_set_size = get_character_set_size(password)
    length = len(password)
    total_combinations = char_set_size ** length
    
    explanation = f"""
Time-to-Crack Calculation Explanation:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Password: {'*' * length} ({length} characters)
Character set size: {char_set_size} characters

Step 1: Calculate total possible combinations
  Formula: Character_Set_Size ^ Password_Length
  Calculation: {char_set_size} ^ {length} = {total_combinations:,.0f}

Step 2: Estimate average attempts needed
  On average, attacker finds password halfway through
  Average attempts: {total_combinations:,.0f} ÷ 2 = {total_combinations/2:,.0f}

Step 3: Calculate time at 1 billion guesses/second
  Time = Average_Attempts ÷ Guesses_Per_Second
  Time = {total_combinations/2:,.0f} ÷ 1,000,000,000
  Time = {estimate_time_to_crack(password):.2f} seconds

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Note: This is a theoretical estimate. Real cracking times may vary based on:
- Attack method used
- Hardware capabilities
- Whether attacker knows password patterns
- Dictionary attacks vs brute force
"""
    
    return explanation


# Example usage
if __name__ == "__main__":
    # Test passwords
    test_passwords = [
        ("123", "Very short password"),
        ("password", "Common word"),
        ("Password123", "Medium strength"),
        ("P@ssw0rd!2024", "Strong password"),
        ("MyS3cur3P@ssw0rd!IsV3ryL0ng", "Very strong password")
    ]
    
    print("Time Estimator Test Results")
    print("=" * 60)
    
    for password, description in test_passwords:
        time_seconds = estimate_time_to_crack(password)
        time_formatted = format_time(time_seconds)
        char_set = get_character_set_size(password)
        
        print(f"\nPassword: {password}")
        print(f"Description: {description}")
        print(f"Length: {len(password)} characters")
        print(f"Character set size: {char_set}")
        print(f"Time to crack: {time_formatted}")
        print("-" * 40)