#!/usr/bin/env python3
"""
Password Strength Checker - Tests

Simple tests to verify that the password checker functions work correctly.
This file helps ensure our code is working as expected.
"""

import sys
from pathlib import Path

# Add the current directory to Python path so we can import our modules
sys.path.append(str(Path(__file__).parent))

# Import our modules to test
from strength_analyzer import (
    check_length,
    check_character_types,
    check_common_patterns,
    calculate_password_score,
    get_strength_level
)
from time_estimator import (
    estimate_time_to_crack,
    get_character_set_size,
    format_time
)


def run_all_tests():
    """Run all tests and report results."""
    print("🧪 Running Password Strength Checker Tests")
    print("=" * 50)
    
    tests_passed = 0
    tests_failed = 0
    
    # Run all test functions
    test_functions = [
        test_length_checker,
        test_character_types,
        test_pattern_detection,
        test_score_calculation,
        test_time_estimation,
        test_time_formatting
    ]
    
    for test_function in test_functions:
        try:
            result = test_function()
            if result:
                tests_passed += 1
            else:
                tests_failed += 1
        except Exception as e:
            print(f"❌ Test {test_function.__name__} failed with error: {e}")
            tests_failed += 1
    
    # Summary
    print("\n" + "=" * 50)
    print(f"📊 Test Summary:")
    print(f"  ✅ Tests Passed: {tests_passed}")
    print(f"  ❌ Tests Failed: {tests_failed}")
    print(f"  📈 Success Rate: {tests_passed/(tests_passed+tests_failed)*100:.1f}%")
    
    if tests_failed == 0:
        print("\n🎉 All tests passed! Your code is working correctly.")
    else:
        print(f"\n⚠️  {tests_failed} test(s) failed. Please check your code.")
    
    return tests_failed == 0


def test_length_checker():
    """Test the password length checker."""
    print("\n1. Testing Length Checker...")
    
    # Test short passwords
    result = check_length("abc")
    assert "Too short!" in result, f"Expected 'Too short!' but got '{result}'"
    print("  ✓ Short password detected correctly")
    
    # Test minimum length
    result = check_length("abcdefg")  # 7 characters
    assert "Need at least 8" in result, f"Expected length warning but got '{result}'"
    print("  ✓ Minimum length warning works")
    
    # Test good length
    result = check_length("abcdefghij")  # 10 characters
    assert "Good length" in result, f"Expected 'Good length' but got '{result}'"
    print("  ✓ Good length password recognized")
    
    # Test excellent length
    result = check_length("abcdefghijklmnopqrst")  # 20 characters
    assert "Excellent" in result, f"Expected 'Excellent' but got '{result}'"
    print("  ✓ Excellent length password recognized")
    
    return True


def test_character_types():
    """Test the character type checker."""
    print("\n2. Testing Character Type Checker...")
    
    # Test lowercase only
    result = check_character_types("password")
    assert result["count"] == 1, f"Expected 1 type but got {result['count']}"
    assert result["types"]["has_lowercase"], "Should have lowercase"
    print("  ✓ Lowercase only detected")
    
    # Test mixed case
    result = check_character_types("Password")
    assert result["count"] == 2, f"Expected 2 types but got {result['count']}"
    assert result["types"]["has_uppercase"], "Should have uppercase"
    print("  ✓ Mixed case detected")
    
    # Test with numbers
    result = check_character_types("Password123")
    assert result["count"] == 3, f"Expected 3 types but got {result['count']}"
    assert result["types"]["has_numbers"], "Should have numbers"
    print("  ✓ Numbers detected")
    
    # Test with symbols
    result = check_character_types("Password123!")
    assert result["count"] == 4, f"Expected 4 types but got {result['count']}"
    assert result["types"]["has_symbols"], "Should have symbols"
    print("  ✓ Symbols detected")
    
    return True


def test_pattern_detection():
    """Test the pattern detection function."""
    print("\n3. Testing Pattern Detection...")
    
    # Test sequential characters
    result = check_common_patterns("abcdef")
    assert len(result) > 0, "Should detect sequential characters"
    assert any("sequential" in issue for issue in result), "Should mention sequential characters"
    print("  ✓ Sequential characters detected")
    
    # Test repeated characters
    result = check_common_patterns("aaabbb")
    assert len(result) > 0, "Should detect repeated characters"
    assert any("repeated" in issue for issue in result), "Should mention repeated characters"
    print("  ✓ Repeated characters detected")
    
    # Test common words
    result = check_common_patterns("password123")
    assert len(result) > 0, "Should detect common words"
    assert any("common word" in issue for issue in result), "Should mention common words"
    print("  ✓ Common words detected")
    
    # Test strong password (no issues)
    result = check_common_patterns("MyStr0ngP@ssw0rd!")
    # Should have fewer issues than weak passwords
    print(f"  ✓ Strong password has {len(result)} issues (should be minimal)")
    
    return True


def test_score_calculation():
    """Test the score calculation function."""
    print("\n4. Testing Score Calculation...")
    
    # Test very weak password
    score = calculate_password_score("123")
    assert score < 20, f"Expected low score but got {score}"
    print("  ✓ Very weak password has low score")
    
    # Test weak password
    score = calculate_password_score("password")
    assert score < 30, f"Expected low score but got {score}"
    print("  ✓ Weak password has low score")
    
    # Test medium password
    score = calculate_password_score("Password123")
    assert 40 <= score <= 70, f"Expected medium score but got {score}"
    print("  ✓ Medium password has medium score")
    
    # Test strong password
    score = calculate_password_score("MyStr0ngP@ssw0rd!")
    assert score >= 60, f"Expected high score but got {score}"
    print("  ✓ Strong password has high score")
    
    # Test score boundaries
    score = calculate_password_score("a" * 100)  # Very long but simple
    assert 0 <= score <= 100, f"Score should be 0-100 but got {score}"
    print("  ✓ Score is always between 0 and 100")
    
    return True


def test_time_estimation():
    """Test the time estimation functions."""
    print("\n5. Testing Time Estimation...")
    
    # Test very weak password
    time_seconds = estimate_time_to_crack("123")
    assert time_seconds < 1, f"Expected very short time but got {time_seconds}"
    print("  ✓ Weak password cracks quickly")
    
    # Test medium password
    time_seconds = estimate_time_to_crack("Password123")
    assert time_seconds > 0, f"Expected positive time but got {time_seconds}"
    print("  ✓ Medium password takes measurable time")
    
    # Test character set calculation
    char_set = get_character_set_size("abc")
    assert char_set == 26, f"Expected 26 but got {char_set}"
    print("  ✓ Lowercase only = 26 characters")
    
    char_set = get_character_set_size("ABC")
    assert char_set == 26, f"Expected 26 but got {char_set}"
    print("  ✓ Uppercase only = 26 characters")
    
    char_set = get_character_set_size("abcABC123")
    assert char_set == 62, f"Expected 62 but got {char_set}"
    print("  ✓ Letters + numbers = 62 characters")
    
    char_set = get_character_set_size("abcABC123!")
    assert char_set == 92, f"Expected 92 but got {char_set}"
    print("  ✓ Letters + numbers + symbols = 92 characters")
    
    return True


def test_time_formatting():
    """Test the time formatting function."""
    print("\n6. Testing Time Formatting...")
    
    # Test less than 1 second
    result = format_time(0.5)
    assert "Less than 1 second" in result, f"Expected short time format but got '{result}'"
    print("  ✓ Sub-second times formatted correctly")
    
    # Test seconds
    result = format_time(30)
    assert "seconds" in result, f"Expected seconds format but got '{result}'"
    print("  ✓ Seconds formatted correctly")
    
    # Test minutes
    result = format_time(120)  # 2 minutes
    assert "minutes" in result, f"Expected minutes format but got '{result}'"
    print("  ✓ Minutes formatted correctly")
    
    # Test hours
    result = format_time(7200)  # 2 hours
    assert "hours" in result, f"Expected hours format but got '{result}'"
    print("  ✓ Hours formatted correctly")
    
    # Test days
    result = format_time(172800)  # 2 days
    assert "days" in result, f"Expected days format but got '{result}'"
    print("  ✓ Days formatted correctly")
    
    # Test years
    result = format_time(63072000)  # 2 years
    assert "years" in result, f"Expected years format but got '{result}'"
    print("  ✓ Years formatted correctly")
    
    # Test very long time
    result = format_time(1e15)  # Very long time
    assert "1,000 years" in result or "Over 1,000 years" in result, f"Expected long time format but got '{result}'"
    print("  ✓ Very long times formatted correctly")
    
    return True


def test_edge_cases():
    """Test edge cases and special situations."""
    print("\n7. Testing Edge Cases...")
    
    # Empty password
    score = calculate_password_score("")
    assert score == 0, f"Empty password should score 0, got {score}"
    print("  ✓ Empty password handled correctly")
    
    # Single character
    time_sec = estimate_time_to_crack("a")
    assert time_sec < 1, f"Single character should crack instantly"
    print("  ✓ Single character handled correctly")
    
    # Very long password
    long_password = "a" * 50
    score = calculate_password_score(long_password)
    assert score > 50, f"Long password should have good score, got {score}"
    print("  ✓ Long password handled correctly")
    
    # Password with spaces
    result = check_common_patterns("my password")
    # Should still work with spaces
    print(f"  ✓ Password with spaces handled (found {len(result)} issues)")
    
    return True


# Run the tests when this file is executed
if __name__ == "__main__":
    success = run_all_tests()
    
    if success:
        print("\n🎉 All tests passed! Your password checker is working correctly.")
        print("You can now use it to check real passwords with confidence!")
    else:
        print("\n💡 Some tests failed. Check the messages above to fix the issues.")
        print("This is normal during development - it helps you find and fix bugs!")