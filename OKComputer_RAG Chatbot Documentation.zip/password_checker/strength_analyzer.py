"""
Password Strength Analyzer

Functions to analyze different aspects of password strength.
This module focuses on checking various security aspects of passwords.
"""

import re
from typing import Dict, List, Optional


def check_length(password: str) -> str:
    """
    Check if the password has good length.
    
    Args:
        password: The password to check
        
    Returns:
        A message about the password length
    """
    length = len(password)
    
    if length < 6:
        return "Too short! Very weak"
    elif length < 8:
        return "Too short! Need at least 8 characters"
    elif length < 10:
        return "Okay length, but longer is better"
    elif length < 12:
        return "Good length"
    elif length < 16:
        return "Very good length"
    else:
        return "Excellent length!"


def check_character_types(password: str) -> Dict[str, any]:
    """
    Check what types of characters the password uses.
    
    Args:
        password: The password to check
        
    Returns:
        Dictionary with character type analysis
    """
    # Check for each character type
    has_lowercase = any(c.islower() for c in password)
    has_uppercase = any(c.isupper() for c in password)
    has_numbers = any(c.isdigit() for c in password)
    has_symbols = any(c in "!@#$%^&*()_+-=[]{}|;:,.<>?" for c in password)
    
    # Count how many types are used
    types_count = sum([has_lowercase, has_uppercase, has_numbers, has_symbols])
    
    return {
        "count": types_count,
        "types": {
            "has_lowercase": has_lowercase,
            "has_uppercase": has_uppercase,
            "has_numbers": has_numbers,
            "has_symbols": has_symbols
        }
    }


def check_common_patterns(password: str) -> List[str]:
    """
    Check for common weak patterns in the password.
    
    Args:
        password: The password to check
        
    Returns:
        List of pattern issues found
    """
    issues = []
    password_lower = password.lower()
    
    # Check for sequential characters
    sequential_patterns = [
        "abcdefghijklmnopqrstuvwxyz",
        "0123456789",
        "qwertyuiop",  # Keyboard patterns
        "asdfghjkl",
        "zxcvbnm"
    ]
    
    for pattern in sequential_patterns:
        for i in range(len(pattern) - 2):
            if pattern[i:i+3] in password_lower:
                issues.append("Contains sequential characters")
                break
    
    # Check for repeated characters (3 or more in a row)
    for i in range(len(password) - 2):
        if password[i] == password[i+1] == password[i+2]:
            issues.append("Contains repeated characters (e.g., aaa, 111)")
            break
    
    # Check for common words (basic check)
    common_words = [
        "password", "pass", "word", "login", "user", "admin",
        "welcome", "hello", "guest", "test", "demo",
        "letmein", "welcome", "monkey", "dragon", "master"
    ]
    
    for word in common_words:
        if word in password_lower:
            issues.append(f"Contains common word: '{word}'")
            break
    
    # Check for years (19xx or 20xx)
    year_pattern = r"(?:19|20)\d{2}"
    if re.search(year_pattern, password):
        issues.append("Contains a year (e.g., 1990, 2020)")
    
    # Check for simple patterns like "abc123" or "password1"
    simple_patterns = [
        r"^[a-z]+\d+$",  # letters followed by numbers
        r"^\d+[a-z]+$",  # numbers followed by letters
    ]
    
    for pattern in simple_patterns:
        if re.match(pattern, password_lower):
            issues.append("Simple pattern detected")
            break
    
    return issues


def calculate_password_score(password: str) -> int:
    """
    Calculate an overall strength score for the password.
    
    Args:
        password: The password to score
        
    Returns:
        Score from 0-100
    """
    score = 0
    
    # Length score (0-40 points)
    length = len(password)
    if length >= 8:
        score += min(length * 4, 40)  # Up to 40 points for length
    else:
        score += length * 2  # Partial points for shorter passwords
    
    # Character variety score (0-40 points)
    char_types = check_character_types(password)
    score += char_types["count"] * 10  # 10 points per character type
    
    # Pattern penalty (-20 to 0 points)
    pattern_issues = check_common_patterns(password)
    score -= len(pattern_issues) * 5  # -5 points per issue
    
    # Bonus for length over 12 characters
    if length >= 12:
        score += 10
    if length >= 16:
        score += 10
    
    # Ensure score is between 0 and 100
    return max(0, min(score, 100))


def get_strength_level(score: int) -> Dict[str, str]:
    """
    Get the strength level based on the score.
    
    Args:
        score: The password strength score (0-100)
        
    Returns:
        Dictionary with level information
    """
    if score >= 80:
        return {
            "label": "VERY STRONG",
            "description": "Excellent password! Very difficult to crack."
        }
    elif score >= 60:
        return {
            "label": "STRONG",
            "description": "Good password. Should take a long time to crack."
        }
    elif score >= 40:
        return {
            "label": "MEDIUM",
            "description": "Okay password, but could be stronger."
        }
    elif score >= 20:
        return {
            "label": "WEAK",
            "description": "Weak password. Consider making it stronger."
        }
    else:
        return {
            "label": "VERY WEAK",
            "description": "Very weak password. Easy to crack."
        }


def contains_personal_info(password: str) -> bool:
    """
    Check if password contains common personal information patterns.
    
    Args:
        password: The password to check
        
    Returns:
        True if personal info detected
    """
    password_lower = password.lower()
    
    # Common personal info patterns
    personal_patterns = [
        r"\b(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)\b",  # Months
        r"\b(sun|mon|tue|wed|thu|fri|sat)\b",  # Days
        r"\b(john|jane|bob|alice|charlie|david)\b",  # Common names
    ]
    
    for pattern in personal_patterns:
        if re.search(pattern, password_lower):
            return True
    
    return False


def calculate_entropy(password: str) -> float:
    """
    Calculate the information entropy of the password.
    
    This measures how unpredictable the password is.
    
    Args:
        password: The password to analyze
        
    Returns:
        Entropy value in bits
    """
    # Count unique characters
    unique_chars = len(set(password))
    
    # Calculate entropy: log2(possible_characters ^ length)
    import math
    entropy = math.log2(unique_chars) * len(password)
    
    return entropy


# Example usage (only runs when this file is run directly)
if __name__ == "__main__":
    # Test passwords
    test_passwords = [
        "password",
        "Password123",
        "P@ssw0rd!2024",
        "abc123",
        "MyS3cur3P@ssw0rd!",
        "111111",
        "Qwerty123",
        "ILovePython2024!"
    ]
    
    print("Testing Password Strength Analyzer")
    print("=" * 50)
    
    for password in test_passwords:
        print(f"\nPassword: {password}")
        print(f"Length: {len(password)}")
        print(f"Length check: {check_length(password)}")
        
        char_types = check_character_types(password)
        print(f"Character types: {char_types['count']}/4")
        
        patterns = check_common_patterns(password)
        if patterns:
            print(f"Issues found: {patterns}")
        
        score = calculate_password_score(password)
        level = get_strength_level(score)
        print(f"Score: {score}/100 - {level['label']}")
        
        entropy = calculate_entropy(password)
        print(f"Entropy: {entropy:.1f} bits")
        
        print("-" * 30)