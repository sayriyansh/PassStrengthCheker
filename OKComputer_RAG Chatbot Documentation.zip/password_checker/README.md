# 🔐 Password Strength Checker

A simple, beginner-friendly Python project that checks how strong your passwords are and shows how long it would take for someone to guess them.

## 🎯 What This Project Does

This project helps you understand password security by:
- **Checking Password Strength**: Analyzes your password and gives it a score
- **Showing Weaknesses**: Tells you what's wrong with your password
- **Time-to-Crack Estimate**: Shows how long it would take to guess your password
- **Improvement Suggestions**: Gives tips to make your password stronger

## ✨ Features

- ✅ **Strength Analysis**: Checks length, character types, and patterns
- ✅ **Visual Feedback**: Color-coded results (red=weak, yellow=medium, green=strong)
- ✅ **Time Estimation**: Calculates how long a computer would need to guess the password
- ✅ **Multiple Check Methods**: Different ways to test password strength
- ✅ **Educational**: Learn about password security while using it
- ✅ **No External Libraries**: Uses only Python's built-in features

## 🚀 How to Use

### Method 1: Run the Main Program
```bash
python password_checker.py
```
Then follow the prompts to test passwords.

### Method 2: Use as a Library
```python
from password_checker import check_password_strength

result = check_password_strength("MyPassword123")
print(f"Score: {result['score']}/100")
print(f"Time to crack: {result['time_to_crack']}")
```

## 📁 Project Structure

```
password-strength-checker/
│
├── password_checker.py      # Main program
├── strength_analyzer.py     # Password analysis functions
├── time_estimator.py        # Time-to-crack calculations
├── common_passwords.txt     # List of common passwords (sample)
├── tests.py                 # Simple tests to check the code
├── requirements.txt         # Python dependencies (empty - uses built-in libraries)
├── README.md               # This file
└── LICENSE                 # Project license
```

## 🎓 Learning Goals

By building this project, you'll learn:
- **Python Basics**: Variables, functions, loops, if-statements
- **String Manipulation**: Working with text in Python
- **File Handling**: Reading from files
- **Basic Math**: Calculations and estimations
- **Creating Reusable Code**: Writing functions that others can use
- **Documentation**: How to explain your code to others

## 🛠️ Step-by-Step Build Guide

### Step 1: Basic Password Length Check
Start simple - just check if the password is long enough:
```python
def check_length(password):
    if len(password) < 8:
        return "Too short! Need at least 8 characters"
    elif len(password) >= 12:
        return "Good length!"
    else:
        return "Okay length, but longer is better"
```

### Step 2: Check for Different Character Types
Add checks for uppercase, lowercase, numbers, and symbols:
```python
def check_character_types(password):
    has_uppercase = any(c.isupper() for c in password)
    has_lowercase = any(c.islower() for c in password)
    has_number = any(c.isdigit() for c in password)
    has_symbol = any(c in "!@#$%^&*()_+-=[]{}|;:,.<>?" for c in password)
    
    # Count how many types are used
    types_count = sum([has_uppercase, has_lowercase, has_number, has_symbol])
    
    return types_count  # Returns number between 0-4
```

### Step 3: Look for Common Patterns
Check for patterns that make passwords weak:
```python
def check_common_patterns(password):
    # Check for sequential letters (abc, 123)
    # Check for repeated characters (aaa, 111)
    # Check for keyboard patterns (qwerty, asdf)
    # Check for common substitutions (pa$$word -> password)
    pass
```

### Step 4: Calculate Overall Score
Combine all checks into a final score:
```python
def calculate_password_score(password):
    score = 0
    
    # Length score (0-40 points)
    length = len(password)
    if length >= 8:
        score += min(length * 4, 40)  # Up to 40 points for length
    
    # Character variety score (0-40 points)
    types_count = check_character_types(password)
    score += types_count * 10  # 10 points per character type
    
    # Pattern penalty (-20 to 0 points)
    pattern_penalty = check_common_patterns(password)
    score += pattern_penalty
    
    return min(score, 100)  # Maximum score is 100
```

### Step 5: Estimate Time to Crack
Calculate how long it would take to guess the password:
```python
def estimate_time_to_crack(password):
    # Count possible characters
    possible_chars = 0
    if any(c.islower() for c in password):
        possible_chars += 26
    if any(c.isupper() for c in password):
        possible_chars += 26
    if any(c.isdigit() for c in password):
        possible_chars += 10
    if any(c in "!@#$%^&*()_+-=[]{}|;:,.<>?" for c in password):
        possible_chars += 30
    
    # Calculate total possibilities
    total_possibilities = possible_chars ** len(password)
    
    # Assume computer can try 1 billion passwords per second
    time_seconds = total_possibilities / 1_000_000_000
    
    return time_seconds
```

## 🧪 Testing Your Code

Run the tests to make sure everything works:
```bash
python tests.py
```

The tests will check:
- Password strength calculations are correct
- Time estimations are reasonable
- All functions return expected results
- Edge cases are handled properly

## 🚀 Running the Project

### Option 1: Interactive Mode
```bash
python password_checker.py
```
This will ask you to enter passwords and show you the results.

### Option 2: Batch Mode
```bash
python password_checker.py --file passwords.txt
```
This will check all passwords in the file.

### Option 3: Single Password
```bash
python password_checker.py --password "MyPassword123"
```
This will check just one password.

## 📊 Example Output

When you run the program, you'll see something like:

```
Enter a password to check: MyPassword123

Password Analysis:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Length: ✓ Good (13 characters)
Uppercase: ✓ Yes
Lowercase: ✓ Yes
Numbers: ✓ Yes
Symbols: ✗ No

Strength Score: 75/100
Strength Level: GOOD

Time to Crack: 2.3 years
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Suggestions:
- Add symbols to make it stronger
- Consider making it longer
```

## 🔍 How the Math Works

### Password Possibilities
If a password uses:
- **Only lowercase**: 26 possibilities per character
- **Lowercase + uppercase**: 52 possibilities per character
- **Letters + numbers**: 62 possibilities per character
- **Letters + numbers + symbols**: 92+ possibilities per character

### Time Calculation
```
Total Possibilities = (Character Set Size) ^ (Password Length)
Time to Crack = Total Possibilities ÷ Guesses Per Second
```

**Example**: "abc123" (6 characters, letters + numbers)
- Character set size: 62
- Total possibilities: 62^6 = 56,800,235,584
- At 1 billion guesses/second: ~57 seconds

## 🎓 Interview Explanation

**Q: What does your project do?**
*A: It's a password strength checker that analyzes passwords and estimates how long it would take to crack them. It checks things like length, character variety, and common patterns.*

**Q: How did you build it?**
*A: I broke it down into small functions - one checks length, another checks character types, one looks for patterns, and then I combine all the results into a final score.*

**Q: What did you learn?**
*A: I learned about string manipulation, file handling, basic math calculations, and how to organize code into reusable functions. I also learned about password security concepts.*

**Q: What challenges did you face?**
*A: The hardest part was figuring out how to calculate the time-to-crack accurately. I had to research character sets and understand how password cracking works.*

**Q: How could you improve it?**
*A: I could add more pattern detection, check against a larger list of common passwords, or create a web interface. I could also add support for checking passwords against known data breaches.*

## 🚀 Future Improvements

Here are some ideas to make the project even better:

### Beginner Ideas
- [ ] Add more password patterns to detect
- [ ] Create a GUI with tkinter
- [ ] Save results to a file
- [ ] Add color to the terminal output
- [ ] Create a password generator

### Intermediate Ideas
- [ ] Web interface with Flask
- [ ] Check against haveibeenpwned API
- [ ] Add unit tests with pytest
- [ ] Create a password manager integration
- [ ] Add multi-language support

### Advanced Ideas
- [ ] Machine learning to detect patterns
- [ ] Database to store common passwords
- [ ] API for other programs to use
- [ ] Real-time password strength meter
- [ ] Integration with password managers

## 📝 License

This project is open source and available under the MIT License.

## 🤝 Contributing

If you want to contribute:
1. Fork the repository
2. Create a new branch
3. Make your changes
4. Add tests if needed
5. Submit a pull request

## 🆘 Getting Help

If you're stuck:
1. Check the comments in the code
2. Read the error messages carefully
3. Try printing variables to see their values
4. Look up Python concepts you don't understand
5. Ask for help in online communities

## 🎉 Congratulations!

You've built a real Python project that:
- Solves a real-world problem
- Uses core Python concepts
- Can be shown in your portfolio
- Helps people understand password security

Keep coding and building more projects! 🚀